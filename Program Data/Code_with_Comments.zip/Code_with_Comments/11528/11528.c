/*
/*This function is responsible for reading and processing packets from an audio/video format context based on specified read intervals.*/

/*Here's the detail: The read_packets function takes a WriterContext pointer and an AVFormatContext pointer as input parameters. It initializes variables for iteration and result storage, specifically the 'i' for iteration and 'ret' for storing the result of function calls. It also initializes the current timestamp, 'cur_ts', using the start time from the AVFormatContext. The function then checks if there are any read intervals specified. If the number of read intervals is zero, it creates a default ReadInterval structure with no start or end, and passes it to the read_interval_packets function along with the WriterContext, the AVFormatContext, and the current timestamp. If read intervals are specified, it iterates through each interval by looping through the read_intervals_nb. For each iteration, it calls the read_interval_packets function with the WriterContext, the AVFormatContext, the specified read interval, and the current timestamp. If the return value from the function call is less than zero (indicating an error), the iteration breaks.*/

/*Needs to notice: When using this function, ensure that the WriterContext and AVFormatContext are properly initialized before passing them to the function. Additionally, make sure that the read_intervals_nb variable is correctly set before calling this function. It's important to handle any potential errors that may occur during the packet processing. Also, take care to manage the current timestamp appropriately and consider any specific requirements for reading intervals and packets within the given AVFormatContext.

*/static void read_packets(WriterContext* w, AVFormatContext* fmt_ctx)

{

    int i, ret = 0;

    int64_t cur_ts = fmt_ctx->start_time;



    if (read_intervals_nb == 0) {

        ReadInterval interval = (ReadInterval) { .has_start = 0, .has_end = 0 };

        ret = read_interval_packets(w, fmt_ctx, &interval, &cur_ts);

    } else {

        for (i = 0; i < read_intervals_nb; i++) {

            ret = read_interval_packets(w, fmt_ctx, &read_intervals[i], &cur_ts);

            if (ret < 0)

                break;

        }

    }

}
