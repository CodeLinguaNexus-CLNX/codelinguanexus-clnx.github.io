/*
This function is responsible for reading and processing the data packets in the IDCIN (Interplay CIN) video format within the context of AVFormat. Here's the detail: The function takes in the AVFormatContext and AVPacket as input. It begins by initializing various local variables and pointers, including the IDCIN demux context and the AVIOContext for data input/output.

The function then checks if the end-of-file has been reached in the input data source, and if so, it returns an I/O error. Next, it examines whether the next data chunk to be read is related to video. If it is, the function processes the video-related data, including decoding the palette and reading the chunk size. It validates the chunk size and then retrieves the packet data. In the case of a palette change, a new palette is constructed and attached to the packet as side data. The function also assigns the stream index and duration for the packet.

If the data chunk is related to audio, the function retrieves the audio packet data, assigns the stream index and duration, and updates the state for the next chunk type based on the audio presence.

Needs to notice:
1. The function is designed to handle the reading of IDCIN video format packets and relevant metadata, including palette information and audio data.
2. It involves the processing of palette changes, chunk size validation, and attachment of palette side data to the packet in the case of a palette change.
3. The function manages the parsing and retrieval of both video and audio data according to the IDCIN format specifications, as well as updating the chunk type state based on the presence of audio data.

In summary, this function plays a crucial role in the demuxing process for IDCIN video data, encompassing the parsing and extraction of video frames, palette information, and audio data in compliance with the IDCIN format.
*/
static int idcin_read_packet(AVFormatContext *s,

                             AVPacket *pkt)

{

    int ret;

    unsigned int command;

    unsigned int chunk_size;

    IdcinDemuxContext *idcin = s->priv_data;

    AVIOContext *pb = s->pb;

    int i;

    int palette_scale;

    unsigned char r, g, b;

    unsigned char palette_buffer[768];

    uint32_t palette[256];



    if (s->pb->eof_reached)

        return AVERROR(EIO);



    if (idcin->next_chunk_is_video) {

        command = avio_rl32(pb);

        if (command == 2) {

            return AVERROR(EIO);

        } else if (command == 1) {

            /* trigger a palette change */

            if (avio_read(pb, palette_buffer, 768) != 768)

                return AVERROR(EIO);

            /* scale the palette as necessary */

            palette_scale = 2;

            for (i = 0; i < 768; i++)

                if (palette_buffer[i] > 63) {

                    palette_scale = 0;

                    break;

                }



            for (i = 0; i < 256; i++) {

                r = palette_buffer[i * 3    ] << palette_scale;

                g = palette_buffer[i * 3 + 1] << palette_scale;

                b = palette_buffer[i * 3 + 2] << palette_scale;

                palette[i] = (r << 16) | (g << 8) | (b);

            }

        }



        chunk_size = avio_rl32(pb);

        if (chunk_size < 4 || chunk_size > INT_MAX - 4) {

            av_log(s, AV_LOG_ERROR, "invalid chunk size: %u\n", chunk_size);

            return AVERROR_INVALIDDATA;

        }

        /* skip the number of decoded bytes (always equal to width * height) */

        avio_skip(pb, 4);

        chunk_size -= 4;

        ret= av_get_packet(pb, pkt, chunk_size);

        if (ret < 0)

            return ret;

        if (command == 1) {

            uint8_t *pal;



            pal = av_packet_new_side_data(pkt, AV_PKT_DATA_PALETTE,

                                          AVPALETTE_SIZE);

            if (ret < 0)

                return ret;

            memcpy(pal, palette, AVPALETTE_SIZE);

            pkt->flags |= AV_PKT_FLAG_KEY;

        }

        pkt->stream_index = idcin->video_stream_index;

        pkt->duration     = 1;

    } else {

        /* send out the audio chunk */

        if (idcin->current_audio_chunk)

            chunk_size = idcin->audio_chunk_size2;

        else

            chunk_size = idcin->audio_chunk_size1;

        ret= av_get_packet(pb, pkt, chunk_size);

        if (ret < 0)

            return ret;

        pkt->stream_index = idcin->audio_stream_index;

        pkt->duration     = chunk_size / idcin->block_align;



        idcin->current_audio_chunk ^= 1;

    }



    if (idcin->audio_present)

        idcin->next_chunk_is_video ^= 1;



    return ret;

}
