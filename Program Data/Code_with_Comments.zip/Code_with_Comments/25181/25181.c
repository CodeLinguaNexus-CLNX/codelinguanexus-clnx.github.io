/*This function is responsible for performing bi-directional weighted interpolation for HEVC (High Efficiency Video Coding) video frames. It processes the input source data using specified interpolation weights and filter parameters to produce the output destination data.

Here's the detail:
- The function takes input source data, including the main source, secondary source (src2), and associated parameters such as strides, interpolation weights, offsets, and dimensions.
- It converts the input data pointers to pixel type and adjusts the strides accordingly for efficient processing.
- Internal parameters related to the interpolation filter, shift values, and logarithmic properties are calculated based on the bit depth and interpolation denominator.
- The function then iterates through the input height and width, applying the specified interpolation formula to each pixel to generate the output destination data.
- The interpolation process involves applying the interpolation filter, incorporating the weighted contributions from the main and secondary sources, and ensuring the output values are within the valid pixel range.

Need's to notice:
- Users should ensure that the input source, interpolation weights, and parameters are properly set and valid before invoking this function.
- The function heavily relies on the correctness of the input data and associated parameters. Any inconsistencies or inaccuracies may lead to unexpected results.
- When using this function, it's crucial to understand the implications of bi-directional weighted interpolation in the context of HEVC video processing and to consider its impact on the overall video decoding and visualization process.*/
static void FUNC(put_hevc_epel_bi_w_h)(uint8_t *_dst, ptrdiff_t _dststride, uint8_t *_src, ptrdiff_t _srcstride,

                                       int16_t *src2,

                                       int height, int denom, int wx0, int wx1,

                                       int ox0, int ox1, intptr_t mx, intptr_t my, int width)

{

    int x, y;

    pixel *src = (pixel *)_src;

    ptrdiff_t srcstride  = _srcstride / sizeof(pixel);

    pixel *dst          = (pixel *)_dst;

    ptrdiff_t dststride = _dststride / sizeof(pixel);

    const int8_t *filter = ff_hevc_epel_filters[mx - 1];

    int shift = 14 + 1 - BIT_DEPTH;

    int log2Wd = denom + shift - 1;



    ox0     = ox0 * (1 << (BIT_DEPTH - 8));

    ox1     = ox1 * (1 << (BIT_DEPTH - 8));

    for (y = 0; y < height; y++) {

        for (x = 0; x < width; x++)

            dst[x] = av_clip_pixel(((EPEL_FILTER(src, 1) >> (BIT_DEPTH - 8)) * wx1 + src2[x] * wx0 +

                                    ((ox0 + ox1 + 1) << log2Wd)) >> (log2Wd + 1));

        src  += srcstride;

        dst  += dststride;

        src2 += MAX_PB_SIZE;

    }

}
