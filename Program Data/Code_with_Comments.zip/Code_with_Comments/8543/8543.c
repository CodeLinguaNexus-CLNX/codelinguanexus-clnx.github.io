/*
This function is responsible for determining if a range of sectors within a CoW (Copy-on-Write) image file are allocated or not.

Here's the detail:
- It calculates the bit index within the CoW bitmap corresponding to the starting sector number provided as input.
- It then reads the bitmap data from the corresponding offset within the image file.
- After reading the bitmap data, it checks the status of the specified bit to determine if the sector has been changed (allocated) or remains the same (unallocated).
- Additionally, it calculates the number of consecutive sectors with the same allocation status (changed or unchanged) starting from the specified sector.

Needs to notice:
- Ensure that the BlockDriverState and other related structures are properly initialized before calling this function.
- Handle potential errors arising from file reading operations and bitmap manipulation to prevent unexpected behavior.
- Be mindful of the potential impact of endianness and other platform-specific considerations when working with bitmap data.
- Review the usage of function parameters and return values to ensure proper interpretation of the results.
*/
static int coroutine_fn cow_co_is_allocated(BlockDriverState *bs,

        int64_t sector_num, int nb_sectors, int *num_same)

{

    int64_t bitnum = sector_num + sizeof(struct cow_header_v2) * 8;

    uint64_t offset = (bitnum / 8) & -BDRV_SECTOR_SIZE;

    uint8_t bitmap[BDRV_SECTOR_SIZE];

    int ret;

    int changed;



    ret = bdrv_pread(bs->file, offset, &bitmap, sizeof(bitmap));

    if (ret < 0) {

        return ret;

    }



    bitnum &= BITS_PER_BITMAP_SECTOR - 1;

    changed = cow_test_bit(bitnum, bitmap);

    *num_same = cow_find_streak(bitmap, changed, bitnum, nb_sectors);

    return changed;

}
