/*
This function is responsible for handling the waiting and signaling mechanism associated with the synchronization condition. Here's the detail:

- The function increments the count of waiting threads on the condition variable (`cond->waiters++`), indicating that a new thread is about to wait on this condition.

- It then unlocks the external mutex (`qemu_mutex_unlock(mutex)`) and waits for a signal on the semaphore associated with the condition variable (`WaitForSingleObject(cond->sema, INFINITE)`).

- Following the wait on the semaphore, the function handles the synchronization logic where waiters rendezvous with the signaling thread. In the case of cond_broadcast, heavy contention and thundering herd phenomena may be observed.

- The decrement of the waiters count is performed atomically, and all waiters contend for the mutex until the signaling thread relinquishes it. This ensures that each waiter consumes exactly one slice of the semaphore. The signaling thread is stopped until it is informed by the last waiter that it can proceed.

- When the count of waiters reaches the target, the function signals the continue_event to allow the signaling thread to continue.

Points to notice:
- Careful consideration is needed when using this function, especially in scenarios with heavy contention or potential thundering herd effects, as noted in the comments.
- Attention should be given to the specific threading and synchronization requirements of the application to ensure correct and efficient usage of this function.
- Understanding the behavior and potential contention issues related to condition variables and mutexes is crucial for effective utilization of this function in a multi-threaded environment.
*/
void qemu_cond_wait(QemuCond *cond, QemuMutex *mutex)

{

    /*

     * This access is protected under the mutex.

     */

    cond->waiters++;



    /*

     * Unlock external mutex and wait for signal.

     * NOTE: we've held mutex locked long enough to increment

     * waiters count above, so there's no problem with

     * leaving mutex unlocked before we wait on semaphore.

     */

    qemu_mutex_unlock(mutex);

    WaitForSingleObject(cond->sema, INFINITE);



    /* Now waiters must rendez-vous with the signaling thread and

     * let it continue.  For cond_broadcast this has heavy contention

     * and triggers thundering herd.  So goes life.

     *

     * Decrease waiters count.  The mutex is not taken, so we have

     * to do this atomically.

     *

     * All waiters contend for the mutex at the end of this function

     * until the signaling thread relinquishes it.  To ensure

     * each waiter consumes exactly one slice of the semaphore,

     * the signaling thread stops until it is told by the last

     * waiter that it can go on.

     */

    if (InterlockedDecrement(&cond->waiters) == cond->target) {

        SetEvent(cond->continue_event);

    }



    qemu_mutex_lock(mutex);

}
