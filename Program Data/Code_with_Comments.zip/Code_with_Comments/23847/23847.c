/*
This function is responsible for initializing an OMAP (Open Multimedia Applications Platform) Real-Time Clock (RTC) device within the system's memory map. Here's the breakdown:

1. It allocates memory for the OMAP RTC device and initializes its structure using g_malloc0, which allocates the memory and sets it to zero.

2. It configures the IRQ (interrupt request) and alarm IRQ for the RTC device, enabling it to generate interrupts and handle alarm events.

3. It creates a new timer for the RTC device using qemu_new_timer_ms, associating it with the rtc_clock and omap_rtc_tick functions for timekeeping and event handling.

4. It resets the OMAP RTC device to ensure it's in a known state before operation.

5. It initializes an I/O memory region for the RTC device using memory_region_init_io and adds this region as a subregion to the system's memory map at the specified base address.

6. Finally, it returns a pointer to the initialized OMAP RTC device.

It's important to notice that this function sets up the OMAP RTC device's structure, timer, and memory region within the system, providing the necessary infrastructure for RTC functionality. Additionally, it ensures proper initialization and integration of the RTC device into the system's memory map.

*/
static struct omap_rtc_s *omap_rtc_init(MemoryRegion *system_memory,

                                        target_phys_addr_t base,

                                        qemu_irq timerirq, qemu_irq alarmirq,

                                        omap_clk clk)

{

    struct omap_rtc_s *s = (struct omap_rtc_s *)

            g_malloc0(sizeof(struct omap_rtc_s));



    s->irq = timerirq;

    s->alarm = alarmirq;

    s->clk = qemu_new_timer_ms(rtc_clock, omap_rtc_tick, s);



    omap_rtc_reset(s);



    memory_region_init_io(&s->iomem, &omap_rtc_ops, s,

                          "omap-rtc", 0x800);

    memory_region_add_subregion(system_memory, base, &s->iomem);



    return s;

}
