/*
This function is responsible for testing I/O channels using IPv4 addresses, with the option to perform asynchronous testing. It sets up socket addresses for listening and connecting, initializes them with IPv4 information, and then calls a testing function to perform I/O channel testing.

Here's the detail: The function first allocates memory for the listen_addr and connect_addr socket addresses, initializes them with IPv4 specifics such as host IP addresses and ports, and then calls the test_io_channel function to perform I/O channel testing, passing the addresses and the async flag as parameters. After the testing is complete, it frees the allocated memory for the socket addresses.

Need's to notice: When using this function, it's important to understand the specific behavior of the test_io_channel function and the implications of setting up IPv4 addresses for testing. Additionally, careful consideration should be given to the async parameter and its effect on the testing process, as well as the proper deallocation of memory after testing is complete to avoid memory leaks.
*/static void test_io_channel_ipv4(bool async)

{

    SocketAddress *listen_addr = g_new0(SocketAddress, 1);

    SocketAddress *connect_addr = g_new0(SocketAddress, 1);



    listen_addr->type = SOCKET_ADDRESS_KIND_INET;

    listen_addr->u.inet = g_new0(InetSocketAddress, 1);

    listen_addr->u.inet->host = g_strdup("0.0.0.0");

    listen_addr->u.inet->port = NULL; /* Auto-select */



    connect_addr->type = SOCKET_ADDRESS_KIND_INET;

    connect_addr->u.inet = g_new0(InetSocketAddress, 1);

    connect_addr->u.inet->host = g_strdup("127.0.0.1");

    connect_addr->u.inet->port = NULL; /* Filled in later */



    test_io_channel(async, listen_addr, connect_addr);



    qapi_free_SocketAddress(listen_addr);

    qapi_free_SocketAddress(connect_addr);

}
