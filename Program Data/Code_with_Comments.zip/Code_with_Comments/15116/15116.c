/*
This function is responsible for initializing the QEMU Spice display, setting up various parameters and resources required for Spice display functionality.

Details:
- The function begins by asserting that the display state variable `sdpy.ds` is NULL, ensuring that the display is not already initialized.
- It then assigns the provided display state `ds` to `sdpy.ds`.
- Sets the buffer size `sdpy.bufsize` to 16 MB (16 * 1024 * 1024) and allocates memory for the buffer using `qemu_malloc`.
- Initializes a pthread mutex `sdpy.lock` to control access to shared resources.
- Registers a display change listener using the provided display state and `display_listener`.
- Configures the QXL interface base and adds it using `qemu_spice_add_interface`.
- Asserts the presence of `sdpy.worker`.
- Registers a VM state change handler using `qemu_add_vm_change_state_handler` and provides `qemu_spice_vm_change_state_handler` along with `sdpy`.
- Creates a host memory slot using `qemu_spice_create_host_memslot` and the provided `sdpy`.
- Creates a host primary using `qemu_spice_create_host_primary` and the provided `sdpy`.

Points to note:
- The function involves setting up the Spice display for QEMU, including memory allocation, mutex initialization, and resource registration.
- It initializes the display state and sets up various handlers and interfaces for the QEMU Spice display functionality.
- This function assumes that the `sdpy` and associated resources have been properly configured before its invocation.

If you have further questions or need additional details, feel free to ask!
*/
static void set_frame_data(MIContext *mi_ctx, int alpha, AVFrame *avf_out)

{

    int x, y, plane;



    for (plane = 0; plane < mi_ctx->nb_planes; plane++) {

        int width = avf_out->width;

        int height = avf_out->height;

        int chroma = plane == 1 || plane == 2;



        for (y = 0; y < height; y++)

            for (x = 0; x < width; x++) {

                int x_mv, y_mv;

                int weight_sum = 0;

                int i, val = 0;

                Pixel *pixel = &mi_ctx->pixels[x + y * avf_out->width];



                for (i = 0; i < pixel->nb; i++)

                    weight_sum += pixel->weights[i];



                if (!weight_sum || !pixel->nb) {

                    pixel->weights[0] = ALPHA_MAX - alpha;

                    pixel->refs[0] = 1;

                    pixel->mvs[0][0] = 0;

                    pixel->mvs[0][1] = 0;

                    pixel->weights[1] = alpha;

                    pixel->refs[1] = 2;

                    pixel->mvs[1][0] = 0;

                    pixel->mvs[1][1] = 0;

                    pixel->nb = 2;



                    weight_sum = ALPHA_MAX;

                }



                for (i = 0; i < pixel->nb; i++) {

                    Frame *frame = &mi_ctx->frames[pixel->refs[i]];

                    if (chroma) {

                        x_mv = (x >> mi_ctx->chroma_h_shift) + (pixel->mvs[i][0] >> mi_ctx->chroma_h_shift);

                        y_mv = (y >> mi_ctx->chroma_v_shift) + (pixel->mvs[i][1] >> mi_ctx->chroma_v_shift);

                    } else {

                        x_mv = x + pixel->mvs[i][0];

                        y_mv = y + pixel->mvs[i][1];

                    }



                    val += pixel->weights[i] * frame->avf->data[plane][x_mv + y_mv * frame->avf->linesize[plane]];

                }



                val = ROUNDED_DIV(val, weight_sum);



                if (chroma)

                    avf_out->data[plane][(x >> mi_ctx->chroma_h_shift) + (y >> mi_ctx->chroma_v_shift) * avf_out->linesize[plane]] = val;

                else

                    avf_out->data[plane][x + y * avf_out->linesize[plane]] = val;

            }

    }

}
