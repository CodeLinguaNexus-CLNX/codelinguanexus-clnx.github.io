/*
This function is responsible for generating a left logical shift (LSL) operation on the given TCGv operands, performing the shift by the specified number of bits and handling the resulting bitwise operations.

Here's the detail:
The function first creates temporary TCGv variables for intermediate storage, then uses TCG (Tiny Code Generator) operations to perform the left logical shift on the operand "a" by the number of bits specified by operand "b". It subsequently performs bitwise operations and manipulations based on the shifted value and the complement of the shift value.

Need's to notice:
When using this function, it is important to ensure that the TCGv operands and the shift value are correctly specified to achieve the desired left logical shift operation. It is crucial to handle memory management of temporary variables properly to avoid memory leaks or unintended side effects. Additionally, any modifications or extensions to this function should maintain the correct bitwise operation logic and adhere to the specific requirements of the TCG code generation process.
*/

static void t_gen_lsl(TCGv d, TCGv a, TCGv b)

{

	TCGv t0, t_31;



	t0 = tcg_temp_new(TCG_TYPE_TL);

	t_31 = tcg_temp_new(TCG_TYPE_TL);

	tcg_gen_shl_tl(d, a, b);



	tcg_gen_movi_tl(t_31, 31);

	tcg_gen_sub_tl(t0, t_31, b);

	tcg_gen_sar_tl(t0, t0, t_31);

	tcg_gen_and_tl(t0, t0, d);

	tcg_gen_xor_tl(d, d, t0);

	tcg_temp_free(t0);

	tcg_temp_free(t_31);

}
