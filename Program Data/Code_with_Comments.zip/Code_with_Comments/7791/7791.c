/*This function is responsible for enabling or disabling a specific QEMU clock type and managing the associated timers.

Here's the detail: The function takes in the QEMUClockType and a boolean flag to enable or disable the clock. It retrieves the pointer to the specified QEMU clock type and updates its enabled status. If the clock is being enabled and was previously disabled, it triggers a notification to inform relevant components. If the clock is being disabled, it waits for any associated timers to complete before proceeding.

Needs to notice: This function provides a centralized mechanism for enabling or disabling QEMU clocks, ensuring that relevant components are appropriately notified. It also handles synchronization by waiting for timers to complete when disabling a clock, thereby preventing potential issues with ongoing timer operations.*/
void qemu_clock_enable(QEMUClockType type, bool enabled)

{

    QEMUClock *clock = qemu_clock_ptr(type);

    QEMUTimerList *tl;

    bool old = clock->enabled;

    clock->enabled = enabled;

    if (enabled && !old) {

        qemu_clock_notify(type);

    } else if (!enabled && old) {

        QLIST_FOREACH(tl, &clock->timerlists, list) {

            qemu_event_wait(&tl->timers_done_ev);

        }

    }

}
