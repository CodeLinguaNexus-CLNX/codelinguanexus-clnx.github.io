/*
This function is responsible for conducting a test related to the ACPI (Advanced Configuration and Power Interface) implementation in a system's BIOS. Here's the detail:

- The function begins by setting up test parameters and initiating the test environment with specific configurations related to networking and display, as well as allowing for optional parameters to be passed in.
- The function then enters a polling loop to wait for the BIOS to perform initialization and reach a specific state, indicated by a predefined signature in the memory.
- During the polling loop, the function repeatedly reads specific memory locations to check for the presence of the expected signature, by combining and comparing individual bytes to form the complete signature value.
- Once the expected signature is detected, the function breaks out of the polling loop and confirms the presence of the signature by asserting its equality to the expected value.
- Subsequently, the function proceeds to search for the Root System Description Pointer (RSDP) within a specific memory range, using a predefined signature string and comparing it with the content at different memory offsets.
- Upon locating the RSDP, the function asserts that the found memory offset is within a valid range and then concludes the test by quitting the test environment and freeing allocated resources.

Needs to notice:
- This function is designed to validate the functionality of ACPI-related features in the system's BIOS, particularly focusing on the identification of specific signatures and pointers within the memory.
- The function heavily relies on low-level memory access and manipulation, as well as time-based polling to observe the system's behavior during the test.
- The test's success is determined by the presence of specific signature values and the correct identification of the RSDP within the system's memory, indicating the proper initialization of ACPI-related components in the BIOS.

In summary, this function serves as a critical component of testing ACPI functionalities in the BIOS, ensuring the proper detection and validation of specific signatures and pointers, which are crucial for system power management and configuration capabilities.
*/

static void test_acpi_one(const char* params)

{

    char *args;

    uint8_t signature_low;

    uint8_t signature_high;

    uint16_t signature;

    int i;

    uint32_t off;





    args = g_strdup_printf("-net none -display none %s %s",

                           params ? params : "", disk);

    qtest_start(args);



   /* Wait at most 1 minute */

#define TEST_DELAY (1 * G_USEC_PER_SEC / 10)

#define TEST_CYCLES MAX((60 * G_USEC_PER_SEC / TEST_DELAY), 1)



    /* Poll until code has run and modified memory.  Once it has we know BIOS

     * initialization is done.  TODO: check that IP reached the halt

     * instruction.

     */

    for (i = 0; i < TEST_CYCLES; ++i) {

        signature_low = readb(BOOT_SECTOR_ADDRESS + SIGNATURE_OFFSET);

        signature_high = readb(BOOT_SECTOR_ADDRESS + SIGNATURE_OFFSET + 1);

        signature = (signature_high << 8) | signature_low;

        if (signature == SIGNATURE) {

            break;

        }

        g_usleep(TEST_DELAY);

    }

    g_assert_cmphex(signature, ==, SIGNATURE);



    /* OK, now find RSDP */

    for (off = 0xf0000; off < 0x100000; off += 0x10)

    {

        uint8_t sig[] = "RSD PTR ";

        int i;



        for (i = 0; i < sizeof sig - 1; ++i) {

            sig[i] = readb(off + i);

        }



        if (!memcmp(sig, "RSD PTR ", sizeof sig)) {

            break;

        }

    }



    g_assert_cmphex(off, <, 0x100000);



    qtest_quit(global_qtest);

    g_free(args);

}
