/*
This function is responsible for attempting to enable asynchronous IO events (AioContext) using the epoll mechanism.

Details:
- The aio_epoll_try_enable function iterates through the list of AioHandlers within the given AioContext.
- For each AioHandler, if it is not marked as deleted and has events set, the function proceeds to create an epoll_event structure and populate it with the corresponding event types as specified by the AioHandler's pfd events.
- The function then adds the file descriptor associated with the AioHandler to the epoll instance using epoll_ctl with the EPOLL_CTL_ADD command, linking the file descriptor with the prepared event.
- If any error occurs during the epoll_ctl operation, the function returns false, indicating the failure to enable the epoll mechanism for asynchronous IO events.
- If all AioHandlers have been successfully added to the epoll instance, the epoll_enabled flag in the AioContext is set to true, and the function returns true to signal successful activation of the epoll mechanism.

Needs to Notice:
- The function assumes the availability of the epoll mechanism and its integration with asynchronous IO operations using AioContext and AioHandlers.
- Proper error handling and recovery mechanisms should be in place to handle potential failures in adding file descriptors to the epoll instance.
- The context's epoll_enabled flag is updated on successful epoll event activation, and its state may impact the behavior of other related functions or components within the AioContext.

*/

static bool aio_epoll_try_enable(AioContext* ctx)

{

    AioHandler *node;

    struct epoll_event event;



    QLIST_FOREACH(node, &ctx->aio_handlers, node) {

        int r;

        if (node->deleted || !node->pfd.events) {

            continue;

        }

        event.events = epoll_events_from_pfd(node->pfd.events);

        event.data.ptr = node;

        r = epoll_ctl(ctx->epollfd, EPOLL_CTL_ADD, node->pfd.fd, &event);

        if (r) {

            return false;

        }

    }

    ctx->epoll_enabled = true;

    return true;

}
