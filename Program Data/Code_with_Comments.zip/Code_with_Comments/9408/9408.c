/*
This function is responsible for initializing the decoding process for M101 codec by setting up the pixel format based on the provided extradata.

Here's the detail of the function: The function first checks the size of the extradata and returns an error if it is less than 6*4 bytes. Then, it examines the extradata to determine the pixel format of the decoded output. If a specific condition in the extradata is met, it sets the pixel format to YUV422P10; otherwise, it defaults to YUYV422.

Need's to notice that this function is crucial in setting up the decoding process for the M101 codec. It analyzes the extradata to determine the pixel format, and developers should ensure that the extradata is correctly formatted according to the M101 specification to avoid errors during decoding.
*/static av_cold int m101_decode_init(AVCodecContext *avctx)

{

    if (avctx->extradata_size < 6*4)

        return AVERROR_INVALIDDATA;



    if (avctx->extradata[2*4] == 10)

        avctx->pix_fmt = AV_PIX_FMT_YUV422P10;

    else

        avctx->pix_fmt = AV_PIX_FMT_YUYV422;





    return 0;

}
