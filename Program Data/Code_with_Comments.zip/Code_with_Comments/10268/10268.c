/*
This function is responsible for comparing two 64-bit floating-point numbers for equality, while also handling signaling NaNs. Here's a detailed breakdown of the function:

- The function takes two 64-bit floating-point numbers, 'a' and 'b', as well as a status parameter.
- It first checks if either 'a' or 'b' is a signaling NaN (Not-a-Number) by examining their exponent and fraction fields. If either of them is a signaling NaN, it raises the "invalid" floating-point exception using float_raise and returns 0 to indicate that the numbers are not equal due to the presence of signaling NaNs.
- If neither 'a' nor 'b' is a signaling NaN, the function proceeds to compare 'a' and 'b' for equality using the standard equality comparison (a == b).
- Additionally, it performs a bitwise comparison to handle the case where both 'a' and 'b' are positive or negative zeros. This is achieved by logically ORing 'a' and 'b', left-shifting the result by 1 bit, and comparing the result with zero.
- The function then returns the result of the equality comparison, taking into account the presence of signaling NaNs and the special case of positive or negative zero.

Points to note:
- The function implements logic to handle signaling NaNs, ensuring that the comparison accounts for these special NaN values and raises the appropriate floating-point exception.
- It utilizes bitwise operations to handle the comparison of positive and negative zero values, which have different representations but are considered equal in the context of floating-point arithmetic.
- This function operates at the low level of floating-point representation and comparison, dealing with specific cases such as NaNs and special zero values.
- Users of this function should be aware of the intricacies of floating-point representation and NaN handling, and ensure appropriate error handling for signaling NaN cases.

In summary, this function provides a mechanism for comparing 64-bit floating-point numbers for equality while addressing the presence of signaling NaNs and special zero values, contributing to accurate floating-point arithmetic operations.
*/
int float64_eq_signaling( float64 a, float64 b STATUS_PARAM )

{



    if (    ( ( extractFloat64Exp( a ) == 0x7FF ) && extractFloat64Frac( a ) )

         || ( ( extractFloat64Exp( b ) == 0x7FF ) && extractFloat64Frac( b ) )

       ) {

        float_raise( float_flag_invalid STATUS_VAR);

        return 0;

    }

    return ( a == b ) || ( (bits64) ( ( a | b )<<1 ) == 0 );



}
