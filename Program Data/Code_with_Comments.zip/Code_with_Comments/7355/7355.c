/*This function is responsible for flushing the trace buffer data to a file, ensuring that the contents of the buffer are written to the trace file if it is open.

Here's the detail: The function `flush_trace_file` first checks if the trace file (`trace_fp`) is not open. If it's not open, it attempts to open it for writing. If the file opening operation fails, the function sets `trace_file_enabled` to false to avoid repeated attempts to open the file. If the file is successfully opened or was already open, the function writes the contents of the trace buffer (`trace_buf`) to the file using the fwrite function. It calculates the size to write based on the trace index and the size of elements in the buffer.

Need's to notice: When using this function, it's important to ensure that the trace file name is correctly set before calling this function. Additionally, proper file handling checks should be in place to handle potential failures in file opening or writing operations. Furthermore, the utilization of the `trace_buf` and `trace_idx` should be managed correctly to avoid data corruption and ensure efficient use of resources.*/
static void flush_trace_file(void)

{

    /* If the trace file is not open yet, open it now */

    if (!trace_fp) {

        trace_fp = fopen(trace_file_name, "w");

        if (!trace_fp) {

            /* Avoid repeatedly trying to open file on failure */

            trace_file_enabled = false;

            return;

        }

        write_header(trace_fp);

    }



    if (trace_fp) {

        size_t unused; /* for when fwrite(3) is declared warn_unused_result */

        unused = fwrite(trace_buf, trace_idx * sizeof(trace_buf[0]), 1, trace_fp);

    }

}
