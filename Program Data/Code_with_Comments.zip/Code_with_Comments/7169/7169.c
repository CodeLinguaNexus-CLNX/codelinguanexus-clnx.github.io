/**
 * This function is responsible for updating the coalesced range of memory regions to manage the coalesced memory transactions efficiently.
 *
 * Here's the detail breakdown of the function:
 *
 * The function iterates through each flat range within the current memory map and identifies the ones associated with the specified memory region. For each matching flat range, it unregisters the coalesced MMIO operations and proceeds to update the coalesced memory range based on the coalesced list of the memory region. It shifts the address range, checks for intersections, and registers the updated coalesced MMIO operations within the identified range. This process ensures that the coalesced memory ranges are accurately updated to reflect the changes in the memory region.

 * Usage needs to notice:
 *
 * This function plays a critical role in managing the coalesced memory transactions within the memory regions. Care should be taken while modifying the coalesced memory ranges or updating the memory regions to maintain the integrity of the coalesced memory operations. It is essential to thoroughly validate any changes to this function to prevent potential disruptions to the coalesced memory management functionality.
 */
static void memory_region_update_coalesced_range(MemoryRegion *mr)

{

    FlatRange *fr;

    CoalescedMemoryRange *cmr;

    AddrRange tmp;



    FOR_EACH_FLAT_RANGE(fr, &address_space_memory.current_map) {

        if (fr->mr == mr) {

            qemu_unregister_coalesced_mmio(int128_get64(fr->addr.start),

                                           int128_get64(fr->addr.size));

            QTAILQ_FOREACH(cmr, &mr->coalesced, link) {

                tmp = addrrange_shift(cmr->addr,

                                      int128_sub(fr->addr.start,

                                                 int128_make64(fr->offset_in_region)));

                if (!addrrange_intersects(tmp, fr->addr)) {

                    continue;

                }

                tmp = addrrange_intersection(tmp, fr->addr);

                qemu_register_coalesced_mmio(int128_get64(tmp.start),

                                             int128_get64(tmp.size));

            }

        }

    }

}
