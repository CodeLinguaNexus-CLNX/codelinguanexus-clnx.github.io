/**
 * This function is responsible for enumerating available I/O protocols by returning the protocol names based on the provided output mode, and updating the opaque pointer to iterate through the available URLProtocols.
 *
 * Here's the detail of the function:
 * - The function updates the opaque pointer to point to the next URLProtocol using ffurl_protocol_next(), and checks if the pointer is valid.
 * - If the pointer is valid and matches the specified output mode (read or write), the function returns the name of the protocol.
 * - If the pointer is invalid or does not match the specified output mode, the function recursively calls itself to continue the enumeration process.
 *
 * Need's to notice:
 * - This function provides a convenient way to iterate through the available URLProtocols and retrieve protocol names based on the specified read or write mode. It is commonly used in multimedia and network programming to enumerate the supported I/O protocols and select the appropriate protocol for data input or output operations.
 */
const char *avio_enum_protocols(void **opaque, int output)

{

    URLProtocol *p;

    *opaque = ffurl_protocol_next(*opaque);

    if (!(p = *opaque))

        return NULL;

    if ((output && p->url_write) || (!output && p->url_read))

        return p->name;

    return avio_enum_protocols(opaque, output);

}
