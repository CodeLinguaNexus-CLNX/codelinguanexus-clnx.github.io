/*
This function is responsible for resetting the counter of delivered Advanced Programmable Interrupt Controller (APIC) interrupts. Here's the detail:

- It resets the global variable apic_irq_delivered, which tracks the count of delivered interrupts.
- Before resetting the counter, it may generate a trace event to log the APIC reset operation.

Needs to notice when using this function:

- This function is used to reset the count of delivered interrupts by the APIC, typically for synchronization or initialization purposes.
- It's important to ensure that no critical interrupt delivery information is lost by resetting the counter.
- When calling this function, be aware that it will reset the count of delivered interrupts and consider any potential impacts on interrupt handling or monitoring.
*/

void apic_reset_irq_delivered(void)

{

    trace_apic_reset_irq_delivered(apic_irq_delivered);



    apic_irq_delivered = 0;

}
