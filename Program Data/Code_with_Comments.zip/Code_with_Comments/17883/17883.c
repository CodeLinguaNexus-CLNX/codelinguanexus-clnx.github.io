/*This function is responsible for copying a region of the VNC display from a source position to a destination position, either using the VNC copy rectangle feature or by performing a general display update.

Here's the detail: The function iterates through all connected VNC clients associated with the given display state. For each client, it checks if the client supports the VNC copy rectangle feature. If the feature is supported, it uses the vnc_copy function to efficiently copy the specified region from the source to the destination on the client's display. If the feature is not supported, a general display update is initiated using the vnc_update function to achieve similar visual results.

Need's to notice: Prior to calling this function, it's essential to ensure that the DisplayState and VncDisplay objects are properly initialized, and the VNC clients are correctly linked to the VncDisplay. Additionally, understanding the behavior and support for VNC features across different VNC clients is important for determining the appropriate method of updating the display. Developers should be aware of the performance implications of using the copy rectangle feature versus a general display update and choose the method accordingly.*/
static void vnc_dpy_copy(DisplayState *ds, int src_x, int src_y, int dst_x, int dst_y, int w, int h)

{

    VncDisplay *vd = ds->opaque;

    VncState *vs = vd->clients;

    while (vs != NULL) {

        if (vnc_has_feature(vs, VNC_FEATURE_COPYRECT))

            vnc_copy(vs, src_x, src_y, dst_x, dst_y, w, h);

        else /* TODO */

            vnc_update(vs, dst_x, dst_y, w, h);

        vs = vs->next;

    }

}
