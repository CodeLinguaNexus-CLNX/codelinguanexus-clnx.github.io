/*
This function is responsible for Huffman decompression of input data using the provided Huffman encoding table. Here's the detail:

1. The function takes in a GetByteContext pointer (gb), an array of uint16_t as the destination (dst), and the size of the destination buffer (dst_size) as input parameters.
2. It reads parameters and data from the input byte stream using the GetByteContext and bytestream2 functions.
3. The function allocates memory for frequency and decoding table structures using av_calloc.
4. It validates input parameters and performs error checks, such as ensuring that the input values are within the expected ranges.
5. It unpacks the Huffman encoding table and builds the corresponding decoding table using the provided frequency data.
6. The function then proceeds to decode the Huffman-compressed data and populate the destination buffer with the result.
7. After the decoding process, it handles memory deallocation for the decoding table and frequency data to avoid memory leaks.

Needs to notice:
Developers using this function should ensure that the input parameters and data are valid and properly formatted according to the Huffman compression scheme. Additionally, proper error handling and memory deallocation should be in place to handle potential memory allocation failures and ensure resource cleanup.
*/
static int huf_uncompress(GetByteContext *gb,

                          uint16_t *dst, int dst_size)

{

    int32_t src_size, im, iM;

    uint32_t nBits;

    uint64_t *freq;

    HufDec *hdec;

    int ret, i;



    src_size = bytestream2_get_le32(gb);

    im = bytestream2_get_le32(gb);

    iM = bytestream2_get_le32(gb);

    bytestream2_skip(gb, 4);

    nBits = bytestream2_get_le32(gb);

    if (im < 0 || im >= HUF_ENCSIZE ||

        iM < 0 || iM >= HUF_ENCSIZE ||

        src_size < 0)

        return AVERROR_INVALIDDATA;



    bytestream2_skip(gb, 4);



    freq = av_calloc(HUF_ENCSIZE, sizeof(*freq));

    hdec = av_calloc(HUF_DECSIZE, sizeof(*hdec));

    if (!freq || !hdec) {

        ret = AVERROR(ENOMEM);

        goto fail;

    }



    if ((ret = huf_unpack_enc_table(gb, im, iM, freq)) < 0)

        goto fail;



    if (nBits > 8 * bytestream2_get_bytes_left(gb)) {

        ret = AVERROR_INVALIDDATA;

        goto fail;

    }



    if ((ret = huf_build_dec_table(freq, im, iM, hdec)) < 0)

        goto fail;

    ret = huf_decode(freq, hdec, gb, nBits, iM, dst_size, dst);



fail:

    for (i = 0; i < HUF_DECSIZE; i++) {

        if (hdec[i].p)

            av_freep(&hdec[i].p);

    }



    av_free(freq);

    av_free(hdec);



    return ret;

}
