/*
This function is responsible for reading the file type data from a MOV context and populating metadata based on the extracted information. Here's the breakdown of the details:

- Upon receiving a MOV context and an input AVIOContext, the function reads the major brand and type information from the input.
- It then compares the retrieved type with "qt " and sets the isom flag in the context accordingly.
- The major brand information is logged and added to the metadata dictionary associated with the MOV context.
- The minor version is read and converted to a string, then added to the metadata as well.
- The function proceeds to read the compatible brands, allocate memory for the string, and populate the metadata with the compatible brand information.
- After adding the compatible brand information, the allocated memory is freed, and the function returns 0 to signal successful completion.

Points to notice:
1. The function reads and processes file type information, setting the appropriate flags and populating metadata fields in the MOV context.
2. Error handling is done for cases where the input data size is invalid or memory allocation fails.
3. The function performs string comparisons and manipulations for extracting and processing the file type information.

In summary, this function plays a fundamental role in extracting file type information from a MOV context and populating metadata based on the extracted data. It also demonstrates memory management and error handling for data processing.
*/
static int mov_read_ftyp(MOVContext *c, AVIOContext *pb, MOVAtom atom)

{

    uint32_t minor_ver;

    int comp_brand_size;

    char minor_ver_str[11]; /* 32 bit integer -> 10 digits + null */

    char* comp_brands_str;

    uint8_t type[5] = {0};



    avio_read(pb, type, 4);

    if (strcmp(type, "qt  "))

        c->isom = 1;

    av_log(c->fc, AV_LOG_DEBUG, "ISO: File Type Major Brand: %.4s\n",(char *)&type);

    av_dict_set(&c->fc->metadata, "major_brand", type, 0);

    minor_ver = avio_rb32(pb); /* minor version */

    snprintf(minor_ver_str, sizeof(minor_ver_str), "%"PRIu32"", minor_ver);

    av_dict_set(&c->fc->metadata, "minor_version", minor_ver_str, 0);



    comp_brand_size = atom.size - 8;

    if (comp_brand_size < 0)

        return AVERROR_INVALIDDATA;

    comp_brands_str = av_malloc(comp_brand_size + 1); /* Add null terminator */

    if (!comp_brands_str)

        return AVERROR(ENOMEM);

    avio_read(pb, comp_brands_str, comp_brand_size);

    comp_brands_str[comp_brand_size] = 0;

    av_dict_set(&c->fc->metadata, "compatible_brands", comp_brands_str, 0);

    av_freep(&comp_brands_str);



    return 0;

}
