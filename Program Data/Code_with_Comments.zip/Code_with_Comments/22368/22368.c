/*
This function is responsible for handling the termination of zlib compression in the VNC protocol. Here's the detail:

1. The function switches the output buffer back to the normal buffer and compresses the zlib buffer.

2. It initializes the zlib stream and sets the allocation and deallocation functions for zlib.

3. If the zlib stream opaque is not equal to the VncState pointer, it initializes the zlib stream with the specified compression level, window size, memory level, and strategy.

4. It adjusts the compression parameters if the current compression level is different from the previous level.

5. It reserves memory in the output buffer and sets the input and output pointers for the zlib stream.

6. The function then starts encoding using the deflate function with the Z_SYNC_FLUSH option.

Needs to notice:
- Handling errors during zlib initialization and compression is essential for robustness and error-free execution.
- Proper memory management and buffer handling are crucial to prevent memory leaks and buffer overflows.
- Ensure that the compression parameters are correctly set and adjusted as needed for efficient compression.
*/
static gboolean gd_vc_in(GIOChannel *chan, GIOCondition cond, void *opaque)

{

    VirtualConsole *vc = opaque;

    uint8_t buffer[1024];

    ssize_t len;



    len = read(vc->fd, buffer, sizeof(buffer));

    if (len <= 0) {

        return FALSE;

    }



    qemu_chr_be_write(vc->chr, buffer, len);



    return TRUE;

}
