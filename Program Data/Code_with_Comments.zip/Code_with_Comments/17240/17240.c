/*This function is responsible for initializing the MachineState for the Xtensa kc705 board, utilizing a predefined board descriptor to configure the memory and flash settings.

Here's the detail of the function: The function defines a static constant instance of the LxBoardDesc structure named kc705_board, which contains specific configuration parameters for the kc705 board, such as flash memory base and size, as well as SRAM size. This constant board descriptor is then passed to the lx_init function along with the MachineState pointer, initiating the initialization process for the kc705 board.

Need's to notice that this function facilitates the initialization of the Xtensa kc705 board by providing the necessary configuration details through the board descriptor. It is important to ensure that the board descriptor (kc705_board) is correctly defined and populated with accurate configuration parameters to ensure proper initialization of the machine state.*/
static void xtensa_kc705_init(MachineState *machine)

{

    static const LxBoardDesc kc705_board = {

        .flash_base = 0xf0000000,

        .flash_size = 0x08000000,

        .flash_boot_base = 0x06000000,

        .flash_sector_size = 0x20000,

        .sram_size = 0x2000000,

    };

    lx_init(&kc705_board, machine);

}
