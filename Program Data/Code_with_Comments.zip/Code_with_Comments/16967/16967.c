/*
/*
This function is responsible for handling the NBD_OPT_LIST option in the NBD protocol negotiation process.

Here's the detail: The function first checks the length of the NBD_OPT_LIST option. If the length is non-zero, it drops the specified number of bytes from the input queue and returns an error if the dropping operation fails. It then sends a reply error message with the NBD_REP_ERR_INVALID error code and NBD_OPT_LIST option to indicate that the OPT_LIST option should not have a length.

If the length is zero, the function iterates over each NBDExport structure in the exports queue, sending a NBD_REP_SERVER reply for each export. If any error occurs during the sending process, it returns -EINVAL.

It finishes the negotiation with a NBD_REP_ACK reply to acknowledge the successful completion of the NBD_OPT_LIST option negotiation.

Need's to notice: The function assumes that the NBDClient structure, NBDExport structure, and other necessary data structures are properly initialized and linked. Additionally, the function must be called within the NBD negotiation process and may require error handling for any potential issues encountered during the negotiation.
*/
*/
static void init_excp_620 (CPUPPCState *env)

{

#if !defined(CONFIG_USER_ONLY)

    env->excp_vectors[POWERPC_EXCP_RESET]    = 0x00000100;

    env->excp_vectors[POWERPC_EXCP_MCHECK]   = 0x00000200;

    env->excp_vectors[POWERPC_EXCP_DSI]      = 0x00000300;

    env->excp_vectors[POWERPC_EXCP_DSEG]     = 0x00000380;

    env->excp_vectors[POWERPC_EXCP_ISI]      = 0x00000400;

    env->excp_vectors[POWERPC_EXCP_ISEG]     = 0x00000480;

    env->excp_vectors[POWERPC_EXCP_EXTERNAL] = 0x00000500;

    env->excp_vectors[POWERPC_EXCP_ALIGN]    = 0x00000600;

    env->excp_vectors[POWERPC_EXCP_PROGRAM]  = 0x00000700;

    env->excp_vectors[POWERPC_EXCP_FPU]      = 0x00000800;

    env->excp_vectors[POWERPC_EXCP_DECR]     = 0x00000900;

    env->excp_vectors[POWERPC_EXCP_SYSCALL]  = 0x00000C00;

    env->excp_vectors[POWERPC_EXCP_TRACE]    = 0x00000D00;

    env->excp_vectors[POWERPC_EXCP_FPA]      = 0x00000E00;

    env->excp_vectors[POWERPC_EXCP_PERFM]    = 0x00000F00;

    env->excp_vectors[POWERPC_EXCP_IABR]     = 0x00001300;

    env->excp_vectors[POWERPC_EXCP_SMI]      = 0x00001400;

    env->excp_prefix = 0xFFF00000UL;

    /* Hardware reset vector */

    env->hreset_vector = 0x0000000000000100ULL;

#endif

}
