/**
 * This function is responsible for writing a 16-bit value to the specified physical address after performing an endianness swap if necessary.
 */

 /**
  * Here's the detail:
  * The function first performs an endianness swap on the input 32-bit value, converting it to a 16-bit value using the tswap16 function. It then writes the resulting 16-bit value to the specified physical address using the cpu_physical_memory_write function, effectively writing two bytes to the memory at the given address. This operation allows for direct manipulation of physical memory contents within the system's address space, taking into account potential endianness differences.

  */

  /**
   * Need's to notice:
   * When utilizing this function, ensure that the target physical address and the provided 32-bit value are appropriate for the intended memory write operation. Validate the input parameters and consider the endianness of the target system to determine if an endianness swap is necessary. Exercise caution when directly writing to physical memory, as improper usage can lead to system instability or data corruption. Additionally, verify that the cpu_physical_memory_write function behaves as expected in the context of the system's memory access mechanisms.
   */
void stw_phys(target_phys_addr_t addr, uint32_t val)

{

    uint16_t v = tswap16(val);

    cpu_physical_memory_write(addr, (const uint8_t *)&v, 2);

}
