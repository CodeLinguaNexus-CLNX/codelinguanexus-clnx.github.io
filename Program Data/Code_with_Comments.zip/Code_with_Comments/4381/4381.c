/*
This function is responsible for registering save and restore handlers for a specific device within the QEMU virtualization environment. Here's the detail:
- It allocates memory for a SaveVMHandlers structure and initializes the save_state and load_state function pointers with the provided handlers for saving and loading the device state.
- After setting up the handlers, it calls the register_savevm_live function, passing the provided device, identification strings, instance and version IDs, along with the initialized SaveVMHandlers and an opaque pointer.

Needs to notice:
- The function simplifies the registration process by encapsulating the allocation and initialization of SaveVMHandlers and delegating the actual registration to the register_savevm_live function.
- It abstracts away the handling of save and load callbacks, allowing for a cleaner interface when registering device state for serialization.
- The opaque pointer is a generic pointer that can be used to pass additional context or data to the save and load handlers, enabling more flexible and customizable save and restore operations for the device state.
- Care should be taken to ensure that the provided save_state and load_state function pointers are valid and handle the device state appropriately to avoid potential issues during serialization and deserialization.
*/

int register_savevm(DeviceState* dev,

                    const char *idstr,

                    int instance_id,

                    int version_id,

                    SaveStateHandler *save_state,

                    LoadStateHandler *load_state,

                    void *opaque)

{

    SaveVMHandlers *ops = g_malloc0(sizeof(SaveVMHandlers));

    ops->save_state = save_state;

    ops->load_state = load_state;

    return register_savevm_live(dev, idstr, instance_id, version_id,

                                ops, opaque);

}
