/*
This function is responsible for configuring the properties of a source filter in the context of the Frei0r video processing plugin.

Details:
- The `source_config_props` function takes an output link of the filter as input and accesses the private context of the filter to retrieve configuration parameters.
- It first validates the image size (width and height) using the `av_image_check_size` function to ensure that it complies with the requirements and constraints defined by the filter context. If the check fails, the function returns an Invalid Argument error.
- The function then sets the width, height, and time base of the output link based on the values stored in the filter's private context.
- Subsequently, it attempts to create an instance of the Frei0r plugin using the `construct` function and sets the plugin instance in the filter's private context. If the creation fails, an error is logged, and an Invalid Argument error is returned.
- Finally, the function calls the `set_params` function to set the parameters for the Frei0r plugin instance based on the configuration stored in the filter's private context.

Points to note:
- This function operates within the context of a source filter and is specifically tailored to configure the properties and parameters related to the Frei0r video processing plugin.
- It is important to ensure that the image size and other configuration parameters comply with the requirements of the filter to avoid potential errors during video processing.
- The successful creation of the Frei0r plugin instance is essential for the proper functioning of the source filter, and failure to do so can lead to processing issues.

If you have further questions or need additional details, feel free to ask!
*/
static int source_config_props(AVFilterLink *outlink)

{

    AVFilterContext *ctx = outlink->src;

    Frei0rContext *s = ctx->priv;



    if (av_image_check_size(s->w, s->h, 0, ctx) < 0)

        return AVERROR(EINVAL);

    outlink->w = s->w;

    outlink->h = s->h;

    outlink->time_base = s->time_base;





    if (!(s->instance = s->construct(outlink->w, outlink->h))) {

        av_log(ctx, AV_LOG_ERROR, "Impossible to load frei0r instance");

        return AVERROR(EINVAL);

    }



    return set_params(ctx, s->params);

}