/**
 * This function is responsible for handling Signal Processor (SIGP) instructions on the System/390 architecture.
 *
 * Here's the detail of the function: The function takes in the System/390 CPU state, an order code, a register value, and a CPU address, and executes the corresponding operation based on the order code. It logs the input parameters, performs operations based on the order code, such as setting the architecture, sensing CPU status, restarting or stopping the system in non-user mode, and handling unknown order codes. It also updates the condition code (cc) based on the result of the operation and returns it.
 *
 * Need's to notice that this function plays a crucial role in handling SIGP instructions on the System/390 architecture, including switching the architecture, sensing CPU status, and controlling system restart and shutdown in non-user mode. It is essential for proper system operation and should be carefully handled when making changes related to SIGP instruction handling in the System/390 CPU emulation.
 *
 * Token: 219
 */
uint32_t HELPER(sigp)(CPUS390XState *env, uint64_t order_code, uint32_t r1,

                      uint64_t cpu_addr)

{

    int cc = SIGP_CC_ORDER_CODE_ACCEPTED;



    HELPER_LOG("%s: %016" PRIx64 " %08x %016" PRIx64 "\n",

               __func__, order_code, r1, cpu_addr);



    /* Remember: Use "R1 or R1 + 1, whichever is the odd-numbered register"

       as parameter (input). Status (output) is always R1. */



    switch (order_code) {

    case SIGP_SET_ARCH:

        /* switch arch */

        break;

    case SIGP_SENSE:

        /* enumerate CPU status */

        if (cpu_addr) {

            /* XXX implement when SMP comes */

            return 3;

        }

        env->regs[r1] &= 0xffffffff00000000ULL;

        cc = 1;

        break;

#if !defined(CONFIG_USER_ONLY)

    case SIGP_RESTART:

        qemu_system_reset_request();

        cpu_loop_exit(CPU(s390_env_get_cpu(env)));

        break;

    case SIGP_STOP:

        qemu_system_shutdown_request();

        cpu_loop_exit(CPU(s390_env_get_cpu(env)));

        break;

#endif

    default:

        /* unknown sigp */

        fprintf(stderr, "XXX unknown sigp: 0x%" PRIx64 "\n", order_code);

        cc = SIGP_CC_NOT_OPERATIONAL;

    }



    return cc;

}
