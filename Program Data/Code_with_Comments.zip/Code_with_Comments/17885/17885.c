/*This function is responsible for initiating the shutdown of an emulated smart card device and handling the cleanup of associated resources and threads.

Here's the detail: The function begins by creating a new VEvent to signal the termination of the virtual event thread. Subsequently, it locks the apdu_thread_quit_mutex and sets the quit_apdu_thread flag, signaling the termination of the handle_apdu thread. It then uses condition variables to ensure the orderly shutdown of the handle_apdu thread before proceeding to destroy the associated mutexes and condition variables.

Need's to notice: Before invoking this function, it's important to ensure that the CCIDCardState and EmulatedState objects are in a valid state and that the associated threads and resources are active. Developers should be cautious about the potential impact of terminating the handle_apdu thread and the subsequent cleanup of mutexes and condition variables. Additionally, understanding the overall system state and the implications of stopping the virtual event and handle_apdu threads is crucial for correct usage of this function.*/
static int emulated_exitfn(CCIDCardState *base)

{

    EmulatedState *card = DO_UPCAST(EmulatedState, base, base);

    VEvent *vevent = vevent_new(VEVENT_LAST, NULL, NULL);



    vevent_queue_vevent(vevent); /* stop vevent thread */

    qemu_mutex_lock(&card->apdu_thread_quit_mutex);

    card->quit_apdu_thread = 1; /* stop handle_apdu thread */

    qemu_cond_signal(&card->handle_apdu_cond);

    qemu_cond_wait(&card->apdu_thread_quit_cond,

                      &card->apdu_thread_quit_mutex);

    /* handle_apdu thread stopped, can destroy all of it's mutexes */

    qemu_cond_destroy(&card->handle_apdu_cond);

    qemu_cond_destroy(&card->apdu_thread_quit_cond);

    qemu_mutex_destroy(&card->apdu_thread_quit_mutex);

    qemu_mutex_destroy(&card->handle_apdu_mutex);

    qemu_mutex_destroy(&card->vreader_mutex);

    qemu_mutex_destroy(&card->event_list_mutex);

    return 0;

}
