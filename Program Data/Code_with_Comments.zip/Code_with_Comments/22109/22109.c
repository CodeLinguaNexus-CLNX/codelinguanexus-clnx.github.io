/*
This function is responsible for displaying the details of an Access Control List (ACL) specified by the given ACL name in the monitor interface.

Here's the detail:
- It begins by extracting the ACL name from the input QDict using the key "aclname".
- It then searches for the ACL object associated with the provided ACL name by invoking the function find_acl().
- If the ACL is found, the function proceeds to output the ACL's policy (whether it's a default deny or allow policy) using monitor_printf().
- Additionally, it iterates through the ACL entries using TAILQ_FOREACH to display each entry's details, including the entry number, the permission status (allow or deny), and the matching criteria.

Needs to notice:
- Prior to calling this function, ensure that the monitor interface and the QDict containing the ACL name are properly initialized and passed to the function.
- It's essential to ensure that the ACL system is appropriately set up and populated with ACL entries before calling this function to avoid unexpected behavior.
- The output format and content of the ACL details are tailored to be displayed in the monitor interface, so the handling of the output should align with the requirements of the monitor interface.
*/
void qemu_system_suspend_request(void)

{

    if (is_suspended) {

        return;

    }

    suspend_requested = 1;

    cpu_stop_current();

    qemu_notify_event();

}
