/*This function is responsible for locating the System Management BIOS (SMBIOS) entry point structure within the memory address range of 0xF0000 to 0x100000. It iterates through this memory range in increments of 0x10, searching for the "_SM_" signature that indicates the presence of the SMBIOS entry point structure.

Here's the detail: Within the specified memory range, the function reads each 16-byte aligned address and checks for the "_SM_" signature. Once the signature is found, the function breaks out of the loop and records the address where the signature was located as the SMBIOS entry point address.

Needs to notice: It's important to note that this function assumes the presence of the SMBIOS entry point structure within the defined memory range and relies on the "_SM_" signature to identify its location. Additionally, the function uses assertions to verify that the identified address falls within the expected memory range.*/
static void test_smbios_ep_address(test_data *data)

{

    uint32_t off;



    /* find smbios entry point structure */

    for (off = 0xf0000; off < 0x100000; off += 0x10) {

        uint8_t sig[] = "_SM_";

        int i;



        for (i = 0; i < sizeof sig - 1; ++i) {

            sig[i] = readb(off + i);

        }



        if (!memcmp(sig, "_SM_", sizeof sig)) {

            break;

        }

    }



    g_assert_cmphex(off, <, 0x100000);

    data->smbios_ep_addr = off;

}
