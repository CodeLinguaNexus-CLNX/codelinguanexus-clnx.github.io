/*
This function is responsible for adding a new ROM blob to the system's ROM memory. Here's the detail:

- It takes the name of the ROM, the actual blob data, its length, and the target physical address as input parameters.
- It allocates memory for a new ROM structure, initializes its attributes including name, address, size, and data.
- It then copies the blob data into the allocated memory within the ROM structure.
- Finally, it inserts the newly created ROM structure into the ROM memory.

Needs to notice:
- Ensure that proper validation and error handling are in place for the input parameters, especially for the blob, length, and address.
- Consider memory management and potential memory leaks associated with the allocation and deallocation of ROM structures and blob data.
- Verify that the rom_insert function works as expected and handles the insertion of the new ROM structure appropriately within the ROM memory.
*/

int rom_add_blob(const char* name, const void* blob, size_t len,

                 target_phys_addr_t addr)

{

    Rom *rom;



    rom = g_malloc0(sizeof(*rom));

    rom->name    = g_strdup(name);

    rom->addr    = addr;

    rom->romsize = len;

    rom->data    = g_malloc0(rom->romsize);

    memcpy(rom->data, blob, len);

    rom_insert(rom);

    return 0;

}
