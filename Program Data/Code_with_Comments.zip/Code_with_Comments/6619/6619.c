/*
This function is responsible for ensuring that an AVIOContext structure has enough buffer space for seeking back by a specified buffer size.

Here's the detail of the function:
The function calculates the required buffer size by adding the specified buffer size to the current buffer position and the maximum buffer size allowed. It then checks if the calculated buffer size is less than the current buffer size or if the AVIOContext is seekable. If so, it returns without performing any further action. If the buffer size is insufficient and the AVIOContext is not seekable, the function allocates a new buffer of the required size, copies the existing data into the new buffer, updates the AVIOContext fields, and frees the old buffer.

Needs to notice:
The function assumes that the AVIOContext is not writable and performs the buffer reallocation and data copying only if the AVIOContext is not seekable and the current buffer size is insufficient.
Developers should ensure that the buffer reallocation and data copying logic aligns with the requirements of the AVIOContext and handle potential memory allocation failures appropriately.
The function does not handle the case when the AVIOContext is writable, and this behavior should be taken into consideration when using the function in a writable context.
It's important to manage memory allocation and deallocation carefully to avoid memory leaks and buffer overflows.
*/

int ffio_ensure_seekback(AVIOContext* s, int buf_size)

{

    uint8_t *buffer;

    int max_buffer_size = s->max_packet_size ?

                          s->max_packet_size : IO_BUFFER_SIZE;



    buf_size += s->buf_ptr - s->buffer + max_buffer_size;



    if (buf_size < s->buffer_size || s->seekable)

        return 0;

    av_assert0(!s->write_flag);



    buffer = av_malloc(buf_size);

    if (!buffer)

        return AVERROR(ENOMEM);



    memcpy(buffer, s->buffer, s->buffer_size);

    av_free(s->buffer);

    s->buf_ptr = buffer + (s->buf_ptr - s->buffer);

    s->buf_end = buffer + (s->buf_end - s->buffer);

    s->buffer = buffer;

    s->buffer_size = buf_size;

    return 0;

}
