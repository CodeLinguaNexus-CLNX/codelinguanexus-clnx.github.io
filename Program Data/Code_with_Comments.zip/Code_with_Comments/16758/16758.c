/*
This function is responsible for initializing the Translation Control Entry (TCE) table associated with a PowerPC Accelerated Processing Unit (APU) device in the context of virtual I/O for Power Architecture (VIOsPAPR).

Here's the detail: Upon invocation, the rtce_init function calculates the size required for the TCE table based on the rtce_window_size parameter provided by the device. It then proceeds to create the TCE table using the kvmppc_create_spapr_tce function, which interfaces with the Kernel-based Virtual Machine (KVM) subsystem to allocate and initialize the TCE table. If the creation process is unsuccessful, the function falls back to allocating and zero-initializing the TCE table using g_malloc0.

Need's to notice that this function plays a critical role in setting up the TCE table for the APU device, facilitating memory address translation and device access within the virtualized environment. Developers should ensure that the rtce_window_size parameter and the associated TCE table creation process are configured correctly to enable proper memory mapping and access for the APU device. Additionally, proper error handling and resource allocation should be considered for robust functionality.
*/
static void rtce_init(VIOsPAPRDevice *dev)

{

    size_t size = (dev->rtce_window_size >> SPAPR_VIO_TCE_PAGE_SHIFT)

        * sizeof(VIOsPAPR_RTCE);



    if (size) {

        dev->rtce_table = kvmppc_create_spapr_tce(dev->reg,

                                                  dev->rtce_window_size,

                                                  &dev->kvmtce_fd);



        if (!dev->rtce_table) {

            dev->rtce_table = g_malloc0(size);

        }

    }

}
