/*
This function is responsible for recursively draining pending I/O requests from the given BlockDriverState and its child nodes. Here's a breakdown of its operations:

1. The function begins by ensuring that any pending metadata writes are submitted to the file associated with the BlockDriverState (bs).

2. It then waits for all drained requests to finish by checking the in-flight request count and polling until it reaches zero.

3. Next, it iterates through each child node of the given BlockDriverState, and for each child, it recursively calls bdrv_drain_recurse on the child's BlockDriverState.

4. During this iteration, it maintains a reference to the child's BlockDriverState if the function is being executed within the main execution loop, and releases the reference after the recursive call.

5. The function returns a boolean value indicating whether it has waited for any drained requests to finish at any level of recursion.

Points to note:
- This function utilizes recursion to recursively drain all pending I/O requests from the given BlockDriverState and its child nodes.
- It employs reference counting to ensure proper handling of BlockDriverState objects and manages references when executing within the main execution loop.
- Special consideration is given to synchronization and thread safety, particularly in scenarios where the function is called from different execution contexts.
*/
static bool bdrv_drain_recurse(BlockDriverState *bs, bool begin)

{

    BdrvChild *child, *tmp;

    bool waited;



    /* Ensure any pending metadata writes are submitted to bs->file.  */

    bdrv_drain_invoke(bs, begin);



    /* Wait for drained requests to finish */

    waited = BDRV_POLL_WHILE(bs, atomic_read(&bs->in_flight) > 0);



    QLIST_FOREACH_SAFE(child, &bs->children, next, tmp) {

        BlockDriverState *bs = child->bs;

        bool in_main_loop =

            qemu_get_current_aio_context() == qemu_get_aio_context();

        assert(bs->refcnt > 0);

        if (in_main_loop) {

            /* In case the recursive bdrv_drain_recurse processes a

             * block_job_defer_to_main_loop BH and modifies the graph,

             * let's hold a reference to bs until we are done.

             *

             * IOThread doesn't have such a BH, and it is not safe to call

             * bdrv_unref without BQL, so skip doing it there.

             */

            bdrv_ref(bs);

        }

        waited |= bdrv_drain_recurse(bs, begin);

        if (in_main_loop) {

            bdrv_unref(bs);

        }

    }



    return waited;

}
