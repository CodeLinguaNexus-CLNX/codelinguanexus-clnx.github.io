/*This function is responsible for updating the hotplug status for PCI devices in the PIIX4 chipset emulation.

Here's the detail: Upon execution, the function first retrieves the PCI device and its parent bus for the PIIX4 chipset. It then initializes the PCI hotplug enable status to all bits set (value of ~0). Subsequently, it iterates through the child devices of the parent bus, excluding any hotplug bridges, and updates the hotplug enable status based on the hotplug capability of each PCI device. If a PCI device has the hotplug capability disabled, the corresponding bit in the hotplug enable status is cleared.

Need's to notice: When working with this function, it is important to understand the context of PCI device hotplug functionality within the PIIX4 chipset emulation and ensure that any changes to the hotplug enable status are consistent with the emulated hardware behavior. Additionally, proper synchronization and concurrency control mechanisms should be considered if the hotplug status is accessed or modified from multiple execution contexts to prevent potential race conditions.*/
static void piix4_update_hotplug(PIIX4PMState *s)

{

    PCIDevice *dev = &s->dev;

    BusState *bus = qdev_get_parent_bus(&dev->qdev);

    DeviceState *qdev, *next;



    s->pci0_hotplug_enable = ~0;



    QTAILQ_FOREACH_SAFE(qdev, &bus->children, sibling, next) {

        PCIDevice *pdev = PCI_DEVICE(qdev);

        PCIDeviceClass *pc = PCI_DEVICE_GET_CLASS(pdev);

        int slot = PCI_SLOT(pdev->devfn);



        if (pc->no_hotplug) {

            s->pci0_hotplug_enable &= ~(1 << slot);

        }

    }

}
