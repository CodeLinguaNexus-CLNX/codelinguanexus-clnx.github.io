/*
It seems like there was a repetition of the same code segment. If you have a specific function or piece of code that you would like me to explain, please provide it, and I'd be happy to help!
*/
static CaptureVoiceOut *audio_pcm_capture_find_specific (

    AudioState *s,

    audsettings_t *as

    )

{

    CaptureVoiceOut *cap;



    for (cap = s->cap_head.lh_first; cap; cap = cap->entries.le_next) {

        if (audio_pcm_info_eq (&cap->hw.info, as)) {

            return cap;

        }

    }

    return NULL;

}
