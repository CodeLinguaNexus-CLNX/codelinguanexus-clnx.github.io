/*This function is responsible for invalidating the cache associated with a BlockDriverState, potentially triggering cache refresh operations.

Here's the detail: When called, the function first checks if the BlockDriverState is associated with a driver and is inactive. If so, it updates the open_flags to remove the inactive flag, indicating that the BlockDriverState is now active. Depending on the driver's capability, it may call the driver's bdrv_invalidate_cache function to invalidate the cache, or recursively invoke bdrv_invalidate_cache on the underlying file's BlockDriverState. Any encountered errors are handled and propagated appropriately, and a refresh_total_sectors operation may be triggered to update the total sector count.

Need's to notice: Before using this function, it's important to ensure that the BlockDriverState and its associated driver are in a valid state. Additionally, understanding the implications of cache invalidation and sector count refresh on the BlockDriverState's operation is crucial for correct usage.*/
void bdrv_invalidate_cache(BlockDriverState *bs, Error **errp)

{

    Error *local_err = NULL;

    int ret;



    if (!bs->drv)  {

        return;

    }



    if (!(bs->open_flags & BDRV_O_INACTIVE)) {

        return;

    }

    bs->open_flags &= ~BDRV_O_INACTIVE;



    if (bs->drv->bdrv_invalidate_cache) {

        bs->drv->bdrv_invalidate_cache(bs, &local_err);

    } else if (bs->file) {

        bdrv_invalidate_cache(bs->file->bs, &local_err);

    }

    if (local_err) {

        bs->open_flags |= BDRV_O_INACTIVE;

        error_propagate(errp, local_err);

        return;

    }



    ret = refresh_total_sectors(bs, bs->total_sectors);

    if (ret < 0) {

        bs->open_flags |= BDRV_O_INACTIVE;

        error_setg_errno(errp, -ret, "Could not refresh total sector count");

        return;

    }

}
