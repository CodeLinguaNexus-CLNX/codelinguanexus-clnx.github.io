/*
This function is responsible for delivering a packet from the Matroska demuxer to the caller.

Here's the detail: The function begins by checking if there are pending packets in the MatroskaDemuxContext's packet queue. If there are packets available, it retrieves the first packet from the queue using memcpy, then frees the memory allocated for this packet using av_free. If there are remaining packets in the queue, the function shifts the packet pointers in the queue to remove the delivered packet, adjusts the memory allocation for the queue using av_realloc, and decrements the count of pending packets. If this was the last packet in the queue, the memory allocated for the queue is freed using av_freep.

If there are no packets available in the queue, the function returns -1 to indicate that no packet could be delivered.

Need's to notice: It is important to ensure that the memory management operations within this function, such as freeing and reallocating memory for the packet queue, are performed safely and do not lead to memory leaks or access violations. Additionally, the caller of this function should handle the returned packet appropriately and ensure proper memory management for the delivered packet.
*/
static int matroska_deliver_packet(MatroskaDemuxContext *matroska,

                                   AVPacket *pkt)

{

    if (matroska->num_packets > 0) {

        memcpy(pkt, matroska->packets[0], sizeof(AVPacket));

        av_free(matroska->packets[0]);

        if (matroska->num_packets > 1) {

            memmove(&matroska->packets[0], &matroska->packets[1],

                    (matroska->num_packets - 1) * sizeof(AVPacket *));

            matroska->packets =

                av_realloc(matroska->packets, (matroska->num_packets - 1) *

                           sizeof(AVPacket *));

        } else {

            av_freep(&matroska->packets);

        }

        matroska->num_packets--;

        return 0;

    }



    return -1;

}
