/*This function is responsible for performing color space conversion from YUV to YUVX format, utilizing a combination of provided filters and source data to generate the output pixel data.

Here's the detail: Upon invocation, the function applies the specified filters and source data to perform the color space conversion, with optimized processing for UV and alpha channels if the corresponding destination buffers are provided. It utilizes specific offsets and filter sizes for different channels to perform the conversion efficiently.

Needs to notice: When using this function, it's important to ensure that the input data, filters, and destination buffers are appropriately configured to match the expected YUV format and dimensions. Additionally, the conditional checks for UV and alpha channels should be examined to guarantee the correct handling of these channels based on the available destination buffers.*/
static void RENAME(yuv2yuvX)(SwsContext *c, const int16_t *lumFilter,

                             const int16_t **lumSrc, int lumFilterSize,

                             const int16_t *chrFilter, const int16_t **chrUSrc,

                             const int16_t **chrVSrc,

                             int chrFilterSize, const int16_t **alpSrc,

                             uint8_t *dest, uint8_t *uDest, uint8_t *vDest,

                             uint8_t *aDest, int dstW, int chrDstW)

{

    if (uDest) {

        x86_reg uv_off = c->uv_off;

        YSCALEYUV2YV12X(CHR_MMX_FILTER_OFFSET, uDest, chrDstW, 0)

        YSCALEYUV2YV12X(CHR_MMX_FILTER_OFFSET, vDest - uv_off, chrDstW + uv_off, uv_off)

    }

    if (CONFIG_SWSCALE_ALPHA && aDest) {

        YSCALEYUV2YV12X(ALP_MMX_FILTER_OFFSET, aDest, dstW, 0)

    }



    YSCALEYUV2YV12X(LUM_MMX_FILTER_OFFSET, dest, dstW, 0)

}
