/*
This function is responsible for performing a CPU reset and handling the boot information for an ARM CPU.

Here's the detail:
1. The function takes a pointer to an ARMCPU structure as an argument and retrieves the CPU state from it.
2. It then accesses the boot information from the CPU environment through the boot_info member.
3. If the boot information is available, it performs the following actions based on the information:
   - If the system is not running Linux, it sets the program counter (PC) to the entry point address provided in the boot info, aligning it to the nearest even address, and sets the ARM/Thumb mode based on the least significant bit of the entry point address.
   - If the system is running Linux, it distinguishes between the first CPU and secondary CPUs:
     - For the first CPU, it sets the PC to the loader start address and initializes the kernel arguments if the device tree blob (DTB) filename is not provided.
     - For secondary CPUs, it invokes the secondary_cpu_reset_hook function provided in the boot info.

Needs to notice:
- The function relies on the ARM CPU state and the boot information provided through the environment. Any modifications to the boot process or CPU reset behavior should consider the structure and content of the boot_info.
- Care should be taken when handling the initialization of kernel arguments and the entry point address, especially when dealing with multi-CPU systems and Linux booting.
- Understanding the overall boot process and the role of this function within it is essential for maintaining correct system initialization and CPU reset behavior.
*/
static void do_cpu_reset(void *opaque)

{

    ARMCPU *cpu = opaque;

    CPUARMState *env = &cpu->env;

    const struct arm_boot_info *info = env->boot_info;



    cpu_reset(CPU(cpu));

    if (info) {

        if (!info->is_linux) {

            /* Jump to the entry point.  */

            env->regs[15] = info->entry & 0xfffffffe;

            env->thumb = info->entry & 1;

        } else {

            if (CPU(cpu) == first_cpu) {

                env->regs[15] = info->loader_start;

                if (!info->dtb_filename) {

                    if (old_param) {

                        set_kernel_args_old(info);

                    } else {

                        set_kernel_args(info);

                    }

                }

            } else {

                info->secondary_cpu_reset_hook(cpu, info);

            }

        }

    }

}
