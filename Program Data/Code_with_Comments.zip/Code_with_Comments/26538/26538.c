/*This function is responsible for clearing the pending events in the sPAPRMachineState by removing and deallocating the associated event log entries.

Here's the detail: The function iterates through the list of pending events in the sPAPRMachineState using the QTAILQ_FOREACH macro. For each entry encountered, it removes the entry from the pending events queue using QTAILQ_REMOVE. Additionally, it frees the memory allocated for the extended log (if any) within the event entry and then frees the memory occupied by the event entry itself using the g_free function.

Need's to notice: It's important to ensure that the pending events queue and its entries are in a consistent state before calling this function to avoid data corruption. Additionally, proper memory deallocation is crucial to prevent memory leaks, and understanding the ownership and lifetime of the memory being freed is important to avoid potential use-after-free issues. Additionally, one should be aware of any potential side effects related to clearing pending events and ensure that this operation is performed at an appropriate point in the program flow.*/
void spapr_clear_pending_events(sPAPRMachineState *spapr)

{

    sPAPREventLogEntry *entry = NULL;



    QTAILQ_FOREACH(entry, &spapr->pending_events, next) {

        QTAILQ_REMOVE(&spapr->pending_events, entry, next);

        g_free(entry->extended_log);

        g_free(entry);

    }

}
