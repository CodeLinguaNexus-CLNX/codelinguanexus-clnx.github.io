/*
This function is responsible for writing the 'trak' atom/tag, which represents a single track in a MOV/MP4 file. It handles the construction of various sub-elements within the 'trak' atom, such as track header, edit list, media, UUID, SDP, and user data for the track.

Here's the detail of the function:
- It takes an AVIOContext 'pb' for writing data, a MOVMuxContext 'mov' containing the MOV/MP4 muxer context, a MOVTrack 'track' representing the track information, and an AVStream 'st' associated with the track.
- The function first records the current position in the output buffer using avio_tell and writes an initial 32-bit placeholder for the size of the 'trak' atom.
- It then proceeds to write the 'trak' fourCC code, and calls various helper functions to write sub-elements within the 'trak' atom based on the track mode and flags, such as tkhd, edts, tref, mdia, uuid, sdp, and user data tags.
- Special handling for PSP movies and video sample aspect ratio is performed, and appropriate tags are written as needed for the 'trak' atom.
- Finally, the function updates the size field of the 'trak' atom with the actual size of the written data.

Needs to notice:
- This function assumes that the provided AVIOContext 'pb', MOVMuxContext 'mov', MOVTrack 'track', and associated AVStream 'st' are properly initialized and configured before the function is called.
- The function is tailored to the specific requirements and constraints of the MOV/MP4 file format and may involve conditional writing of certain tags based on the track mode, flags, and associated data.
- Careful consideration should be given to the compatibility and requirements of the target MOV/MP4 file format when invoking this function.
*/
static int mov_write_trak_tag(AVIOContext *pb, MOVMuxContext *mov,

                              MOVTrack *track, AVStream *st)

{

    int64_t pos = avio_tell(pb);

    avio_wb32(pb, 0); /* size */

    ffio_wfourcc(pb, "trak");

    mov_write_tkhd_tag(pb, mov, track, st);

    if (track->mode == MODE_PSP || track->flags & MOV_TRACK_CTTS ||

        (track->entry && track->cluster[0].dts) ||

        is_clcp_track(track)) {

        if (mov->use_editlist)

            mov_write_edts_tag(pb, mov, track);  // PSP Movies require edts box

        else if ((track->entry && track->cluster[0].dts) || track->mode == MODE_PSP || is_clcp_track(track))

            av_log(mov->fc, AV_LOG_WARNING,

                   "Not writing any edit list even though one would have been required\n");

    }

    if (track->tref_tag)

        mov_write_tref_tag(pb, track);

    mov_write_mdia_tag(pb, mov, track);

    if (track->mode == MODE_PSP)

        mov_write_uuid_tag_psp(pb, track); // PSP Movies require this uuid box

    if (track->tag == MKTAG('r','t','p',' '))

        mov_write_udta_sdp(pb, track);

    if (track->mode == MODE_MOV) {

        if (track->enc->codec_type == AVMEDIA_TYPE_VIDEO) {

            double sample_aspect_ratio = av_q2d(st->sample_aspect_ratio);

            if ((0.0 != sample_aspect_ratio && 1.0 != sample_aspect_ratio)) {

                mov_write_tapt_tag(pb, track);

            }

        }

        if (is_clcp_track(track)) {

            mov_write_tapt_tag(pb, track);

        }

    }

    mov_write_track_udta_tag(pb, mov, st);

    return update_size(pb, pos);

}
