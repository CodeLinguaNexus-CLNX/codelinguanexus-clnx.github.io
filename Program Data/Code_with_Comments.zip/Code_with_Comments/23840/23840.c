/*
This function is responsible for executing a checkpoint transaction in the context of COLO (Cache-Offload on L2). Here's the breakdown:

1. It begins by sending a COLO_MESSAGE_CHECKPOINT_REQUEST to the destination file to initiate the checkpoint process.

2. It then receives a COLO_MESSAGE_CHECKPOINT_REPLY from the source file, confirming the checkpoint request.

3. The function resets the channel buffer and sets its usage to 0, preparing it for the upcoming data transfer.

4. It locks the I/O thread and forces the VM state to stop in the RUN_STATE_COLO mode, indicating the transition from running to a stopped state in the COLO context.

5. Block migration is disabled, and the VM state parameters are set accordingly. The function then initiates the VM state saving process with the destination file.

6. After sending the VM state data to the destination file, it confirms the successful receipt and loading of the VM state on the destination side.

7. Finally, it releases the I/O thread lock, starts the VM, and reports any encountered errors if applicable.

It's important to notice that this function orchestrates the entire process of initiating and completing a checkpoint transaction for the COLO feature, including sending messages, managing the VM state, and ensuring data transfer integrity. Additionally, it involves locking and unlocking the I/O thread and handling the transition of VM states between running and stopped modes within the COLO context.
*/
static int colo_do_checkpoint_transaction(MigrationState *s,

                                          QIOChannelBuffer *bioc,

                                          QEMUFile *fb)

{

    Error *local_err = NULL;

    int ret = -1;



    colo_send_message(s->to_dst_file, COLO_MESSAGE_CHECKPOINT_REQUEST,

                      &local_err);

    if (local_err) {





    colo_receive_check_message(s->rp_state.from_dst_file,

                    COLO_MESSAGE_CHECKPOINT_REPLY, &local_err);

    if (local_err) {



    /* Reset channel-buffer directly */

    qio_channel_io_seek(QIO_CHANNEL(bioc), 0, 0, NULL);

    bioc->usage = 0;



    qemu_mutex_lock_iothread();





    vm_stop_force_state(RUN_STATE_COLO);


    trace_colo_vm_state_change("run", "stop");










    /* Disable block migration */

    s->params.blk = 0;

    s->params.shared = 0;

    qemu_savevm_state_header(fb);

    qemu_savevm_state_begin(fb, &s->params);

    qemu_mutex_lock_iothread();

    qemu_savevm_state_complete_precopy(fb, false);




    qemu_fflush(fb);



    colo_send_message(s->to_dst_file, COLO_MESSAGE_VMSTATE_SEND, &local_err);

    if (local_err) {




     * We need the size of the VMstate data in Secondary side,

     * With which we can decide how much data should be read.


    colo_send_message_value(s->to_dst_file, COLO_MESSAGE_VMSTATE_SIZE,

                            bioc->usage, &local_err);

    if (local_err) {





    qemu_put_buffer(s->to_dst_file, bioc->data, bioc->usage);

    qemu_fflush(s->to_dst_file);

    ret = qemu_file_get_error(s->to_dst_file);

    if (ret < 0) {





    colo_receive_check_message(s->rp_state.from_dst_file,

                       COLO_MESSAGE_VMSTATE_RECEIVED, &local_err);

    if (local_err) {





    colo_receive_check_message(s->rp_state.from_dst_file,

                       COLO_MESSAGE_VMSTATE_LOADED, &local_err);

    if (local_err) {





    ret = 0;



    qemu_mutex_lock_iothread();

    vm_start();


    trace_colo_vm_state_change("stop", "run");



out:

    if (local_err) {

        error_report_err(local_err);


    return ret;
