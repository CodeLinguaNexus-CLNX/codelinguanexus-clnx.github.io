/*
This function is responsible for setting up the curses library environment for text-based user interface applications. It initializes the color pairs and configuration settings needed to create a visually appealing and interactive terminal interface.

Here's the detail: The function begins by initializing color pairs using a predefined set of default colors. It then configures the terminal settings to handle raw input, disable echoing, enable non-blocking input, and set up keyboard input for special keys. Lastly, it initializes color pairs for foreground and background colors to expand the color palette available for rendering in the terminal.

Need's to notice: When using this function, it is important to consider the terminal capabilities and ensure that the curses library is properly initialized. Additionally, understanding the color initialization process, terminal input handling, and the available color palette for the specific terminal environment is crucial for creating an effective and visually appealing text-based user interface.
*/static void curses_setup(void)

{

    int i, colour_default[8] = {

        COLOR_BLACK, COLOR_BLUE, COLOR_GREEN, COLOR_CYAN,

        COLOR_RED, COLOR_MAGENTA, COLOR_YELLOW, COLOR_WHITE,

    };



    /* input as raw as possible, let everything be interpreted

     * by the guest system */

    initscr(); noecho(); intrflush(stdscr, FALSE);

    nodelay(stdscr, TRUE); nonl(); keypad(stdscr, TRUE);

    start_color(); raw(); scrollok(stdscr, FALSE);



    for (i = 0; i < 64; i ++)

        init_pair(i, colour_default[i & 7], colour_default[i >> 3]);

}
