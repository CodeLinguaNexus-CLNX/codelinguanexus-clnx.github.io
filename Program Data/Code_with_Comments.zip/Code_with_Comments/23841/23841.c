/*
This function is responsible for disabling Message Signaled Interrupt eXtended (MSI-X) support for a QPCI (Quick PCI) device. Here's the breakdown:

1. It begins by asserting that MSI-X is currently enabled for the QPCI device.

2. It locates the MSI-X capability structure within the device's PCI configuration space and ensures that it is found at a non-zero address.

3. The function reads the MSI-X capability structure's flags and clears the enable bit to disable MSI-X support.

4. It unmaps the memory regions associated with the MSI-X table and pending bit array (PBA) using qpci_iounmap.

5. It updates the device's internal state to reflect that MSI-X is no longer enabled and sets the related memory region pointers to NULL.

It's important to notice that this function is responsible for cleanly disabling MSI-X support for the QPCI device by updating the device's configuration and releasing associated memory resources. Additionally, it ensures that the device's internal state accurately reflects the disabled MSI-X functionality, and it cleans up any memory mappings related to MSI-X.
*/
void qpci_msix_disable(QPCIDevice *dev)

{

    uint8_t addr;

    uint16_t val;



    g_assert(dev->msix_enabled);

    addr = qpci_find_capability(dev, PCI_CAP_ID_MSIX);

    g_assert_cmphex(addr, !=, 0);

    val = qpci_config_readw(dev, addr + PCI_MSIX_FLAGS);

    qpci_config_writew(dev, addr + PCI_MSIX_FLAGS,

                                                val & ~PCI_MSIX_FLAGS_ENABLE);



    qpci_iounmap(dev, dev->msix_table);

    qpci_iounmap(dev, dev->msix_pba);

    dev->msix_enabled = 0;

    dev->msix_table = NULL;

    dev->msix_pba = NULL;

}
