/*
This function is responsible for iterating through the guest physical memory blocks and retrieving the next page's details. Here's the detail:

- Upon invocation, the function uses the input parameters `blockptr`, `pfnptr`, `bufptr`, and `s` to manage the iteration and retrieve information about the next page in the guest physical memory.

- The function first checks if `block` is NULL, which indicates the start of the iteration. If so, it initializes `block` to the first element in the list of guest physical blocks and sets the page number (`pfnptr`) based on the target start address of the block. It also ensures that the buffer pointer (`bufptr`) is correctly set to the host address if provided.

- If `block` is not NULL, the function calculates the address for the next page and determines whether it falls within the current block. If it does, the buffer pointer (`buf`) is calculated accordingly. If the next page spans across blocks, it proceeds to the next block and updates the necessary pointers.

- The function then updates the buffer pointer (`bufptr`) if required and returns true to indicate that the next page details have been successfully retrieved. If there are no more blocks to iterate through, the function returns false.

Needs to notice:
- It is crucial to ensure that the input parameters (`blockptr`, `pfnptr`, `bufptr`, `s`) are correctly initialized before calling this function to ensure the proper iteration
*/
static char *pcibus_get_fw_dev_path(DeviceState *dev)

{

    PCIDevice *d = (PCIDevice *)dev;

    char path[50], name[33];

    int off;



    off = snprintf(path, sizeof(path), "%s@%x",

                   pci_dev_fw_name(dev, name, sizeof name),

                   PCI_SLOT(d->devfn));

    if (PCI_FUNC(d->devfn))

        snprintf(path + off, sizeof(path) + off, ",%x", PCI_FUNC(d->devfn));

    return strdup(path);

}
