/*
This function is responsible for seeking to a specific timestamp within a TMV (Text Media Video) format file in order to read the associated data chunks.

Here��s the detail of the function:
The tmv_read_seek function takes as input the AVFormatContext, stream_index, timestamp, and flags. It first checks if the stream_index is non-zero, in which case it returns -1 to indicate an error. If the stream_index is valid (zero in this case), it calculates the absolute position in the file to seek to based on the provided timestamp, audio and video chunk sizes, and padding. It then uses the avio_seek function to move the file pointer to the calculated position plus the size of the TMV header. Finally, it updates the stream_index in the TMVContext and returns 0 to indicate successful seeking.

Need��s to notice that the function specifically handles seeking within TMV format files and does not support seeking to different stream_indices. Additionally, it assumes a certain file structure and performs the seek operation accordingly.

*/static int tmv_read_seek(AVFormatContext* s, int stream_index,

                         int64_t timestamp, int flags)

{

    TMVContext *tmv = s->priv_data;

    int64_t pos;



    if (stream_index)

        return -1;



    pos = timestamp *

          (tmv->audio_chunk_size + tmv->video_chunk_size + tmv->padding);



    avio_seek(s->pb, pos + TMV_HEADER_SIZE, SEEK_SET);

    tmv->stream_index = 0;

    return 0;

}
