/*
This function is responsible for updating the mouse cursor definition within the context of a SimpleSpiceDisplay. Here's the detail:

1. The function takes in a DisplayChangeListener pointer (dcl) and a QEMUCursor pointer (c) as input parameters.
2. It retrieves the SimpleSpiceDisplay structure containing the DisplayChangeListener using the container_of macro.
3. It locks the display's mutex to ensure exclusive access while updating the cursor state.
4. If a new cursor (c) is provided, it retrieves the cursor data using the cursor_get function.
5. It updates the SimpleSpiceDisplay's cursor with the new cursor data and sets the hot spot coordinates (hot_x and hot_y) accordingly.
6. Any existing cursor update and movement data is freed to avoid memory leaks.
7. It generates a new cursor update packet using qemu_spice_create_cursor_update and assigns it to the display structure.
8. Finally, it releases the display's mutex to allow other operations to proceed.

Needs to notice:
Developers using this function should ensure that proper synchronization mechanisms are in place when calling this function to prevent potential data corruption in a multi-threaded environment. Additionally, memory management for the cursor data and cursor update packets should be handled appropriately to avoid memory leaks.
*/
static void display_mouse_define(DisplayChangeListener *dcl,

                                 QEMUCursor *c)

{

    SimpleSpiceDisplay *ssd = container_of(dcl, SimpleSpiceDisplay, dcl);



    qemu_mutex_lock(&ssd->lock);

    if (c) {

        cursor_get(c);

    }

    cursor_put(ssd->cursor);

    ssd->cursor = c;

    ssd->hot_x = c->hot_x;

    ssd->hot_y = c->hot_y;

    g_free(ssd->ptr_move);

    ssd->ptr_move = NULL;

    g_free(ssd->ptr_define);

    ssd->ptr_define = qemu_spice_create_cursor_update(ssd, c, 0);

    qemu_mutex_unlock(&ssd->lock);

}
