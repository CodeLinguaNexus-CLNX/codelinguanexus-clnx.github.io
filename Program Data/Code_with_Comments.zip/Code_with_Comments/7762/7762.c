/*
This function is responsible for determining whether a range of sectors is allocated within a chain of block driver states, starting from the top and going down to the base. Here's the detail: it checks whether the specified range of sectors is allocated in the topmost block driver state; if not, it iterates through the chain of block driver states to find the first state where the range is allocated, or it identifies the last unallocated range within the chain.

Needs to notice: The function relies on bdrv_co_is_allocated function to determine the allocation status of sectors within each block driver state. It is important to ensure that the input parameters such as top, base, sector_num, and nb_sectors are valid and appropriate for the block driver states being checked. Additionally, the function assumes a specific chain structure for block driver states and operates based on this assumption.
*/
static int coroutine_fn is_allocated_base(BlockDriverState *top,

                                          BlockDriverState *base,

                                          int64_t sector_num,

                                          int nb_sectors, int *pnum)

{

    BlockDriverState *intermediate;

    int ret, n;



    ret = bdrv_co_is_allocated(top, sector_num, nb_sectors, &n);

    if (ret) {

        *pnum = n;

        return ret;

    }



    /*

     * Is the unallocated chunk [sector_num, n] also

     * unallocated between base and top?

     */

    intermediate = top->backing_hd;



    while (intermediate != base) {

        int pnum_inter;



        ret = bdrv_co_is_allocated(intermediate, sector_num, nb_sectors,

                                   &pnum_inter);

        if (ret < 0) {

            return ret;

        } else if (ret) {

            *pnum = pnum_inter;

            return 0;

        }



        /*

         * [sector_num, nb_sectors] is unallocated on top but intermediate

         * might have

         *

         * [sector_num+x, nr_sectors] allocated.

         */

        if (n > pnum_inter) {

            n = pnum_inter;

        }



        intermediate = intermediate->backing_hd;

    }



    *pnum = n;

    return 1;

}
