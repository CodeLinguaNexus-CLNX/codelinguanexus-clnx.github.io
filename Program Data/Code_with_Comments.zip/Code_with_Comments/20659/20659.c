/**

This function is responsible for initializing the motion pixels decoder, including memory allocation, context setup, and table initialization.
Here��s the detail:
Upon invocation, the function first initializes the motion pixels context ��mp�� by obtaining a reference to the private data of the AVCodecContext ��avctx��. It then calculates the aligned width and height values for the video frame. Subsequently, it performs a check on the extradata size and logs an error if it is insufficient, returning an error code if so. Following this, the function proceeds to initialize the motion pixels tables, allocate and initialize memory for various data structures including the changes map, offset bits length, vertical pixel table, horizontal pixel table, and the decoder��s internal frame. Furthermore, it sets the pixel format to AV_PIX_FMT_RGB555 and initializes the frame defaults for the motion pixels decoder.
Needs to notice:
The function heavily relies on memory allocation and assumes the availability of required memory resources. Care should be taken to handle memory allocation failures and potential resource constraints. Additionally, users of this function should ensure that the extradata is appropriately set before invoking this function to avoid errors related to insufficient extradata size.
*/
static av_cold int mp_decode_init(AVCodecContext *avctx)

{

    MotionPixelsContext *mp = avctx->priv_data;

    int w4 = (avctx->width  + 3) & ~3;

    int h4 = (avctx->height + 3) & ~3;



    if(avctx->extradata_size < 2){

        av_log(avctx, AV_LOG_ERROR, "extradata too small\n");

        return AVERROR_INVALIDDATA;

    }



    motionpixels_tableinit();

    mp->avctx = avctx;

    ff_dsputil_init(&mp->dsp, avctx);

    mp->changes_map = av_mallocz(avctx->width * h4);

    mp->offset_bits_len = av_log2(avctx->width * avctx->height) + 1;

    mp->vpt = av_mallocz(avctx->height * sizeof(YuvPixel));

    mp->hpt = av_mallocz(h4 * w4 / 16 * sizeof(YuvPixel));



    avctx->pix_fmt = AV_PIX_FMT_RGB555;

    avcodec_get_frame_defaults(&mp->frame);

    return 0;

}