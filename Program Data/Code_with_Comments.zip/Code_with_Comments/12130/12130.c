/*
This function is responsible for conditionally printing debug messages based on the specified debug level. Here's the detail:

- The function takes a debug level and a format string followed by variable arguments, similar to the printf function.
- It checks if the specified debug level is less than or equal to the global debug level variable.
- If the condition is true, it initializes the variable argument list using va_start, then prints the formatted message to the standard error stream using vfprintf, and finally cleans up the variable argument list using va_end.

Some points to notice while using this function:
- The global debug level variable should be appropriately set to control the verbosity of debug messages. Messages with a level less than or equal to this debug level will be printed.
- Care should be taken to ensure that the format string and variable arguments are correctly provided to prevent security vulnerabilities such as format string exploits.
- Proper usage of this function involves setting the debug level appropriately and using it for debugging purposes in the codebase.
*/
dprint(int level, const char *fmt, ...)

{

    va_list args;



    if (level <= debug) {

        va_start(args, fmt);

        vfprintf(stderr, fmt, args);

        va_end(args);

    }

}
