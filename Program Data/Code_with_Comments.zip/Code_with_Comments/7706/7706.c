/*// Token: 200
// This function is responsible for handling the completion of asynchronous USB packets within the EHCI (Enhanced Host Controller Interface) implementation.

// Here's the detail:
// Upon receiving an asynchronous USB packet completion event on the specified USB port, the function retrieves the corresponding EHCIQueue and updates its asynchronous operation status to signify completion. If the port is in a powered-on state (as indicated by the PORTSC_POWNER flag), the completion is delegated to the companion USB port's complete() operation. Otherwise, it proceeds to mark the asynchronous queue as finished and sets the USB status based on the length of the completed packet.

// Need's to notice:
// When utilizing this function, it's important to ensure that the state and status of the EHCI queues and associated USB packets are managed consistently and accurately. Additionally, the behavior of the companion USB port's complete() operation, including any dependencies or interactions with the completion process, should be handled appropriately to maintain the integrity of USB packet processing within the EHCI implementation.*/
static void ehci_async_complete_packet(USBPort *port, USBPacket *packet)

{

    EHCIQueue *q;

    EHCIState *s = port->opaque;

    uint32_t portsc = s->portsc[port->index];



    if (portsc & PORTSC_POWNER) {

        USBPort *companion = s->companion_ports[port->index];

        companion->ops->complete(companion, packet);

        return;

    }



    q = container_of(packet, EHCIQueue, packet);

    trace_usb_ehci_queue_action(q, "wakeup");

    assert(q->async == EHCI_ASYNC_INFLIGHT);

    q->async = EHCI_ASYNC_FINISHED;

    q->usb_status = packet->len;

}
