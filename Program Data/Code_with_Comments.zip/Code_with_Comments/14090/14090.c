/*
This function, v9fs_link, is responsible for handling a 'link' operation in the 9P file system protocol. Here's the detailed breakdown of its operation:

- It unpacks the parameters from the V9fsPDU (Protocol Data Unit) opaque structure, including dfid (directory fid), oldfid (old file fid), and name (link name).
- The function then traces the 'link' operation for debugging or logging purposes.
- It retrieves the fid states for the directory fid (dfid) and the old file fid (oldfid) using the get_fid function, and if either fid is not found, it sets an appropriate error (ENOENT) and completes the operation.
- It invokes the v9fs_co_link function to perform the actual 'link' operation, passing in the relevant fid states and the link name.
- After the 'link' operation is complete, it frees the link name, releases the fid states, and completes the PDU with the appropriate error code.

Needs to notice:
- This function plays a critical role in handling the 'link' operation in the 9P file system protocol, facilitating the creation of hard links within the file system.
- It's vital to ensure that proper error handling is in place, including returning appropriate error codes and deallocating resources in case of any failure during the 'link' operation.
- The function's dependencies on other fid states and the v9fs_co_link function should be carefully managed and validated to maintain the integrity and consistency of the file system operations.
*/
static void v9fs_link(void *opaque)

{

    V9fsPDU *pdu = opaque;

    V9fsState *s = pdu->s;

    int32_t dfid, oldfid;

    V9fsFidState *dfidp, *oldfidp;

    V9fsString name;

    size_t offset = 7;

    int err = 0;



    pdu_unmarshal(pdu, offset, "dds", &dfid, &oldfid, &name);

    trace_v9fs_link(pdu->tag, pdu->id, dfid, oldfid, name.data);



    dfidp = get_fid(pdu, dfid);

    if (dfidp == NULL) {

        err = -ENOENT;

        goto out_nofid;

    }



    oldfidp = get_fid(pdu, oldfid);

    if (oldfidp == NULL) {

        err = -ENOENT;

        goto out;

    }

    err = v9fs_co_link(pdu, oldfidp, dfidp, &name);

    if (!err) {

        err = offset;

    }

out:

    put_fid(pdu, dfidp);

out_nofid:

    v9fs_string_free(&name);

    complete_pdu(s, pdu, err);

}
