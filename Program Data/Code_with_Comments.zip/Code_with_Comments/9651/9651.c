/*
This function is responsible for handling write configuration operations for a PCI Express (PCIe) to PCI bridge device.

Here's the detail:
1. It invokes the corresponding write configuration functions for the PCIe to PCI bridge device, such as pci_bridge_write_config, msi_write_config, and shpc_cap_write_config, passing the device instance, address, value, and length as parameters.
2. The pci_bridge_write_config function handles the write configuration operation specific to the PCI bridge functionality, updating the configuration space accordingly.
3. The msi_write_config function manages the write configuration operation related to Message Signaled Interrupts (MSI) for the PCIe to PCI bridge, modifying configurations as necessary to support MSI functionality.
4. The shpc_cap_write_config function deals with write configuration operations associated with the capabilities supported by the bridge device, making appropriate updates to the configuration space.

Needs to notice:
- Developers should ensure that any changes made to the PCIe to PCI bridge configuration writing functionality are compatible with the overall system and adhere to the PCIe and PCI bridge specifications.
- An understanding of PCIe, PCI, and bridge device specifications is crucial for making modifications or enhancements to this function.
- Proper testing should be conducted to validate that the write configuration operations are correctly handled and do not introduce any unintended side effects, especially in scenarios involving complex PCIe to PCI bridge configurations or interactions with other system components.
*/
static void pcie_pci_bridge_write_config(PCIDevice *d,

        uint32_t address, uint32_t val, int len)

{

    pci_bridge_write_config(d, address, val, len);

    msi_write_config(d, address, val, len);

    shpc_cap_write_config(d, address, val, len);

}
