/*This function is responsible for emulating the read Table of Contents (TOC) operation for a SCSI disk device.

Here's the detail: Upon invocation, the function extracts necessary parameters from the SCSIRequest and calculates the TOC based on the requested format, start track, and addressing mode (MSF). It then utilizes the appropriate method to read the TOC based on the specified format (0, 1, or 2), updating the outbuf accordingly. If an unsupported format is requested, the function returns an error code.

Need's to notice: When using this function, it's important to ensure that the SCSIRequest and associated parameters are valid and reflect a genuine read TOC operation. Additionally, understanding the structure and format of the TOC data and its interpretation by different formats is essential for correct emulation.*/
static int scsi_disk_emulate_read_toc(SCSIRequest *req, uint8_t *outbuf)

{

    SCSIDiskState *s = DO_UPCAST(SCSIDiskState, qdev, req->dev);

    int start_track, format, msf, toclen;

    uint64_t nb_sectors;



    msf = req->cmd.buf[1] & 2;

    format = req->cmd.buf[2] & 0xf;

    start_track = req->cmd.buf[6];

    bdrv_get_geometry(s->qdev.conf.bs, &nb_sectors);

    DPRINTF("Read TOC (track %d format %d msf %d)\n", start_track, format, msf >> 1);

    nb_sectors /= s->qdev.blocksize / 512;

    switch (format) {

    case 0:

        toclen = cdrom_read_toc(nb_sectors, outbuf, msf, start_track);

        break;

    case 1:

        /* multi session : only a single session defined */

        toclen = 12;

        memset(outbuf, 0, 12);

        outbuf[1] = 0x0a;

        outbuf[2] = 0x01;

        outbuf[3] = 0x01;

        break;

    case 2:

        toclen = cdrom_read_toc_raw(nb_sectors, outbuf, msf, start_track);

        break;

    default:

        return -1;

    }

    return toclen;

}
