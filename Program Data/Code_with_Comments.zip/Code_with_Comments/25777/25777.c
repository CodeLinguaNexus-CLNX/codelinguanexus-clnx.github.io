/*
Function explanation:
This function is responsible for performing vertical prediction and addition for an 8x8 block based on the input block and stride.

Details:
- The function takes input pixel data (_pix), a block of Discrete Cosine Transform coefficients (_block), and the stride as parameters.
- It casts the input data to the appropriate data types (pixel and dctcoef) and adjusts the stride value accordingly.
- The function then performs vertical prediction and addition for each pixel in the 8x8 block, utilizing the DCT coefficients to update the pixel values.
- The updated pixel values are written back into the input pixel array, taking into account the specified stride.

Points to note:
- Care should be taken to ensure that the input pixel data and DCT coefficients are properly initialized and aligned to prevent potential memory access violations.
- The usage of pointer arithmetic and array access within the loop should be carefully managed to avoid out-of-bounds access and ensure correct data manipulation.
- It is important to verify the correctness of the input stride value and its alignment to the pixel data to ensure accurate vertical addition and prediction.
- This function plays a crucial role in video codec processing and should be utilized in accordance with the specific requirements of the codec and the surrounding processing pipeline.
*/
static void FUNCC(pred8x8l_vertical_add)(uint8_t *_pix, const int16_t *_block,

                                         ptrdiff_t stride)

{

    int i;

    pixel *pix = (pixel*)_pix;

    const dctcoef *block = (const dctcoef*)_block;

    stride >>= sizeof(pixel)-1;

    pix -= stride;

    for(i=0; i<8; i++){

        pixel v = pix[0];

        pix[1*stride]= v += block[0];

        pix[2*stride]= v += block[8];

        pix[3*stride]= v += block[16];

        pix[4*stride]= v += block[24];

        pix[5*stride]= v += block[32];

        pix[6*stride]= v += block[40];

        pix[7*stride]= v += block[48];

        pix[8*stride]= v +  block[56];

        pix++;

        block++;

    }

}
