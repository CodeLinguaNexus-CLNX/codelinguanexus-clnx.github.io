/*
This function is responsible for determining the appropriate size for a memory access within a given memory region. It ensures that the access size falls within the supported range and is aligned based on the address, while also taking into account the minimum and maximum access sizes specified for the memory region.

Here's the detail:
- It takes a MemoryRegion, an access size 'l', and a hardware address 'addr' as parameters.
- It retrieves the minimum and maximum access sizes from the memory region's operations and ensures they fall within a default range if not explicitly specified.
- It adjusts the maximum access size based on the alignment of the address if the memory region does not support unaligned accesses.
- It bounds the access size by the maximum size and ensures it is at least as large as the minimum size.
- It then returns the adjusted access size.

Needs to notice:
- Ensure that the memory region's minimum and maximum access sizes are properly configured for the intended use case.
- Take into consideration whether unaligned accesses are supported by the memory region.
- Pay attention to potential incorrect usage in other parts of the code that might not support minimum access sizes larger than the remaining length.
*/
static int memory_access_size(MemoryRegion *mr, unsigned l, hwaddr addr)

{

    unsigned access_size_min = mr->ops->impl.min_access_size;

    unsigned access_size_max = mr->ops->impl.max_access_size;



    /* Regions are assumed to support 1-4 byte accesses unless

       otherwise specified.  */

    if (access_size_min == 0) {

        access_size_min = 1;

    }

    if (access_size_max == 0) {

        access_size_max = 4;

    }



    /* Bound the maximum access by the alignment of the address.  */

    if (!mr->ops->impl.unaligned) {

        unsigned align_size_max = addr & -addr;

        if (align_size_max != 0 && align_size_max < access_size_max) {

            access_size_max = align_size_max;

        }

    }



    /* Don't attempt accesses larger than the maximum.  */

    if (l > access_size_max) {

        l = access_size_max;

    }

    /* ??? The users of this function are wrong, not supporting minimums larger

       than the remaining length.  C.f. memory.c:access_with_adjusted_size.  */

    assert(l >= access_size_min);



    return l;

}
