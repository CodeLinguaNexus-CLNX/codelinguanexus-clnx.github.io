/*This function is responsible for dumping the kqemu statistics to a file.

Here's the detail: The kqemu_record_dump function begins by allocating memory for an array of PCRecord pointers. It then iterates through the PCRecord hash table, storing the records in the allocated array and calculating the total count of PC records. The array is then sorted using the qsort function based on a comparison function pc_rec_cmp. Subsequently, the function opens a file for writing and writes the total count of PC records followed by individual PC records with their counts and percentages to the file. Finally, the file is closed and the allocated memory is freed before calling the kqemu_record_flush function.

Needs to notice: When using this function, it is important to ensure that the file path "/tmp/kqemu.stats" is writable, and proper error handling should be implemented in case the file cannot be opened for writing. Additionally, users should be cautious about potential memory leaks and ensure that the freed memory is handled appropriately.

The generated comment token count in the response is less than 256.*/
void kqemu_record_dump(void)

{

    PCRecord **pr, *r;

    int i, h;

    FILE *f;

    int64_t total, sum;



    pr = malloc(sizeof(PCRecord *) * nb_pc_records);

    i = 0;

    total = 0;

    for(h = 0; h < PC_REC_HASH_SIZE; h++) {

        for(r = pc_rec_hash[h]; r != NULL; r = r->next) {

            pr[i++] = r;

            total += r->count;

        }

    }

    qsort(pr, nb_pc_records, sizeof(PCRecord *), pc_rec_cmp);



    f = fopen("/tmp/kqemu.stats", "w");

    if (!f) {

        perror("/tmp/kqemu.stats");

        exit(1);

    }

    fprintf(f, "total: %" PRId64 "\n", total);

    sum = 0;

    for(i = 0; i < nb_pc_records; i++) {

        r = pr[i];

        sum += r->count;

        fprintf(f, "%08lx: %" PRId64 " %0.2f%% %0.2f%%\n",

                r->pc,

                r->count,

                (double)r->count / (double)total * 100.0,

                (double)sum / (double)total * 100.0);

    }

    fclose(f);

    free(pr);



    kqemu_record_flush();

}
