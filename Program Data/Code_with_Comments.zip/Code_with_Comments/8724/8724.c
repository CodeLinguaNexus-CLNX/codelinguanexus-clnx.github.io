/*
This function is responsible for processing the deletion of a submission queue (SQ) in an NVMe (Non-Volatile Memory Express) storage controller context, including canceling pending requests, updating associated completion queue (CQ), and freeing resources.

Here's the detail of the function: The function begins by extracting the queue identifier from the NvmeCmd parameter and performing validation checks on the identifier. Subsequently, it proceeds to cancel any pending I/O requests associated with the SQ and, if the associated CQ is valid, updates the CQ and reassigns the requests to the deleted SQ. Finally, it frees the resources allocated to the SQ in the NVMe controller context.

Need's to notice that this function plays a critical role in the removal of an SQ in the NVMe context and involves intricate operations related to pending I/O requests, associated completion queues, and resource deallocation. It is essential to understand the impact of deleting an SQ on the overall functioning of the NVMe controller and the related storage operations.
*/static uint16_t nvme_del_sq(NvmeCtrl *n, NvmeCmd *cmd)

{

    NvmeDeleteQ *c = (NvmeDeleteQ *)cmd;

    NvmeRequest *req, *next;

    NvmeSQueue *sq;

    NvmeCQueue *cq;

    uint16_t qid = le16_to_cpu(c->qid);



    if (!qid || nvme_check_sqid(n, qid)) {

        return NVME_INVALID_QID | NVME_DNR;

    }



    sq = n->sq[qid];

    while (!QTAILQ_EMPTY(&sq->out_req_list)) {

        req = QTAILQ_FIRST(&sq->out_req_list);

        assert(req->aiocb);

        blk_aio_cancel(req->aiocb);

    }

    if (!nvme_check_cqid(n, sq->cqid)) {

        cq = n->cq[sq->cqid];

        QTAILQ_REMOVE(&cq->sq_list, sq, entry);



        nvme_post_cqes(cq);

        QTAILQ_FOREACH_SAFE(req, &cq->req_list, entry, next) {

            if (req->sq == sq) {

                QTAILQ_REMOVE(&cq->req_list, req, entry);

                QTAILQ_INSERT_TAIL(&sq->req_list, req, entry);

            }

        }

    }



    nvme_free_sq(sq, n);

    return NVME_SUCCESS;

}
