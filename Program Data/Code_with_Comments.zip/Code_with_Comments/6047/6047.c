/*
This function is responsible for peeking at the TLS handshake data in a VNC session to determine if it is a TLS Websocket connection. Here's the detail: Initially, it checks if the session is not already established. If not, it peeks at the incoming data to identify if it resembles the TLS handshake protocol. If a TLS Websocket connection is recognized, it sets up the TLS client and initiates the TLS handshake. Otherwise, it proceeds with the regular handshake read process.

Needs to notice that this function is essential for detecting TLS Websocket connections and initiating the TLS handshake process in VNC sessions. It involves checking the incoming data for specific patterns indicative of TLS handshakes and managing the transition to TLS-secured communication.
*/

void vncws_tls_handshake_peek(void* opaque)

{

    VncState *vs = opaque;

    long ret;



    if (!vs->ws_tls.session) {

        char peek[4];

        ret = qemu_recv(vs->csock, peek, sizeof(peek), MSG_PEEK);

        if (ret && (strncmp(peek, "\x16", 1) == 0

                    || strncmp(peek, "\x80", 1) == 0)) {

            VNC_DEBUG("TLS Websocket connection recognized");

            vnc_tls_client_setup(vs, 1);

            vncws_start_tls_handshake(vs);

        } else {

            vncws_handshake_read(vs);

        }

    } else {

        qemu_set_fd_handler2(vs->csock, NULL, vncws_handshake_read, NULL, vs);

    }

}
