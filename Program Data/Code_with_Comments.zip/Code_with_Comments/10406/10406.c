/*
This function is responsible for initializing the PCI bus for a PREP (PowerPC Reference Platform) architecture. Here's the breakdown of the function:

- It allocates and initializes a PREPPCIState structure, representing the state of the PREP PCI configuration space.

- It registers I/O port handlers for configuration address and data registers, as well as physical memory for PCI I/O space.

- A PCI host bridge device is registered with the PCI bus, representing the host bridge for the PREP platform.

- Various configuration parameters for the PCI host bridge device are initialized, such as vendor and device IDs, class codes, and other configuration space registers.

- Finally, the function returns a pointer to the initialized PCI bus.

Needs to notice:
- Platform specificity: This function is specific to the PREP architecture and initializes the PCI bus and host bridge accordingly. Modifications may be required for different architectures.
- I/O port and memory registration: The function registers I/O port handlers and physical memory for PCI I/O space, which may conflict with existing registrations and should be carefully managed.
- Device configuration: The configuration settings for the PCI host bridge device are hardcoded in the function. For a more flexible and dynamic configuration, these settings may need to be modified or exposed through an external interface.
- Static memory allocation: The allocation of the PREPPCIState structure using qemu_mallocz implies a fixed, predetermined size. This may limit the scalability of the PCI bus initialization process.

Overall, this function serves as the entry point for setting up the PCI bus and related devices for the PREP platform and serves as a crucial component for system emulation on this architecture.
*/
PCIBus *pci_prep_init(qemu_irq *pic)

{

    PREPPCIState *s;

    PCIDevice *d;

    int PPC_io_memory;



    s = qemu_mallocz(sizeof(PREPPCIState));

    s->bus = pci_register_bus(prep_set_irq, prep_map_irq, pic, 0, 2);



    register_ioport_write(0xcf8, 4, 4, pci_prep_addr_writel, s);

    register_ioport_read(0xcf8, 4, 4, pci_prep_addr_readl, s);



    register_ioport_write(0xcfc, 4, 1, pci_host_data_writeb, s);

    register_ioport_write(0xcfc, 4, 2, pci_host_data_writew, s);

    register_ioport_write(0xcfc, 4, 4, pci_host_data_writel, s);

    register_ioport_read(0xcfc, 4, 1, pci_host_data_readb, s);

    register_ioport_read(0xcfc, 4, 2, pci_host_data_readw, s);

    register_ioport_read(0xcfc, 4, 4, pci_host_data_readl, s);



    PPC_io_memory = cpu_register_io_memory(0, PPC_PCIIO_read,

                                           PPC_PCIIO_write, s);

    cpu_register_physical_memory(0x80800000, 0x00400000, PPC_io_memory);



    /* PCI host bridge */

    d = pci_register_device(s->bus, "PREP Host Bridge - Motorola Raven",

                            sizeof(PCIDevice), 0, NULL, NULL);

    d->config[0x00] = 0x57; // vendor_id : Motorola

    d->config[0x01] = 0x10;

    d->config[0x02] = 0x01; // device_id : Raven

    d->config[0x03] = 0x48;

    d->config[0x08] = 0x00; // revision

    d->config[0x0A] = 0x00; // class_sub = pci host

    d->config[0x0B] = 0x06; // class_base = PCI_bridge

    d->config[0x0C] = 0x08; // cache_line_size

    d->config[0x0D] = 0x10; // latency_timer

    d->config[0x0E] = 0x00; // header_type

    d->config[0x34] = 0x00; // capabilities_pointer



    return s->bus;

}
