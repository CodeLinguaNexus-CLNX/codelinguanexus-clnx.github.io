/*
This function is responsible for initializing an audio resampling context using the specified parameters and generating the resampling filter. Here's the detailed breakdown of the function:

- It allocates and clears memory for the AVResampleContext structure using av_mallocz.
- It calculates the resampling factor based on the output rate, input rate, and cutoff frequency.
- It computes the phase count based on the phase shift parameter.
- It initializes various fields in the resampling context, including phase shift, linear flag, filter length, filter bank, source and destination increments, and the initial index.

Details:
- The function dynamically allocates memory for the resampling context and the filter bank based on the provided parameters, ensuring that the memory is suitably set for the resampling process.
- It computes the resampling factor based on the input and output rates along with the specified cutoff frequency, and determines the length of the resampling filter bank based on the calculated factor and the provided filter size.
- The function then constructs the filter bank and handles the circular buffer wraparound in the filter bank.
- It sets the source and destination increments and determines the initial index based on the calculated phase count and filter length.

Needs to notice:
- The function performs several calculations based on the input parameters, and it assumes valid input values. Error handling for invalid or extreme input parameters is not explicitly presented in this function.
- It provides a warning against non-integer filter length by using the ceil function, ensuring that the filter length is at least 1.
- Memory allocation and deallocation are handled internally, but it's essential to ensure proper memory management and potential error handling in a broader context when using this function.
- The function assumes that the input parameters accurately represent the audio characteristics and resampling requirements, and does not include explicit parameter validation or error checking within the function.
*/
AVResampleContext *av_resample_init(int out_rate, int in_rate, int filter_size, int phase_shift, int linear, double cutoff){

    AVResampleContext *c= av_mallocz(sizeof(AVResampleContext));

    double factor= FFMIN(out_rate * cutoff / in_rate, 1.0);

    int phase_count= 1<<phase_shift;

    

    c->phase_shift= phase_shift;

    c->phase_mask= phase_count-1;

    c->linear= linear;



    c->filter_length= FFMAX(ceil(filter_size/factor), 1);

    c->filter_bank= av_mallocz(c->filter_length*(phase_count+1)*sizeof(FELEM));

    av_build_filter(c->filter_bank, factor, c->filter_length, phase_count, 1<<FILTER_SHIFT, 1);

    memcpy(&c->filter_bank[c->filter_length*phase_count+1], c->filter_bank, (c->filter_length-1)*sizeof(FELEM));

    c->filter_bank[c->filter_length*phase_count]= c->filter_bank[c->filter_length - 1];



    c->src_incr= out_rate;

    c->ideal_dst_incr= c->dst_incr= in_rate * phase_count;

    c->index= -phase_count*((c->filter_length-1)/2);



    return c;

}
