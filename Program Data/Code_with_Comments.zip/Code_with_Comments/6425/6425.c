/*
The function is responsible for saving the state of the virtual machine to the provided QEMU file, including handling the initialization, iteration, and finalization of the state-saving process.

Here's the detail:
The function initializes a MigrationState and sets up the migration parameters with the destination file. It then performs the necessary operations to save the VM state, including unlocking the I/O thread, saving the VM state header, iterating through the state-saving process, and handling any errors that may occur during the process. Finally, it cleans up and returns the result of the state-saving operation.

Need's to notice:
When modifying or extending the functionality of this state-saving function, developers need to ensure that the VM state is correctly and completely saved to the provided QEMU file, handling any potential errors or exceptions that may arise during the process. Care should be taken to maintain the integrity and consistency of the saved VM state, and to properly clean up any resources used in the process to avoid memory leaks or other issues.
*/

static int qemu_savevm_state(QEMUFile* f, Error** errp)

{

    int ret;

    MigrationParams params = {

        .blk = 0,

        .shared = 0

    };

    MigrationState *ms = migrate_init(&params);

    ms->to_dst_file = f;



    if (qemu_savevm_state_blocked(errp)) {

        return -EINVAL;

    }



    qemu_mutex_unlock_iothread();

    qemu_savevm_state_header(f);

    qemu_savevm_state_begin(f, &params);

    qemu_mutex_lock_iothread();



    while (qemu_file_get_error(f) == 0) {

        if (qemu_savevm_state_iterate(f, false) > 0) {

            break;

        }

    }



    ret = qemu_file_get_error(f);

    if (ret == 0) {

        qemu_savevm_state_complete_precopy(f, false);

        ret = qemu_file_get_error(f);

    }

    qemu_savevm_state_cleanup();

    if (ret != 0) {

        error_setg_errno(errp, -ret, "Error while writing VM state");

    }

    return ret;

}
