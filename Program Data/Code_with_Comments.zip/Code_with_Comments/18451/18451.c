/*
This function is responsible for sending High Efficiency Video Coding (HEVC) frames over the Real-time Transport Protocol (RTP). 

Here's the detail:
The function takes in an AVFormatContext pointer, which contains information about the format of the input video stream, and the frame_buf, which is a pointer to the buffer containing the HEVC frame data. The frame_size parameter indicates the size of the frame data in bytes. The RTPMuxContext structure, stored in the priv_data field of the AVFormatContext, is used to store RTP-specific information.

The function starts by setting the timestamp for the RTP packet to the current timestamp in the RTPMuxContext. Then, the buf_ptr and buf_end pointers are initialized to the start and end of the frame buffer, respectively.

Depending on the nal_length_size field of the RTPMuxContext, the function chooses the start code finder function to use. If nal_length_size is non-zero, ff_avc_mp4_find_startcode is used, otherwise, ff_avc_find_startcode is used. These functions are responsible for finding the start code of the NAL unit in the frame buffer.

The function then enters a loop where it finds the next NAL unit in the frame buffer and sends it as a separate packet using the nal_send() function. The next_NAL_unit pointer is updated to the position of the start code of the next NAL unit, and buf_ptr is set to the next_NAL_unit pointer.

Finally, the flush_buffered() function is called to send any remaining buffered data and flush the buffer.

Needs to notice:
- The input AVFormatContext and frame_buf parameters should be valid and properly allocated.
- The rtp_ctx pointer in the AVFormatContext should be initialized with appropriate RTP settings before calling this function.
- The nal_send() and flush_buffered() functions should be defined and implemented separately.
- The frame_buf should contain valid HEVC frame data.
- The function assumes that the NAL units in the frame buffer are properly formatted with start codes.
- The function assumes proper handling of RTP packetization and transmission outside the scope of this function.
*/
void ff_rtp_send_hevc(AVFormatContext *ctx, const uint8_t *frame_buf, int frame_size)

{

    const uint8_t *next_NAL_unit;

    const uint8_t *buf_ptr, *buf_end = frame_buf + frame_size;

    RTPMuxContext *rtp_ctx = ctx->priv_data;



    /* use the default 90 KHz time stamp */

    rtp_ctx->timestamp = rtp_ctx->cur_timestamp;

    rtp_ctx->buf_ptr   = rtp_ctx->buf;



    if (rtp_ctx->nal_length_size)

        buf_ptr = ff_avc_mp4_find_startcode(frame_buf, buf_end, rtp_ctx->nal_length_size) ? frame_buf : buf_end;

    else

        buf_ptr = ff_avc_find_startcode(frame_buf, buf_end);



    /* find all NAL units and send them as separate packets */

    while (buf_ptr < buf_end) {

        if (rtp_ctx->nal_length_size) {

            next_NAL_unit = ff_avc_mp4_find_startcode(buf_ptr, buf_end, rtp_ctx->nal_length_size);

            if (!next_NAL_unit)

                next_NAL_unit = buf_end;



            buf_ptr += rtp_ctx->nal_length_size;

        } else {

            while (!*(buf_ptr++))

                ;

            next_NAL_unit = ff_avc_find_startcode(buf_ptr, buf_end);

        }

        /* send the next NAL unit */

        nal_send(ctx, buf_ptr, next_NAL_unit - buf_ptr, next_NAL_unit == buf_end);



        /* jump to the next NAL unit */

        buf_ptr = next_NAL_unit;

    }

    flush_buffered(ctx, 1);

}
