/*
Function explanation:

This function is responsible for handling changes related to the VNC (Virtual Network Computing) server, including setting the password or initiating the VNC server on a specified target.

Details:
- The do_change_vnc function takes two parameters: "target", which represents the target VNC server, and "arg", which represents the argument associated with the change (e.g., password).
- If the "target" is related to the password ("passwd" or "password"), the function either takes the provided password as the argument or prompts the user to input the password. It then attempts to set the VNC server password using the provided or input password.
- If the "target" is not related to the password, the function attempts to start the VNC server on the specified target.
- The function relies on the vnc_display_password and vnc_display_open functions to set the VNC server password and initiate the VNC server, respectively.

Needs to notice:
- When using this function to handle VNC server changes, it's vital to ensure that the "target" and "arg" parameters are correctly specified and aligned with the intended VNC server operation.
- Handling of password input, including potential limitations on the password length or format, should be considered to ensure proper password setting for the VNC server.
- The behavior of the vnc_display_password and vnc_display_open functions, including their error-handling and return values, should be carefully managed to respond to potential issues in setting the password or initiating the VNC server.
- Access control and security considerations, especially when setting the VNC server password, should be prioritized to prevent unauthorized access and ensure the confidentiality of the VNC server.

In summary, the do_change_vnc function facilitates changes to the VNC server, such as setting the password or initiating the server on a specified target. When utilizing this function, attention to parameter validity, password handling, and error management in VNC server operations is fundamental for ensuring proper VNC server configuration and security.
*/

static void do_change_vnc(const char* target, const char* arg)

{

    if (strcmp(target, "passwd") == 0 ||

	strcmp(target, "password") == 0) {

	char password[9];

	if (arg) {

	    strncpy(password, arg, sizeof(password));

	    password[sizeof(password) - 1] = '\0';

	} else

	    monitor_readline("Password: ", 1, password, sizeof(password));

	if (vnc_display_password(NULL, password) < 0)

	    term_printf("could not set VNC server password\n");

    } else {

	if (vnc_display_open(NULL, target) < 0)

	    term_printf("could not start VNC server on %s\n", target);

    }

}
