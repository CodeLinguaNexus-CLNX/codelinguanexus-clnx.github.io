/*
This function is responsible for writing data to a virtual block device managed by the BlockDriverState structure, taking into account the specifics of the underlying VHD (Virtual Hard Disk) format. It handles the write operation based on the VHD type and manages the allocation and writing of data to the virtual disk.

Here's the detail:
The function begins by extracting the BDRVVPCState structure from the opaque field of the BlockDriverState. It then proceeds to check the VHD type in the footer and decides whether to perform a direct write operation to the underlying physical file or to manage the allocation and writing in a granular manner. For non-fixed VHD types, it iterates through the sectors, allocates blocks as needed, and writes the data using bdrv_pwrite. It ensures that the data is written in sectors of BDRV_SECTOR_SIZE and handles the iteration until all sectors are processed.

Needs to notice:
1. The function assumes valid input for the BlockDriverState pointer 'bs' and the buffer pointer 'buf', as well as the integrity of the underlying structures and data.
2. Proper understanding of the VHD format and the virtual block device management is crucial for utilizing this function effectively within the context of disk management.
3. Care should be taken to handle potential errors during block allocation and writing to ensure the integrity of the virtual disk.
*/
static int vpc_write(BlockDriverState *bs, int64_t sector_num,

    const uint8_t *buf, int nb_sectors)

{

    BDRVVPCState *s = bs->opaque;

    int64_t offset;

    int64_t sectors, sectors_per_block;

    int ret;

    VHDFooter *footer =  (VHDFooter *) s->footer_buf;



    if (cpu_to_be32(footer->type) == VHD_FIXED) {

        return bdrv_write(bs->file, sector_num, buf, nb_sectors);

    }

    while (nb_sectors > 0) {

        offset = get_sector_offset(bs, sector_num, 1);



        sectors_per_block = s->block_size >> BDRV_SECTOR_BITS;

        sectors = sectors_per_block - (sector_num % sectors_per_block);

        if (sectors > nb_sectors) {

            sectors = nb_sectors;

        }



        if (offset == -1) {

            offset = alloc_block(bs, sector_num);

            if (offset < 0)

                return -1;

        }



        ret = bdrv_pwrite(bs->file, offset, buf, sectors * BDRV_SECTOR_SIZE);

        if (ret != sectors * BDRV_SECTOR_SIZE) {

            return -1;

        }



        nb_sectors -= sectors;

        sector_num += sectors;

        buf += sectors * BDRV_SECTOR_SIZE;

    }



    return 0;

}
