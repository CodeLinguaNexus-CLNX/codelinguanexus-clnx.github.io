/*
This function is responsible for detaching a USB device from the USB bus. Here's the detail:

- It takes a pointer to the USBDevice structure representing the device to be detached as an input parameter.
- Inside the function, it first retrieves the USB bus where the device is attached using the usb_bus_from_device function.
- It then checks if the device is already detached. If so, it reports an error and returns -1.
- If the device is attached, it decrements the attached counter for the device.
- It iterates through the list of used USB ports on the bus to find the specific port to which the device is connected.
- Upon finding the port, it removes it from the used list and decrements the count of used ports on the bus.
- It then calls the usb_attach function to update the port's status to indicate that it is no longer connected to any device.
- Finally, it inserts the port into the list of free ports on the bus and increments the count of free ports.

Needs to notice:
- This function assumes that the USBDevice structure represents a valid and attached USB device.
- It directly manipulates the used and free lists of USB ports on the bus, so it should be used with caution to avoid inconsistencies in the bus state.
- Error handling and edge cases, such as detaching an already detached device, are considered within the function to ensure proper behavior.

Please note that this explanation is based on the provided code snippet and the assumed context within the codebase. If additional context or specific usage details are needed, feel free to ask for further clarification.
*/

int usb_device_detach(USBDevice* dev)

{

    USBBus *bus = usb_bus_from_device(dev);

    USBPort *port;



    if (!dev->attached) {

        error_report("Error: tried to detach unattached usb device %s\n",

                dev->product_desc);

        return -1;

    }

    dev->attached--;



    QTAILQ_FOREACH(port, &bus->used, next) {

        if (port->dev == dev)

            break;

    }

    assert(port != NULL);



    QTAILQ_REMOVE(&bus->used, port, next);

    bus->nused--;



    usb_attach(port, NULL);



    QTAILQ_INSERT_TAIL(&bus->free, port, next);

    bus->nfree++;

    return 0;

}
