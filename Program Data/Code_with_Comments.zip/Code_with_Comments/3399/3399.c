/*
This function is responsible for unrealizing a VirtIO SCSI device. It calls the virtio_scsi_common_unrealize function to handle the common unrealization process for VirtIO SCSI devices.

Here��s the detail of the function:
The virtio_scsi_device_unrealize function takes in the device state and an error pointer as parameters. It internally calls the virtio_scsi_common_unrealize function, which handles the common steps required to unrealize a VirtIO SCSI device, such as cleaning up resources and notifying the guest OS about the device removal.

Need��s to notice:
The function does not directly perform the unrealization process but delegates it to the virtio_scsi_common_unrealize function. It��s important to ensure that the device state and error pointer are properly handled before and after calling this function to avoid potential issues during device unrealization.
*/static void virtio_scsi_device_unrealize(DeviceState* dev, Error** errp)
{
    virtio_scsi_common_unrealize(dev, errp);
}