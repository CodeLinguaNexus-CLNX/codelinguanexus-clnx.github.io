/*
This function is responsible for asynchronously reading and processing events from a block device in the RBD (Ceph Rados Block Device) driver of the QEMU emulator.

Here's the detail:
The function continuously reads a specific size of data from the file descriptor associated with the RBD block device. The read data is then interpreted as an event to be processed. Upon successfully reading the required amount of data, the function triggers the completion of the asynchronous I/O operation associated with the received event by calling qemu_rbd_complete_aio.

Needs to notice:
- This function is designed for asynchronous event handling within the RBD driver of the QEMU emulator, facilitating non-blocking I/O operations for RBD block devices.
- The function specifically handles the reception and processing of events sent from non-QEMU threads, indicating its role in handling inter-thread communication for RBD device events.
- Developers utilizing or modifying this function should be familiar with the asynchronous I/O mechanisms and thread synchronization techniques employed within the QEMU RBD driver. Understanding the specific event types and their processing logic is crucial when extending or debugging the event handling functionality.
- It's essential to be aware of the underlying operating system's behavior related to asynchronous I/O and signal handling, as the function utilizes read in a loop and handles EINTR errors, which are commonly associated with interrupted system calls.
*/
static void qemu_rbd_aio_event_reader(void *opaque)

{

    BDRVRBDState *s = opaque;



    ssize_t ret;



    do {

        char *p = (char *)&s->event_rcb;



        /* now read the rcb pointer that was sent from a non qemu thread */

        ret = read(s->fds[RBD_FD_READ], p + s->event_reader_pos,

                   sizeof(s->event_rcb) - s->event_reader_pos);

        if (ret > 0) {

            s->event_reader_pos += ret;

            if (s->event_reader_pos == sizeof(s->event_rcb)) {

                s->event_reader_pos = 0;

                qemu_rbd_complete_aio(s->event_rcb);

            }

        }

    } while (ret < 0 && errno == EINTR);

}
