/**
 * This function is responsible for initializing the CPU device for the SPARC architecture, configuring its parameters and registering necessary interrupts.
 *
 * Here's the detail: Upon receiving the CPU model, identifier, PROM address, and CPU interrupts, the function initializes the SPARC CPU state, sets its identifier, registers appropriate reset handlers, and allocates interrupts based on defined maximum priority levels (PILs) to enable proper functioning of the SPARC CPU within the QEMU environment.
 *
 * Need's to notice: It is crucial to ensure that the provided CPU model is supported and correctly initialized, and that the CPU identifiers and interrupt allocations are consistent with the system configuration. Additionally, the function's behavior for primary and secondary CPUs should be carefully considered to guarantee proper initialization and reset handling for each CPU instance.
 */
static void cpu_devinit(const char *cpu_model, unsigned int id,

                        uint64_t prom_addr, qemu_irq **cpu_irqs)

{

    CPUState *cs;

    SPARCCPU *cpu;

    CPUSPARCState *env;



    cpu = SPARC_CPU(cpu_generic_init(TYPE_SPARC_CPU, cpu_model));

    if (cpu == NULL) {

        fprintf(stderr, "qemu: Unable to find Sparc CPU definition\n");

        exit(1);

    }

    env = &cpu->env;



    cpu_sparc_set_id(env, id);

    if (id == 0) {

        qemu_register_reset(main_cpu_reset, cpu);

    } else {

        qemu_register_reset(secondary_cpu_reset, cpu);

        cs = CPU(cpu);

        cs->halted = 1;

    }

    *cpu_irqs = qemu_allocate_irqs(cpu_set_irq, cpu, MAX_PILS);

    env->prom_addr = prom_addr;

}
