/*
This function, pci_apb_ioreadl, is responsible for performing a 32-bit input operation from a memory-mapped I/O region within the context of a PCI device. Here's the detail:

- The function takes opaque as a pointer to device-specific data and addr as the target physical address from which to perform the input operation.

- It reads a 32-bit value from the input/output port using the cpu_inl function, which reads a 32-bit little-endian word from an I/O port.

- Before returning the read value, the function byte-swaps the result using the bswap32 function. This is done to ensure that the endianness of the value matches the host system's endianness, as the I/O operation may involve data transfer between systems with different endianness.

Needs to notice:
- This function is tailored for handling input operations from memory-mapped I/O regions specific to PCI devices.
- Byte-swapping is performed to ensure consistency in endianness, which is crucial when working in a heterogeneous system environment.
- It's important to verify that the cpu_inl and bswap32 functions are correctly implemented and suitable for the target platform, ensuring proper handling of I/O operations and endianness conversion.
*/
static uint32_t pci_apb_ioreadl (void *opaque, target_phys_addr_t addr)

{

    uint32_t val;



    val = bswap32(cpu_inl(addr & IOPORTS_MASK));

    return val;

}
