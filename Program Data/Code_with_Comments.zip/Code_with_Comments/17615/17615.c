/**
 * This function is responsible for converting the UYVY format to RGB32 using AltiVec optimizations.
 */

 /**
  * Here's the detail:
  * This function processes the input UYVY data, separating the luminance (Y) and chrominance (U, V) components using AltiVec vector operations. It then applies a color space conversion function (cvtyuvtoRGB) to convert the YUV values to RGB components. The resulting RGB components are packed into the RGB32 format using vector operations, and then stored in the output planes. This process is repeated for the specified slice of the input data, utilizing AltiVec vector operations for optimized processing.
  */

  /**
   * Need's to notice:
   * When utilizing this function, ensure the correct initialization and handling of the input and output data structures, including the input planes, strides, and slice parameters. Validate the input data's format and integrity to ensure proper processing. Additionally, exercise caution during the use of AltiVec vector operations and ensure compatibility with the target architecture. Verify that the cvtyuvtoRGB function and the output RGBA function behave as expected in the context of the overall image processing pipeline.
   */
static int altivec_uyvy_rgb32 (SwsContext *c,

			       unsigned char **in, int *instrides,

			       int srcSliceY,	int srcSliceH,

			       unsigned char **oplanes, int *outstrides)

{

  int w = c->srcW;

  int h = srcSliceH;

  int i,j;

  vector unsigned char uyvy;

  vector signed   short Y,U,V;

  vector signed   short vx,ux,uvx;

  vector signed   short R0,G0,B0,R1,G1,B1;

  vector unsigned char  R,G,B;

  vector unsigned char *out;

  ubyte *img;



  img = in[0];

  out = (vector unsigned char *)(oplanes[0]+srcSliceY*outstrides[0]);



  for (i=0;i<h;i++) {

    for (j=0;j<w/16;j++) {

      uyvy = vec_ld (0, img);

      U = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_u);



      V = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_v);



      Y = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_y);



      cvtyuvtoRGB (c, Y,U,V,&R0,&G0,&B0);



      uyvy = vec_ld (16, img);

      U = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_u);



      V = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_v);



      Y = (vector signed short)

	vec_perm (uyvy, (vector unsigned char)(0), demux_y);



      cvtyuvtoRGB (c, Y,U,V,&R1,&G1,&B1);



      R  = vec_packclp (R0,R1);

      G  = vec_packclp (G0,G1);

      B  = vec_packclp (B0,B1);



      //      vec_mstbgr24 (R,G,B, out);

      out_rgba (R,G,B,out);



      img += 32;

    }

  }

  return srcSliceH;

}
