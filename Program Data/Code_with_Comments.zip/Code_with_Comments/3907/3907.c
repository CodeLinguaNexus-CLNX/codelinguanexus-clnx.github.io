/*
This function is responsible for handling requests to update the framebuffer display in a VNC (Virtual Network Computing) session. Here's the breakdown:
- It calculates the width and height of the display surface based on the VncState and VncDisplay objects associated with the VNC session.
- The function then processes the update request parameters, including the incremental flag, position and dimensions of the rectangular region to be updated.
- If the specified y_position exceeds the height of the display surface, it adjusts it to the maximum valid value.
- It also ensures that the combined y_position and height (h) do not exceed the height of the display surface by adjusting the height if necessary.
- The need_update flag is set to indicate that an update is required, and if the update is non-incremental, the force_update flag is also set. The dirty bitmap associated with the specified region is updated accordingly by setting the dirty bits for the affected region.

Needs to notice:
- The function relies on the VncState and VncDisplay structures, which are assumed to be properly initialized and managed elsewhere in the code.
- It uses bitmap_set and bitmap_clear functions to manage the dirty regions in the framebuffer, indicating which parts of the display need to be updated.
- It's important to ensure that the input parameters, particularly the x and y positions, as well as the width and height values, are within the valid range to avoid potential display artifacts or out-of-bounds memory access.
- When using this function, it's crucial to understand the relationship between the dirty bitmap, the display surface, and the VNC session state to ensure proper coordination of framebuffer updates and synchronization with the remote client.
*/

static void framebuffer_update_request(VncState* vs, int incremental,

                                       int x_position, int y_position,

                                       int w, int h)

{

    int i;

    const size_t width = surface_width(vs->vd->ds) / VNC_DIRTY_PIXELS_PER_BIT;

    const size_t height = surface_height(vs->vd->ds);



    if (y_position > height) {

        y_position = height;

    }

    if (y_position + h >= height) {

        h = height - y_position;

    }



    vs->need_update = 1;

    if (!incremental) {

        vs->force_update = 1;

        for (i = 0; i < h; i++) {

            bitmap_set(vs->dirty[y_position + i], 0, width);

            bitmap_clear(vs->dirty[y_position + i], width,

                         VNC_DIRTY_BITS - width);

        }

    }

}
