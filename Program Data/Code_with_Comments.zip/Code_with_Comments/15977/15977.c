/*
This function is responsible for updating the configuration of a VirtIO block device based on the underlying block device and its parameters.

Here's the detail:
- The function starts by obtaining the VirtIO block device and block configuration from the provided VirtIODevice.
- It then retrieves the capacity and block size information from the underlying block device using bdrv_get_geometry.
- The function proceeds to populate a struct virtio_blk_config with various parameters such as capacity, maximum segments, cylinders, block size, minimum and optimal I/O sizes, heads, and more.
- There is a conditional check to ensure that the block device capacity is a multiple of the logical block size and adjusts the geometry accordingly if it's not the case.
- Finally, the function sets additional parameters such as size_max, physical block exponent, alignment offset, and write cache enablement, and copies the updated configuration into the provided config buffer.

Needs to notice:
- Developers using this function should have a clear understanding of the VirtIO block device specification and the semantics of the various configuration parameters being set.
- It's important to ensure that the underlying block device (s->bs) and its associated BlockConf configuration are properly initialized and compatible with the VirtIO block device.
- Care should be taken when adjusting the block device geometry to ensure that it aligns with the expected behavior of the device and the requirements of the virtualized environment.
- The function relies on various assumptions and operations related to block size, geometry, and capacity calculations, which should be well understood and validated in the context of the specific block device being configured.
- Proper error handling and validation of the input parameters should be considered to ensure the function operates correctly in diverse environments and with different block device configurations.

Overall, this function plays a critical role in configuring a VirtIO block device to align with the characteristics of the underlying block device, and careful attention to detail is necessary when using and modifying it.
*/
static void virtio_blk_update_config(VirtIODevice *vdev, uint8_t *config)

{

    VirtIOBlock *s = VIRTIO_BLK(vdev);

    BlockConf *conf = &s->conf.conf;

    struct virtio_blk_config blkcfg;

    uint64_t capacity;

    int blk_size = conf->logical_block_size;



    bdrv_get_geometry(s->bs, &capacity);

    memset(&blkcfg, 0, sizeof(blkcfg));

    virtio_stq_p(vdev, &blkcfg.capacity, capacity);

    virtio_stl_p(vdev, &blkcfg.seg_max, 128 - 2);

    virtio_stw_p(vdev, &blkcfg.cylinders, conf->cyls);

    virtio_stl_p(vdev, &blkcfg.blk_size, blk_size);

    virtio_stw_p(vdev, &blkcfg.min_io_size, conf->min_io_size / blk_size);

    virtio_stw_p(vdev, &blkcfg.opt_io_size, conf->opt_io_size / blk_size);

    blkcfg.heads = conf->heads;

    /*

     * We must ensure that the block device capacity is a multiple of

     * the logical block size. If that is not the case, let's use

     * sector_mask to adopt the geometry to have a correct picture.

     * For those devices where the capacity is ok for the given geometry

     * we don't touch the sector value of the geometry, since some devices

     * (like s390 dasd) need a specific value. Here the capacity is already

     * cyls*heads*secs*blk_size and the sector value is not block size

     * divided by 512 - instead it is the amount of blk_size blocks

     * per track (cylinder).

     */

    if (bdrv_getlength(s->bs) /  conf->heads / conf->secs % blk_size) {

        blkcfg.sectors = conf->secs & ~s->sector_mask;

    } else {

        blkcfg.sectors = conf->secs;

    }

    blkcfg.size_max = 0;

    blkcfg.physical_block_exp = get_physical_block_exp(conf);

    blkcfg.alignment_offset = 0;

    blkcfg.wce = bdrv_enable_write_cache(s->bs);

    memcpy(config, &blkcfg, sizeof(struct virtio_blk_config));

}
