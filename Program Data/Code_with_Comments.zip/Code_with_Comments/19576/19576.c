/*This function is responsible for handling input events during replay in a QEMU console.

Here's the detail: When in replay play mode, the function does nothing and allows the replayed input events to flow through as if in normal operation. In replay record mode, it adds the input event to the replay log by making a clone of the input event and storing it for future replay. In any other mode, it sends the input event to the QEMU input event handling implementation for processing.

Need's to notice that the function's behavior is determined by the current replay mode, and it selectively records or replays input events based on this mode. Additionally, it relies on other replay-related functions and structures for cloning and storing input events and interacts with the QEMU input event handling implementation based on the current mode.*/
void replay_input_event(QemuConsole *src, InputEvent *evt)

{

    if (replay_mode == REPLAY_MODE_PLAY) {

        /* Nothing */

    } else if (replay_mode == REPLAY_MODE_RECORD) {

        replay_add_input_event(qapi_clone_InputEvent(evt));

    } else {

        qemu_input_event_send_impl(src, evt);

    }

}
