/*
This function is responsible for generating the Shift Left with MQ instruction in the DisasContext. Here's the detail: It computes the logical shift left of the value in the source register by the amount specified in the low-order five bits of the value in the base register, and then stores the result in the MQ special-purpose register. It also handles the update of the general-purpose registers based on the condition of the base register. Needs to notice the function manipulates the values in general-purpose registers and special-purpose registers according to the specified operation and conditions, and it handles the update of the general-purpose registers based on the condition of the base register.
*/

static void gen_slq(DisasContext* ctx)

{

    int l1 = gen_new_label();

    TCGv t0 = tcg_temp_new();

    TCGv t1 = tcg_temp_new();

    tcg_gen_andi_tl(t1, cpu_gpr[rB(ctx->opcode)], 0x1F);

    tcg_gen_shl_tl(t0, cpu_gpr[rS(ctx->opcode)], t1);

    tcg_gen_subfi_tl(t1, 32, t1);

    tcg_gen_shr_tl(t1, cpu_gpr[rS(ctx->opcode)], t1);

    tcg_gen_or_tl(t1, t0, t1);

    gen_store_spr(SPR_MQ, t1);

    tcg_gen_andi_tl(t1, cpu_gpr[rB(ctx->opcode)], 0x20);

    tcg_gen_mov_tl(cpu_gpr[rA(ctx->opcode)], t0);

    tcg_gen_brcondi_tl(TCG_COND_EQ, t1, 0, l1);

    tcg_gen_movi_tl(cpu_gpr[rA(ctx->opcode)], 0);

    gen_set_label(l1);

    tcg_temp_free(t0);

    tcg_temp_free(t1);

    if (unlikely(Rc(ctx->opcode) != 0))

        gen_set_Rc0(ctx, cpu_gpr[rA(ctx->opcode)]);

}
