/*This function is responsible for handling the opening of input streams for a specified variant in a multimedia processing context. It takes into account different key types, such as KEY_NONE and KEY_AES_128, and performs the necessary actions to open the input stream with appropriate decryption if required.

Here's the detail:
The function first retrieves the segment associated with the current sequence number from the variant. It then checks the key type of the segment and proceeds to open the input stream accordingly. If the key type is KEY_NONE, the function opens the input stream using ffurl_open with the specified URL for reading. If the key type is KEY_AES_128, the function processes the key and initializes the input stream for decryption using the AES-128 encryption algorithm. It allocates the input URLContext, sets the key and initialization vector (IV) using av_opt_set, and connects to the input stream using ffurl_connect.

Needs to notice:
- This function provides support for opening input streams with decryption capabilities, specifically for the AES-128 encryption algorithm.
- It handles the retrieval and processing of keys as well as the initialization of the input stream with the appropriate decryption parameters.
- The function ensures that the input stream is successfully opened and configured for decryption before returning control to the calling code.*/
static int open_input(struct variant *var)

{

    struct segment *seg = var->segments[var->cur_seq_no - var->start_seq_no];

    if (seg->key_type == KEY_NONE) {

        return ffurl_open(&var->input, seg->url, AVIO_FLAG_READ,

                          &var->parent->interrupt_callback, NULL);

    } else if (seg->key_type == KEY_AES_128) {

        char iv[33], key[33], url[MAX_URL_SIZE];

        int ret;

        if (strcmp(seg->key, var->key_url)) {

            URLContext *uc;

            if (ffurl_open(&uc, seg->key, AVIO_FLAG_READ,

                           &var->parent->interrupt_callback, NULL) == 0) {

                if (ffurl_read_complete(uc, var->key, sizeof(var->key))

                    != sizeof(var->key)) {

                    av_log(NULL, AV_LOG_ERROR, "Unable to read key file %s\n",

                           seg->key);

                }

                ffurl_close(uc);

            } else {

                av_log(NULL, AV_LOG_ERROR, "Unable to open key file %s\n",

                       seg->key);

            }

            av_strlcpy(var->key_url, seg->key, sizeof(var->key_url));

        }

        ff_data_to_hex(iv, seg->iv, sizeof(seg->iv), 0);

        ff_data_to_hex(key, var->key, sizeof(var->key), 0);

        iv[32] = key[32] = '\0';

        if (strstr(seg->url, "://"))

            snprintf(url, sizeof(url), "crypto+%s", seg->url);

        else

            snprintf(url, sizeof(url), "crypto:%s", seg->url);

        if ((ret = ffurl_alloc(&var->input, url, AVIO_FLAG_READ,

                               &var->parent->interrupt_callback)) < 0)

            return ret;

        av_opt_set(var->input->priv_data, "key", key, 0);

        av_opt_set(var->input->priv_data, "iv", iv, 0);

        if ((ret = ffurl_connect(var->input, NULL)) < 0) {

            ffurl_close(var->input);

            var->input = NULL;

            return ret;

        }

        return 0;

    }

    return AVERROR(ENOSYS);

}
