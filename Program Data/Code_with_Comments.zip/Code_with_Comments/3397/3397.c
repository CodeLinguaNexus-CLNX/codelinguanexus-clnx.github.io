/*
First paragraph: This function is responsible for performing horizontal chroma scaling for video frame conversion within an image processing context.

Second paragraph: Here's the detail: The function takes various input parameters including pointers to the destination buffers (dst1 and dst2), the width of the destination, pointers to the source chroma planes (src_in), scaling factors, filter coefficients (hChrFilter), and other parameters related to image format conversion. Depending on certain conditions (referred to by the if-else statements), the source chroma planes may undergo certain transformations such as YV12 conversion or planar reading. After the initial processing, the function calls different scaling functions based on the availability of a fast scaling method and the need for range conversion.

Third paragraph: Needs to notice: The function's behavior is influenced by the context-specific callbacks and flags (such as c->chrToYV12, c->readChrPlanar, c->hcscale_fast, and c->chrConvertRange) which may introduce different processing paths and optimizations. Additionally, the use of callback functions introduces a level of abstraction and flexibility but also requires careful management and verification of their correct implementation. Moreover, the comment mentioning the "token" below 256 may imply a specific design or performance constraint related to the implementation of this function.

If you have further questions or need additional explanation about this function, please feel free to ask for more detailed clarification or specific aspects!

*/static av_always_inline void hcscale(SwsContext* c, int16_t* dst1, int16_t* dst2, int dstWidth,

                                     const uint8_t *src_in[4],

                                     int srcW, int xInc, const int16_t *hChrFilter,

                                     const int16_t *hChrFilterPos, int hChrFilterSize,

                                     uint8_t *formatConvBuffer, uint32_t *pal)

{

    const uint8_t *src1 = src_in[1], *src2 = src_in[2];

    if (c->chrToYV12) {

        uint8_t *buf2 = formatConvBuffer + FFALIGN(srcW * FFALIGN(c->srcBpc, 8) >> 3, 16);

        c->chrToYV12(formatConvBuffer, buf2, src1, src2, srcW, pal);

        src1= formatConvBuffer;

        src2= buf2;

    } else if (c->readChrPlanar) {

        uint8_t *buf2 = formatConvBuffer + FFALIGN(srcW * FFALIGN(c->srcBpc, 8) >> 3, 16);

        c->readChrPlanar(formatConvBuffer, buf2, src_in, srcW);

        src1= formatConvBuffer;

        src2= buf2;

    }



    if (!c->hcscale_fast) {

        c->hcScale(c, dst1, dstWidth, src1, hChrFilter, hChrFilterPos, hChrFilterSize);

        c->hcScale(c, dst2, dstWidth, src2, hChrFilter, hChrFilterPos, hChrFilterSize);

    } else { // fast bilinear upscale / crap downscale

        c->hcscale_fast(c, dst1, dst2, dstWidth, src1, src2, srcW, xInc);

    }



    if (c->chrConvertRange)

        c->chrConvertRange(dst1, dst2, dstWidth);

}
