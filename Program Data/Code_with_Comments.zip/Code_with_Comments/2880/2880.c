/*
This function is responsible for handling operations in 64-bit mode for the coprocessor 1 (CP1) and checking the Floating Point Status Register (CP0_Status) to ensure that the FPU (Floating Point Unit) is enabled. If the FPU is not enabled, it raises an exception of type EXCP_RI.

Here's the detail: The function first checks if the Floating Point Status bit in the CP0_Status register is set, indicating that the FPU is enabled. If the bit is not set, it calls the do_raise_exception function to raise an exception of type EXCP_RI, indicating a reserved instruction exception. After the exception is raised, the function returns.

Need's to notice: When using this function, it is important to ensure that the environment (env) is properly set up and that the CP0_Status register reflects the correct state of the FPU. Additionally, the handling of the raised exception and the subsequent execution flow should be carefully managed to maintain the integrity of the 64-bit mode operations and exception handling.
*/void op_cp1_64bitmode(void)

{

    if (!(env->CP0_Status & (1 << CP0St_FR))) {

        CALL_FROM_TB1(do_raise_exception, EXCP_RI);

    }

    RETURN();

}
