/*
This function is responsible for performing fixed-point digital signal processing (DSP) function checks using randomly generated input buffers. Here's the detail: it allocates aligned memory buffers, initializes an AVFixedDSPContext structure, and then proceeds to invoke a series of specific DSP function checks such as vector multiplication, vector addition, reverse vector multiplication, windowed vector multiplication, scaled windowed vector multiplication, butterflies operation, and scalar product calculation. Each check is performed using the corresponding DSP function and the randomly generated input buffers.

Needs to notice: When using this function, it's important to ensure that the randomly generated input buffers accurately represent the range of data that the fixed-point DSP functions are expected to handle. Additionally, proper validation of the DSP function behavior against the generated input data is crucial for verifying the correctness and performance of the fixed-point DSP implementation. Furthermore, understanding the underlying fixed-point DSP algorithms and their specific requirements is essential for interpreting the results of the function checks and making any necessary optimizations or adjustments.
*/

void checkasm_check_fixed_dsp(void)

{

    LOCAL_ALIGNED_32(int32_t, src0, [BUF_SIZE]);

    LOCAL_ALIGNED_32(int32_t, src1, [BUF_SIZE]);

    LOCAL_ALIGNED_32(int32_t, src2, [BUF_SIZE]);

    AVFixedDSPContext *fdsp = avpriv_alloc_fixed_dsp(1);



    randomize_buffers();

    if (check_func(fdsp->vector_fmul, "vector_fmul"))

        check_vector_fmul(src0, src1);

    if (check_func(fdsp->vector_fmul_add, "vector_fmul_add"))

        check_vector_fmul_add(src0, src1, src2);

    if (check_func(fdsp->vector_fmul_reverse, "vector_fmul_reverse"))

        check_vector_fmul(src0, src1);

    if (check_func(fdsp->vector_fmul_window, "vector_fmul_window"))

        check_vector_fmul_window(src0, src1, src2);

    if (check_func(fdsp->vector_fmul_window_scaled, "vector_fmul_window_scaled"))

        check_vector_fmul_window_scaled(src0, src1, src2);

    report("vector_fmul");

    if (check_func(fdsp->butterflies_fixed, "butterflies_fixed"))

        check_butterflies(src0, src1);

    report("butterflies_fixed");

    if (check_func(fdsp->scalarproduct_fixed, "scalarproduct_fixed"))

        check_scalarproduct_fixed(src0, src1);

    report("scalarproduct_fixed");



    av_freep(&fdsp);

}
