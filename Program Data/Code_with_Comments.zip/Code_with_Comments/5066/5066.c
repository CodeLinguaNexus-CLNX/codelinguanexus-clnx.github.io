/*

*/
/*
Function explanation:
This function is responsible for compressing MP3 audio headers. It processes the input buffer containing MP3 audio data, extracts and processes the header information, and compresses the header if it meets specific criteria. The compressed output is then stored in the poutbuf, and the size of the compressed data is updated in poutbuf_size.

Details:
- The mp3_header_compress function takes input parameters including the AVBitStreamFilterContext, AVCodecContext, input buffer (buf), buffer size (buf_size), and keyframe flag.
- It begins by checking the strict_std_compliance setting in the AVCodecContext. If the compliance level is higher than FF_COMPLIANCE_EXPERIMENTAL, an error message is logged, and the function returns -1 to indicate non-standard compliance.
- The header is then extracted from the input buffer, and the mode_extension is determined from the header information.
- If the header validation using ff_mpa_check_header and a bitmask check fails, the function copies the input buffer to the output buffer and updates the output buffer size, logging a message indicating the inability to compress the header.
- If the header passes the validation, the compressing process begins. The function allocates memory for the compressed data, excluding the header, and then copies the relevant portion of the input buffer to the output buffer, including padding if necessary.
- Additionally, specific manipulations are performed on the output buffer if the audio is stereo (2 channels) and certain conditions related to the header information are met.
- Finally, the function returns 1 to indicate successful compression.

Needs to notice:
- When using this function, it is important to handle the compressed data and its incorporation into the overall bitstream processing flow appropriately.
- The function may log error or informational messages, so capturing and handling these messages according to the application's logging or error-reporting mechanism is necessary.
- Careful consideration should be given to the handling of strict_std_compliance to ensure compatibility with the target MP3 standard and the intended usage scenario.
- Additionally, proper memory management, including allocation and deallocation, should be considered to avoid memory leaks or buffer overflows when working with the compressed data.

In summary, the mp3_header_compress function is responsible for compressing MP3 audio headers, ensuring compliance with the applicable standard and handling stereo audio specifics if applicable. Effective usage of the compressed data, error handling, compliance settings, and memory management is essential when utilizing this function within the context of MP3 audio processing.
*/

static int mp3_header_compress(AVBitStreamFilterContext* bsfc, AVCodecContext* avctx, const char* args,

                     uint8_t **poutbuf, int *poutbuf_size,

                     const uint8_t *buf, int buf_size, int keyframe){

    uint32_t header;

    int mode_extension;



    if(avctx->strict_std_compliance > FF_COMPLIANCE_EXPERIMENTAL){

        av_log(avctx, AV_LOG_ERROR, "not standards compliant\n");

        return -1;

    }



    header = (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];

    mode_extension= (header>>4)&3;



    if(ff_mpa_check_header(header) < 0 || (header&0x70000) != 0x30000){

        *poutbuf= (uint8_t *) buf;

        *poutbuf_size= buf_size;



        av_log(avctx, AV_LOG_INFO, "cannot compress %08X\n", header);

        return 0;

    }



    *poutbuf_size= buf_size - 4;

    *poutbuf= av_malloc(buf_size - 4 + FF_INPUT_BUFFER_PADDING_SIZE);

    memcpy(*poutbuf, buf + 4, buf_size - 4 + FF_INPUT_BUFFER_PADDING_SIZE);



    if(avctx->channels==2){

        if((header & (3<<19)) != 3<<19){

            (*poutbuf)[1] &= 0x3F;

            (*poutbuf)[1] |= mode_extension<<6;

            FFSWAP(int, (*poutbuf)[1], (*poutbuf)[2]);

        }else{

            (*poutbuf)[1] &= 0x8F;

            (*poutbuf)[1] |= mode_extension<<4;

        }

    }



    return 1;

}
