/*
This function is responsible for handling the completion of a PFlash command and resetting the flash memory accordingly.

Here's the detail: Upon completion of the PFlash command, the function toggles the status flag, sets the write cycle, and updates the command to zero. If the bypass condition is met, it sets the write cycle to 2; otherwise, it allows the memory region associated with the PFlash to become readable, setting the write cycle to 0.

Needs to notice: The function operates with a PFlash opaque structure and manipulates its internal state, and it also interacts with the memory region by adjusting its read permissions based on the bypass condition.
*/
static void pflash_timer (void *opaque)

{

    pflash_t *pfl = opaque;



    DPRINTF("%s: command %02x done\n", __func__, pfl->cmd);

    /* Reset flash */

    pfl->status ^= 0x80;

    if (pfl->bypass) {

        pfl->wcycle = 2;

    } else {

        memory_region_rom_device_set_readable(&pfl->mem, true);

        pfl->wcycle = 0;

    }

    pfl->cmd = 0;

}
