/*
This function is responsible for calculating the relocation value for a 26-bit relative jump or branch instruction in the context of a TCG (Tiny Code Generator) instruction sequence.

Here's the detail: When invoked, the function performs a bitwise assertion to ensure that the difference between the memory addresses of the source instruction and the target instruction fits within the 26-bit relocation range. It then computes the relative jump address by right-shifting the target address by 2 bits to align it with the instruction boundary and applying a mask to extract the lower 26 bits.

Needs to notice: This function is specifically designed for handling 26-bit relative jumps or branches and assumes certain alignment and masking requirements. Any modifications to this function should carefully consider the target architecture's instruction encoding and addressing mechanisms to ensure proper relocation calculation for the specific type of jump or branch instruction.
*/
static inline uint32_t reloc_26_val(tcg_insn_unit *pc, tcg_insn_unit *target)

{

    assert((((uintptr_t)pc ^ (uintptr_t)target) & 0xf0000000) == 0);

    return ((uintptr_t)target >> 2) & 0x3ffffff;

}
