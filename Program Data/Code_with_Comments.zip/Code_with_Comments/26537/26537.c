/*
This function is responsible for allocating an output buffer for VAAPI (Video Acceleration API) encoding.

Here's the detail:

- It takes the 'opaque' pointer and 'size' as input arguments. The 'opaque' pointer is used to access the AVCodecContext, while 'size' represents the size of the output buffer.

- It retrieves the VAAPI encode context 'ctx' from the AVCodecContext's private data.

- It creates a VAAPI buffer of type VAEncCodedBufferType, which is used to hold the compressed output data. The size calculation for the buffer is based on the assumption that it needs to be large enough to accommodate the largest possible compressed frame, including the uncompressed frame and some header data.

- If the creation of the VAAPI output buffer fails, it logs an error message and returns NULL.

- If the buffer creation is successful, it logs a debug message indicating the allocated output buffer ID.

- It then creates an AVBufferRef to wrap the VAAPI buffer ID, indicating that the buffer is read-only, and specifying a custom free function (vaapi_encode_free_output_buffer) to handle buffer deallocation.

- If the AVBufferRef creation fails, it cleans up by destroying the VAAPI buffer and returns NULL.

Needs to notice:

- The allocation of the output buffer size should be carefully calculated to accommodate the largest possible compressed frame, including any necessary header data. The assumptions made about the buffer size should be validated to ensure it is sufficient for all scenarios.

- Error handling and resource cleanup are essential, as failure to create the VAAPI output buffer requires proper cleanup to avoid resource leakage.

- The usage of VAAPI functions and the associated VAAPI buffer lifecycle should be well-documented and understood, especially the relationship between buffer creation, referencing, and deallocation.

- Developers should be aware of potential memory constraints or performance implications related to buffer size allocation and usage. Testing with a variety of input sizes and scenarios is recommended to validate the buffer size assumptions.
*/
static AVBufferRef *vaapi_encode_alloc_output_buffer(void *opaque,

                                                     int size)

{

    AVCodecContext   *avctx = opaque;

    VAAPIEncodeContext *ctx = avctx->priv_data;

    VABufferID buffer_id;

    VAStatus vas;

    AVBufferRef *ref;



    // The output buffer size is fixed, so it needs to be large enough

    // to hold the largest possible compressed frame.  We assume here

    // that the uncompressed frame plus some header data is an upper

    // bound on that.

    vas = vaCreateBuffer(ctx->hwctx->display, ctx->va_context,

                         VAEncCodedBufferType,

                         3 * ctx->aligned_width * ctx->aligned_height +

                         (1 << 16), 1, 0, &buffer_id);

    if (vas != VA_STATUS_SUCCESS) {

        av_log(avctx, AV_LOG_ERROR, "Failed to create bitstream "

               "output buffer: %d (%s).\n", vas, vaErrorStr(vas));

        return NULL;

    }



    av_log(avctx, AV_LOG_DEBUG, "Allocated output buffer %#x\n", buffer_id);



    ref = av_buffer_create((uint8_t*)(uintptr_t)buffer_id,

                           sizeof(buffer_id),

                           &vaapi_encode_free_output_buffer,

                           avctx, AV_BUFFER_FLAG_READONLY);

    if (!ref) {

        vaDestroyBuffer(ctx->hwctx->display, buffer_id);

        return NULL;

    }



    return ref;

}
