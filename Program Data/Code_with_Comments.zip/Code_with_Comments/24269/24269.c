/*This function is responsible for initializing the parsing of Advanced SubStation Alpha (ASS) subtitle data in an FFmpeg codec context.

Here's the detail: The function allocates memory for storing the subtitle header based on the extradata size within the codec context. It then copies the extradata into the allocated memory block and updates the subtitle header size accordingly.

Needs to notice: It's important to ensure that the extradata field in the AVCodecContext is properly set with valid ASS subtitle data before calling this initialization function. Additionally, memory allocation and copying operations should be checked for potential errors to prevent issues such as memory leaks or invalid memory access. Understanding the structure and contents of the ASS subtitle data format is crucial for correctly initializing the subtitle header.*/
static av_cold int ass_decode_init(AVCodecContext *avctx)

{

    avctx->subtitle_header = av_malloc(avctx->extradata_size);

    if (!avctx->extradata)

        return AVERROR(ENOMEM);

    memcpy(avctx->subtitle_header, avctx->extradata, avctx->extradata_size);

    avctx->subtitle_header_size = avctx->extradata_size;

    return 0;

}
