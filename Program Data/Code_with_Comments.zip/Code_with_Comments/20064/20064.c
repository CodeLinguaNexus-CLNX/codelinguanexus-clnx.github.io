/*
First paragraph: This function is responsible for checking if a test unit is ready for use in the context of an IDE device. 

Second paragraph: Here's the detailed description of the function. The function begins by checking if the IDE device's underlying block storage, represented by the "s->bs" member, has a media inserted using the bdrv_is_inserted() function. If a media is present, the function calls the ide_atapi_cmd_ok() function to indicate that the test unit is ready. On the other hand, if no media is inserted, the function calls the ide_atapi_cmd_error() function to report an error with the specific sense code SENSE_NOT_READY and additional sense code ASC_MEDIUM_NOT_PRESENT.

Third paragraph: There are no specific notices or points to be aware of mentioned in the code snippet.

TOKENS USED: function, checking, IDEState, uint8_t, buf, bdrv_is_inserted(), ide_atapi_cmd_ok(), ide_atapi_cmd_error(), sense code, ASC_MEDIUM_NOT_PRESENT.
*/
static void cmd_test_unit_ready(IDEState *s, uint8_t *buf)

{

    if (bdrv_is_inserted(s->bs)) {

        ide_atapi_cmd_ok(s);

    } else {

        ide_atapi_cmd_error(s, SENSE_NOT_READY, ASC_MEDIUM_NOT_PRESENT);

    }

}
