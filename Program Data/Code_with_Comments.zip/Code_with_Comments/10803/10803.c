/**
 * This function is responsible for comparing a 64-bit unsigned integer read from the QEMU file with a provided 64-bit integer, checking if they are equal.
 *
 * Here's the detail of the function:
 * - The function reads a 64-bit unsigned integer from the QEMU file 'f' and compares it with the provided 64-bit integer 'pv'. It then returns 0 if the values are equal, indicating success, and returns -EINVAL if the values are not equal.
 *
 * Need's to notice:
 * - The function assumes that the 64-bit integer provided in 'pv' is in the correct endianness for comparison with the data read from the QEMU file, as it uses qemu_get_be64s() to read the data in big-endian format.
 */
static int get_uint64_equal(QEMUFile *f, void *pv, size_t size)

{

    uint64_t *v = pv;

    uint64_t v2;

    qemu_get_be64s(f, &v2);



    if (*v == v2) {

        return 0;

    }

    return -EINVAL;

}
