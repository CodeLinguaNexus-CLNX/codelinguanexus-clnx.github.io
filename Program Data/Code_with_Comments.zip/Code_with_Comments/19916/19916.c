/**
 * This function is responsible for checking and validating the NIC (Network Interface Controller) model against a list of supported models and the default model. If the NIC model is unsupported, it prints an error message and exits with a non-zero status.
 *
 * Here's the detail: The function first checks if the NIC model is null, and if so, it assigns the default model to the NIC. It then compares the NIC model with the list of supported models. If a match is found, the index of the matched model in the model list is returned. If the NIC model is set to "?", the function prints the supported NIC models and exits with a non-zero status. Additionally, it prints the list of supported NIC models to the standard error output.
 *
 * Need's to notice: It's important to note that this function is designed to be used within the QEMU (Quick Emulator) environment for virtualization. Users should ensure that the NIC model being set is supported by the underlying virtualization platform. Additionally, the function assumes that the input NICInfo structure and model lists are properly initialized and not null.
 */
int qemu_check_nic_model_list(NICInfo *nd, const char * const *models,

                              const char *default_model)

{

    int i, exit_status = 0;



    if (!nd->model)

        nd->model = strdup(default_model);



    if (strcmp(nd->model, "?") != 0) {

        for (i = 0 ; models[i]; i++)

            if (strcmp(nd->model, models[i]) == 0)

                return i;



        fprintf(stderr, "qemu: Unsupported NIC model: %s\n", nd->model);

        exit_status = 1;

    }



    fprintf(stderr, "qemu: Supported NIC models: ");

    for (i = 0 ; models[i]; i++)

        fprintf(stderr, "%s%c", models[i], models[i+1] ? ',' : '\n');



    exit(exit_status);

}
