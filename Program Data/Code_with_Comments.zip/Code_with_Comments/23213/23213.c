/**
 * This function is responsible for retrieving the error message corresponding to the given error code. It handles loading the necessary system module, formatting the error message, and converting it to UTF-8 encoding for return.
 *
 * Here's the detail: The function first checks if the error code falls within the range of network-related errors. If so, it loads the "netmsg.dll" module to facilitate message retrieval. It then uses the FormatMessageW function to obtain the error message, and performs additional processing to ensure proper formatting. Finally, it converts the message to UTF-8 encoding before returning it.
 *
 * Needs to notice: Care should be taken to handle memory allocation and deallocation properly, particularly when working with wide character strings and converting them to UTF-8. Additionally, the function assumes the availability of the "netmsg.dll" module for network-related error message retrieval, and this dependency should be considered when using the function in different environments.
 */
get_net_error_message(gint error)

{

    HMODULE module = NULL;

    gchar *retval = NULL;

    wchar_t *msg = NULL;

    int flags;

    size_t nchars;



    flags = FORMAT_MESSAGE_ALLOCATE_BUFFER |

        FORMAT_MESSAGE_IGNORE_INSERTS |

        FORMAT_MESSAGE_FROM_SYSTEM;



    if (error >= NERR_BASE && error <= MAX_NERR) {

        module = LoadLibraryExW(L"netmsg.dll", NULL, LOAD_LIBRARY_AS_DATAFILE);



        if (module != NULL) {

            flags |= FORMAT_MESSAGE_FROM_HMODULE;

        }

    }



    FormatMessageW(flags, module, error, 0, (LPWSTR)&msg, 0, NULL);



    if (msg != NULL) {

        nchars = wcslen(msg);



        if (nchars > 2 &&

            msg[nchars - 1] == L'\n' &&

            msg[nchars - 2] == L'\r') {

            msg[nchars - 2] = L'\0';

        }



        retval = g_utf16_to_utf8(msg, -1, NULL, NULL, NULL);



        LocalFree(msg);

    }



    if (module != NULL) {

        FreeLibrary(module);

    }



    return retval;

}
