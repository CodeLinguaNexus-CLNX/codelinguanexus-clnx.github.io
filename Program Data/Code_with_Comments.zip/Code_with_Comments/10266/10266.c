/*
This function is responsible for managing the deletion of a coroutine within QEMU. Here's a detailed breakdown of the function:

- The function takes a Coroutine pointer and retrieves the CoroutineThreadState associated with the current thread.
- It then casts the provided Coroutine pointer to a CoroutineUContext pointer for further manipulation.
- If the pool size within the CoroutineThreadState is less than a maximum size (POOL_MAX_SIZE), the coroutine being deleted is added back to the coroutine pool.
- Upon being added to the pool, the caller of the coroutine is set to NULL, and the pool size is incremented.
- If the pool has reached its maximum size, the function proceeds to free the coroutine's stack and the coroutine structure itself using the g_free function.

Notable points to consider:
- This function is designed to manage the coroutine pool within QEMU, allowing for the efficient reuse of coroutine resources when the pool size is below the maximum limit.
- When a coroutine is deleted and the pool is not at maximum capacity, it is added back to the pool for potential future reuse, reducing the need for frequent memory allocations and deallocations.
- If the pool has reached its maximum size, the function is responsible for freeing the memory associated with the coroutine, including its stack and the coroutine structure itself.
- Proper management of the coroutine pool and memory deallocation is crucial for maintaining performance and resource utilization within the QEMU virtualization environment.

Overall, this function plays a vital role in the lifecycle management of coroutines within QEMU, ensuring efficient resource utilization and memory management.
*/
void qemu_coroutine_delete(Coroutine *co_)

{

    CoroutineThreadState *s = coroutine_get_thread_state();

    CoroutineUContext *co = DO_UPCAST(CoroutineUContext, base, co_);



    if (s->pool_size < POOL_MAX_SIZE) {

        QLIST_INSERT_HEAD(&s->pool, &co->base, pool_next);

        co->base.caller = NULL;

        s->pool_size++;

        return;

    }



    g_free(co->stack);

    g_free(co);

}
