/*
This function is responsible for populating the file descriptor sets (read, write, and exceptional) based on the event configuration stored in the given array of pollfds. Here's the detailed breakdown:

- Upon invocation, the function initializes the nfds variable to -1 and declares an iterator i to iterate through the elements of the pollfds.

- It then iterates through the elements of the pollfds array, retrieving the file descriptor and event configuration for each entry.

- For each pollfd entry, the function examines the event configuration and updates the corresponding file descriptor set (rfds, wfds, or xfds) based on the presence of read, write, or exceptional events. Additionally, the function updates the nfds variable based on the maximum file descriptor encountered during the iteration.

Some important points to note:
- The function relies on the GArray data structure to store pollfd entries, which should be appropriately initialized and populated before invoking this function.
- It efficiently updates the file descriptor sets based on the event configuration, providing the necessary information for subsequent polling or event handling operations.

Overall, this function plays a pivotal role in preparing the file descriptor sets for I/O multiplexing and event-driven I/O operations based on the event configuration stored in the pollfds array.
*/

static int pollfds_fill(GArray* pollfds, fd_set* rfds, fd_set* wfds,

                        fd_set *xfds)

{

    int nfds = -1;

    int i;



    for (i = 0; i < pollfds->len; i++) {

        GPollFD *pfd = &g_array_index(pollfds, GPollFD, i);

        int fd = pfd->fd;

        int events = pfd->events;

        if (events & G_IO_IN) {

            FD_SET(fd, rfds);

            nfds = MAX(nfds, fd);

        }

        if (events & G_IO_OUT) {

            FD_SET(fd, wfds);

            nfds = MAX(nfds, fd);

        }

        if (events & G_IO_PRI) {

            FD_SET(fd, xfds);

            nfds = MAX(nfds, fd);

        }

    }

    return nfds;

}
