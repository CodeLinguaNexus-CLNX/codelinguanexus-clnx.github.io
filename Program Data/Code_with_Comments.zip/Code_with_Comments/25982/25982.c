/*
This function is responsible for testing the performance of coroutine nesting by repeatedly creating and entering nested coroutines. Here's the breakdown of its functionality:

- It initializes parameters such as maxcycles (the number of iterations) and maxnesting (the maximum depth of nesting) for the performance test.

- The function then starts a test timer using g_test_timer_start to measure the duration of the performance test.

- Within a loop that runs maxcycles times, the function creates a new Coroutine named "root" using qemu_coroutine_create and enters into it with a NestData structure, which contains information about the nesting depth and counters for coroutine enter and return operations.

- After completing the iterations, it calculates the duration of the test using g_test_timer_elapsed and outputs a message containing the iteration counts, nesting depth, and the measured duration.

Points to notice:
- The performance test operates using fixed values for maxcycles and maxnesting, which may not be representative of real-world use cases. Considerations should be given to parameterize these values for more comprehensive testing.
- The function uses a test timer and message output for measurement and reporting. In a production environment, the use of dedicated performance measurement and logging frameworks may be more appropriate.
- As with any performance testing code, caution should be exercised when interpreting the results as they may be influenced by various factors such as system load, hardware capabilities, and compiler optimizations.
*/
static void perf_nesting(void)

{

    unsigned int i, maxcycles, maxnesting;

    double duration;



    maxcycles = 10000;

    maxnesting = 1000;

    Coroutine *root;



    g_test_timer_start();

    for (i = 0; i < maxcycles; i++) {

        NestData nd = {

            .n_enter  = 0,

            .n_return = 0,

            .max      = maxnesting,

        };

        root = qemu_coroutine_create(nest);

        qemu_coroutine_enter(root, &nd);

    }

    duration = g_test_timer_elapsed();



    g_test_message("Nesting %u iterations of %u depth each: %f s\n",

        maxcycles, maxnesting, duration);

}
