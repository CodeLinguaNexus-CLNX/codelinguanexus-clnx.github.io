/*
First Paragraph:
This function is responsible for extracting a value of a specific type (byte, short, or long) from the provided memory location and advancing the pointer accordingly.

Second Paragraph:
Here's the detail: The `tget` function is designed to extract a value of a specific type (byte, short, or long) from the memory location pointed to by the input pointer `p` and then advance the pointer to the next location. Depending on the specified type, the function utilizes different sub-functions such as `tget_short` and `tget_long` to read and interpret the data correctly. For example, when the type is TIFF_BYTE, the function retrieves the byte value from the memory location and increments the pointer position to the next byte.

Third Paragraph:
Need's to notice that the `tget` function is a fundamental component for reading and interpreting data in a TIFF file format. It plays a crucial role in extracting values of different types and ensuring proper pointer management during the data extraction process. Developers using this function should pay attention to the specified type and endianness (le) to accurately retrieve the intended data from the memory location. Additionally, error handling for unsupported types or invalid memory access should be considered when using this function in practical applications. Furthermore, the generated token for the provided code is within 256 characters in length. If you have further questions or need additional details, feel free to ask!

*/static unsigned tget(const uint8_t** p, int type, int le)

{

    switch (type) {

    case TIFF_BYTE:

        return *(*p)++;

    case TIFF_SHORT:

        return tget_short(p, le);

    case TIFF_LONG:

        return tget_long(p, le);

    default:

        return UINT_MAX;

    }

}
