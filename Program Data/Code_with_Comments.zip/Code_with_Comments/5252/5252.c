/*
This function is responsible for checking and handling exceptions in the context of System Planning and Analysis of Power (sPAPR) environment. Here's a detailed breakdown of its functionality: The function first checks the number of arguments and return values, and if they don't meet the expected criteria, it sets the return value accordingly and exits. It then retrieves and processes the input arguments to determine the type of exception and performs appropriate handling. If the exception is related to an Event Power Off (EPOW) and there is a pending EPOW event, it writes the EPOW data to a buffer and clears the pending EPOW status. Otherwise, it sets the return value to indicate the absence of pending EPOW.

Some points to notice when using this function:
1. It is specifically designed for handling exceptions in the sPAPR environment, so understanding the sPAPR specification and exception handling mechanism is essential.
2. The function interacts with memory using memory read and write operations, so ensuring memory access correctness and validity is crucial.
3. Careful consideration of the exception types and appropriate handling mechanisms is necessary to ensure the proper functioning of the sPAPR environment.
*/

static void check_exception(sPAPREnvironment* spapr,

                            uint32_t token, uint32_t nargs,

                            target_ulong args,

                            uint32_t nret, target_ulong rets)

{

    uint32_t mask, buf, len;

    uint64_t xinfo;



    if ((nargs < 6) || (nargs > 7) || nret != 1) {

        rtas_st(rets, 0, -3);

        return;

    }



    xinfo = rtas_ld(args, 1);

    mask = rtas_ld(args, 2);

    buf = rtas_ld(args, 4);

    len = rtas_ld(args, 5);

    if (nargs == 7) {

        xinfo |= (uint64_t)rtas_ld(args, 6) << 32;

    }



    if ((mask & EVENT_MASK_EPOW) && pending_epow) {

        if (sizeof(*pending_epow) < len) {

            len = sizeof(*pending_epow);

        }



        cpu_physical_memory_write(buf, pending_epow, len);

        g_free(pending_epow);

        pending_epow = NULL;

        rtas_st(rets, 0, 0);

    } else {

        rtas_st(rets, 0, 1);

    }

}
