/*
This function is responsible for handling the retrieval and management of file descriptors within the QEMU monitor environment.

Here's the detail: Upon invocation, the function first retrieves a file descriptor from the QEMU monitor's character device. It then performs validation checks on the input parameters, ensuring that the provided fdname is valid and not starting with a digit. Subsequently, the function duplicates the file descriptor to prevent potential issues with ownership and then proceeds to manage the file descriptor within the monitor's list. If a file descriptor with the same name already exists in the list, it is replaced with the new one. If not, a new entry is created and added to the monitor's file descriptor list.

Need's to notice: When utilizing this function, it is important to ensure that the provided fdname is appropriate and does not conflict with existing entries in the monitor's file descriptor list. Additionally, proper error handling should be implemented to address potential issues related to file descriptor duplication and list management. Furthermore, users should be mindful of potential resource limitations, such as the maximum number of open files (EMFILE), and handle such scenarios appropriately to maintain the stability of the system.
*/
static int do_getfd(Monitor *mon, const QDict *qdict, QObject **ret_data)

{

    const char *fdname = qdict_get_str(qdict, "fdname");

    mon_fd_t *monfd;

    int fd;



    fd = qemu_chr_get_msgfd(mon->chr);

    if (fd == -1) {

        qerror_report(QERR_FD_NOT_SUPPLIED);

        return -1;

    }



    if (qemu_isdigit(fdname[0])) {

        qerror_report(QERR_INVALID_PARAMETER_VALUE, "fdname",

                      "a name not starting with a digit");

        return -1;

    }



    fd = dup(fd);

    if (fd == -1) {

        if (errno == EMFILE)

            qerror_report(QERR_TOO_MANY_FILES);

        else

            qerror_report(QERR_UNDEFINED_ERROR);

        return -1;

    }



    QLIST_FOREACH(monfd, &mon->fds, next) {

        if (strcmp(monfd->name, fdname) != 0) {

            continue;

        }



        close(monfd->fd);

        monfd->fd = fd;

        return 0;

    }



    monfd = qemu_mallocz(sizeof(mon_fd_t));

    monfd->name = qemu_strdup(fdname);

    monfd->fd = fd;



    QLIST_INSERT_HEAD(&mon->fds, monfd, next);

    return 0;

}
