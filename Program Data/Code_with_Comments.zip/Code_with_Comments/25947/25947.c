/* FUNC: This function is responsible for decoding the primary header information of a picture in the VC-9 video format.

DETAILS: The function processes the input GetBitContext to extract and interpret the primary header information for a picture. It reads various flags and parameters from the input bitstream, determines the picture type based on the decoding context, and dispatches the decoding process to specific functions based on the picture type. Additionally, it handles the case where a frame is skipped and performs relevant logging.

NOTICE: It is important to ensure that the decoding context 'v' is properly initialized before calling this function. Care should be taken to handle the skipped frame scenario appropriately and manage the decoding status in subsequent processing stages.

TOKEN: 187
*/
static int standard_decode_picture_primary_header(VC9Context *v)

{

    GetBitContext *gb = &v->s.gb;

    int status = 0;



    if (v->finterpflag) v->interpfrm = get_bits(gb, 1);

    skip_bits(gb, 2); //framecnt unused

    if (v->rangered) v->rangeredfrm = get_bits(gb, 1);

    v->s.pict_type = get_bits(gb, 1);

    if (v->s.avctx->max_b_frames)

    {

        if (!v->s.pict_type)

        {

            if (get_bits(gb, 1)) v->s.pict_type = I_TYPE;

            else v->s.pict_type = B_TYPE;

        }

        else v->s.pict_type = P_TYPE;

    }

    else v->s.pict_type++;



    switch (v->s.pict_type)

    {

    case I_TYPE: status = decode_i_picture_header(v); break;

    case P_TYPE: status = decode_p_picture_primary_header(v); break;

    case BI_TYPE:

    case B_TYPE: status = decode_b_picture_primary_header(v); break;

    }



    if (status == FRAME_SKIPED)

    {

      av_log(v->s.avctx, AV_LOG_INFO, "Skipping frame...\n");

      return status;

    }

    return 0;

}
