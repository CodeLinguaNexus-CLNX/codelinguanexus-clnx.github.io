

/*
This function is responsible for handling changes in the virtual machine state specific to the VirtIO networking device.

Here's the detail:
When the virtual machine state changes, this function is invoked to manage the VirtIO networking device accordingly. If the virtual machine is in a running state, it proceeds to start the vhost backend, if appropriate, such as after migration. The function essentially ensures that the status of the VirtIO networking device aligns with the current state of the virtual machine.

Notable points to consider:
It's important to understand the specific behavior and requirements of the VirtIO networking device when integrating with different virtual machine states. Additionally, any dependencies or constraints related to the vhost backend startup should be taken into account to ensure the proper functioning of the networking device within the virtual machine environment.
*/
static void virtio_net_vmstate_change(void *opaque, int running, int reason)

{

    VirtIONet *n = opaque;

    if (!running) {

        return;

    }

    /* This is called when vm is started, it will start vhost backend if

     * appropriate e.g. after migration. */

    virtio_net_set_status(&n->vdev, n->vdev.status);

}
