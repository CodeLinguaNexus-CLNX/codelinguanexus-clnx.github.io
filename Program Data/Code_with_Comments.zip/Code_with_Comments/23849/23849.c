/*
This function is responsible for writing data and possibly file descriptors to a socket using scatter/gather I/O for improved performance. Here's the breakdown:

1. It prepares the message header (struct msghdr) to hold the data and control information for the socket operation.

2. If file descriptors are to be sent along with the data, it prepares the control message (CMSG) to hold the file descriptors using the SCM_RIGHTS mechanism.

3. It then attempts to write the message to the socket using the sendmsg function, handling potential errors and retries if the operation is temporarily unavailable (EAGAIN or EWOULDBLOCK) or interrupted by a signal (EINTR).

4. If the write operation fails, it sets an error message indicating the reason for the failure.

It's important to notice that this function provides a low-level interface for writing data and file descriptors to a socket, and it handles potential non-blocking and interrupt-related scenarios that can occur during socket I/O operations. Additionally, it supports scatter/gather I/O for efficiently writing multiple buffers to the socket.
*/
static ssize_t qio_channel_socket_writev(QIOChannel *ioc,

                                         const struct iovec *iov,

                                         size_t niov,

                                         int *fds,

                                         size_t nfds,

                                         Error **errp)

{

    QIOChannelSocket *sioc = QIO_CHANNEL_SOCKET(ioc);

    ssize_t ret;

    struct msghdr msg = { NULL, };

    char control[CMSG_SPACE(sizeof(int) * SOCKET_MAX_FDS)] = { 0 };

    size_t fdsize = sizeof(int) * nfds;

    struct cmsghdr *cmsg;



    msg.msg_iov = (struct iovec *)iov;

    msg.msg_iovlen = niov;



    if (nfds) {

        if (nfds > SOCKET_MAX_FDS) {

            error_setg_errno(errp, EINVAL,

                             "Only %d FDs can be sent, got %zu",

                             SOCKET_MAX_FDS, nfds);

            return -1;

        }



        msg.msg_control = control;

        msg.msg_controllen = CMSG_SPACE(sizeof(int) * nfds);



        cmsg = CMSG_FIRSTHDR(&msg);

        cmsg->cmsg_len = CMSG_LEN(fdsize);

        cmsg->cmsg_level = SOL_SOCKET;

        cmsg->cmsg_type = SCM_RIGHTS;

        memcpy(CMSG_DATA(cmsg), fds, fdsize);

    }



 retry:

    ret = sendmsg(sioc->fd, &msg, 0);

    if (ret <= 0) {

        if (socket_error() == EAGAIN ||

            socket_error() == EWOULDBLOCK) {

            return QIO_CHANNEL_ERR_BLOCK;

        }

        if (socket_error() == EINTR) {

            goto retry;

        }

        error_setg_errno(errp, socket_error(),

                         "Unable to write to socket");

        return -1;

    }

    return ret;

}
