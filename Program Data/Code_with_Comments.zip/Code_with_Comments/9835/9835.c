/*
First paragraph:
This function is responsible for overlaying frames in the input video stream.

Second paragraph:
Here's the detail: When this function is invoked, it takes the input link and input picture reference as its arguments. It then rescales the timestamp of the input picture reference according to the time bases of the input and output links. The function then checks if an overlay picture reference already exists, and if not, it sets the input picture reference as the overlay picture reference. Otherwise, it sets the input picture reference as the next overlay picture reference.

Third paragraph:
Needs to notice: When using this function, it is important to provide the appropriate input link and input picture reference. Additionally, it is necessary to ensure that the overlay picture references are managed correctly to achieve the desired overlay effect.

Generated comments token will be below 256/*

*/static void start_frame_overlay(AVFilterLink* inlink, AVFilterBufferRef* inpicref)

{

    AVFilterContext *ctx = inlink->dst;

    OverlayContext *over = ctx->priv;



    inpicref->pts = av_rescale_q(inpicref->pts, ctx->inputs[OVERLAY]->time_base,

                                 ctx->outputs[0]->time_base);



    if (!over->overpicref) over->overpicref      = inpicref;

    else                   over->overpicref_next = inpicref;

}
