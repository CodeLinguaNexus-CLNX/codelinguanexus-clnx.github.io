/*
This function is responsible for parsing the edit list (elst) atom in a MOV (QuickTime) multimedia file within the MOVContext structure. Here's the detailed breakdown of the function:

- It retrieves the pointer to the stream context of the last added stream from the MOV format context (fc) and sets it as the current stream context (sc) for edit list processing.
- The function reads the version and flags fields from the edit list atom without using the retrieved values, implying it is simply skipping over these fields.
- It reads the count of edit list entries and assigns it to the edit_count field in the stream context.
- Then it iterates through each edit entry and reads the track duration, media time, and media rate fields for each entry. It warns if the media time is not starting at 0, indicating a potential audio/video desync issue.
- Finally, it logs the edit count for the current track.

Needs to notice:
- This function assumes the byte order in the Atom is big-endian as it uses get_be24 and get_be32 to read the version, flags, edit count, track duration, media time, and media rate fields. Endianness considerations are critical for cross-platform compatibility.
- It provides a warning log if the media time does not start at 0, indicating a potential synchronization issue, and suggests that a patch addressing this issue would be welcomed.
- The function focuses solely on parsing the edit list atom and updating the internal state of the MOV format context and stream context accordingly. Any further error handling or recovery in case of malformed data is not explicitly shown in this function.
*/
static int mov_read_elst(MOVContext *c, ByteIOContext *pb, MOVAtom atom)

{

    MOVStreamContext *sc = c->fc->streams[c->fc->nb_streams-1]->priv_data;

    int i, edit_count;



    get_byte(pb); /* version */

    get_be24(pb); /* flags */

    edit_count= sc->edit_count = get_be32(pb);     /* entries */



    for(i=0; i<edit_count; i++){

        int time;

        get_be32(pb); /* Track duration */

        time = get_be32(pb); /* Media time */

        get_be32(pb); /* Media rate */

        if (time != 0)

            av_log(c->fc, AV_LOG_WARNING, "edit list not starting at 0, "

                   "a/v desync might occur, patch welcome\n");

    }

    dprintf(c->fc, "track[%i].edit_count = %i\n", c->fc->nb_streams-1, sc->edit_count);

    return 0;

}
