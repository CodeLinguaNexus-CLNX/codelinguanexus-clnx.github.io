/*
First Paragraph:
This function is responsible for performing a specific operation on the input data, which involves a combination of mathematical computations to achieve a certain transformation.

Second Paragraph:
Here's the detail of the function: It includes a series of inline operations that manipulate the input pixel data and apply specific arithmetic calculations to generate the desired output. The function is designed to efficiently process the input data and produce the transformed result according to the defined algorithm.

Third Paragraph:
Needs to notice that the generated comment tokens in the function should be kept below 256 characters to ensure proper handling and processing of the inline code within the context of the program structure.
*/static inline void FUNC(idctSparseCol_extrashift)(int16_t* col)

#else

static inline void FUNC(idctSparseColPut)(pixel *dest, int line_size,

                                          int16_t *col)

{

    int a0, a1, a2, a3, b0, b1, b2, b3;



    IDCT_COLS;



    dest[0] = av_clip_pixel((a0 + b0) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a1 + b1) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a2 + b2) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a3 + b3) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a3 - b3) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a2 - b2) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a1 - b1) >> COL_SHIFT);

    dest += line_size;

    dest[0] = av_clip_pixel((a0 - b0) >> COL_SHIFT);

}



static inline void FUNC(idctSparseColAdd)(pixel *dest, int line_size,

                                          int16_t *col)

{

    int a0, a1, a2, a3, b0, b1, b2, b3;



    IDCT_COLS;



    dest[0] = av_clip_pixel(dest[0] + ((a0 + b0) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a1 + b1) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a2 + b2) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a3 + b3) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a3 - b3) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a2 - b2) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a1 - b1) >> COL_SHIFT));

    dest += line_size;

    dest[0] = av_clip_pixel(dest[0] + ((a0 - b0) >> COL_SHIFT));

}



static inline void FUNC(idctSparseCol)(int16_t *col)

#endif

{

    int a0, a1, a2, a3, b0, b1, b2, b3;



    IDCT_COLS;



    col[0 ] = ((a0 + b0) >> COL_SHIFT);

    col[8 ] = ((a1 + b1) >> COL_SHIFT);

    col[16] = ((a2 + b2) >> COL_SHIFT);

    col[24] = ((a3 + b3) >> COL_SHIFT);

    col[32] = ((a3 - b3) >> COL_SHIFT);

    col[40] = ((a2 - b2) >> COL_SHIFT);

    col[48] = ((a1 - b1) >> COL_SHIFT);

    col[56] = ((a0 - b0) >> COL_SHIFT);

}
