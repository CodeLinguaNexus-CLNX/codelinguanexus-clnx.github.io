/*
This function is responsible for retrieving a value from memory based on the given memory operation type. Here's the detail:

- If the memory operation type is MO_8, it loads an 8-bit unsigned value from the memory location pointed to by the program counter (s->pc). The program counter is then incremented by 1.

- If the memory operation type is MO_16, it loads a 16-bit unsigned value from the memory location pointed to by s->pc. The program counter is then incremented by 2.

- If the memory operation type is MO_32, or in the case of TARGET_X86_64, MO_64, it loads a 32-bit (or 64-bit in the case of x86_64 target) value from the memory location pointed to by s->pc. The program counter is then incremented by 4.

- If the memory operation type is none of the above cases, the function will abort, indicating an unsupported memory operation type.

It is important to notice the following when using this function: [Specify any important considerations or precautions to take when using this function, if applicable].
*/
static inline uint32_t insn_get(CPUX86State *env, DisasContext *s, TCGMemOp ot)

{

    uint32_t ret;



    switch (ot) {

    case MO_8:

        ret = cpu_ldub_code(env, s->pc);

        s->pc++;

        break;

    case MO_16:

        ret = cpu_lduw_code(env, s->pc);

        s->pc += 2;

        break;

    case MO_32:

#ifdef TARGET_X86_64

    case MO_64:

#endif

        ret = cpu_ldl_code(env, s->pc);

        s->pc += 4;

        break;

    default:

        tcg_abort();

    }

    return ret;

}
