/*
This function is responsible for generating a mask value used in NVIC (Nested Vectored Interrupt Controller) operations to prioritize interrupts based on the configured priority group.

Here's the detail:
- The function utilizes the priority group value (prigroup) from the NVICState data structure to construct a bitmask that can be used to filter or prioritize interrupts based on their respective priority levels.
- It employs bitwise operations to generate the bitmask: the value ~0U, which represents the bitwise negation of 0U (all bits set to 1), is left-shifted by (s->prigroup + 1) positions. This effectively sets the most significant bits of the resulting value to 0, creating a mask that can be applied to interrupt priority values.
- The resulting bitmask can then be used in NVIC operations to ensure that only interrupts with a priority higher than a certain level (determined by the priority group setting) are serviced, based on the ARM Cortex-M interrupt priority logic.

Needs to notice:
- When utilizing this function or the generated bitmask in NVIC operations, it's crucial to have a clear understanding of the configured priority group and how it affects interrupt prioritization within the system.
- Developers should ensure that the priority group setting is properly initialized and maintained to reflect the intended interrupt handling behavior within the system, as inaccuracies in the priority group setting can lead to unexpected interrupt prioritization and handling.
- When modifying this function or any related logic, thorough testing and validation of the NVIC behavior in response to different interrupt scenarios, including edge cases, are essential to guarantee correct and reliable operation of the interrupt controller.
*/
void aio_set_event_notifier(AioContext *ctx,

                            EventNotifier *notifier,

                            bool is_external,

                            EventNotifierHandler *io_read,

                            AioPollFn *io_poll)

{

    aio_set_fd_handler(ctx, event_notifier_get_fd(notifier), is_external,

                       (IOHandler *)io_read, NULL, io_poll, notifier);

}
