/*This function is responsible for performing an immediate exit operation, terminating the program's execution.

Here's the detail: Upon invocation, the function calls the "exit" function with a status code of 0, which triggers the immediate termination of the program. This results in the cleanup of resources and the cessation of all process execution.

Need's to notice: When using this function, it's important to be aware that the "exit" function terminates the program without executing any further code or cleanup operations. Therefore, ensure that no critical tasks or resources remain unresolved before invoking this function, as they will not be handled during the exit process.*/
static void do_quit(int argc, const char **argv)

{

    exit(0);

}
