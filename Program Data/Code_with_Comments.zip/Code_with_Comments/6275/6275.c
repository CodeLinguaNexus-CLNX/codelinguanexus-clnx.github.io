/*
This function is responsible for initializing a device object with its properties and state. Here's the detail:

- It sets the initial values for various properties of the device, such as `hotplugged`, `instance_id_alias`, and `realized`.
- It adds boolean properties to the device object, including "realized", "hotpluggable", and "hotplugged", using the `object_property_add_bool` function.
- It iterates through the class hierarchy of the device object and adds properties from each class using `qdev_property_add_legacy` and `qdev_property_add_static`.
- It adds a link property, "parent_bus", to the device object, which refers to the parent bus object.
- It initializes a list of GPIOs for the device.

Needs to notice:
- This function is integral for setting up a device object with its initial properties and linking it to the parent bus.
- It handles the initialization of properties, including legacy and static properties, and sets up the necessary links for the device.
- Care should be taken to ensure that the initialization of properties and state is accurate and reflects the intended behavior of the device in the system.

If you have additional questions or need further explanation, feel free to ask for more details!
*/

static void device_initfn(Object* obj)

{

    DeviceState *dev = DEVICE(obj);

    ObjectClass *class;

    Property *prop;



    if (qdev_hotplug) {

        dev->hotplugged = 1;

        qdev_hot_added = true;

    }



    dev->instance_id_alias = -1;

    dev->realized = false;



    object_property_add_bool(obj, "realized",

                             device_get_realized, device_set_realized, NULL);

    object_property_add_bool(obj, "hotpluggable",

                             device_get_hotpluggable, NULL, NULL);

    object_property_add_bool(obj, "hotplugged",

                             device_get_hotplugged, device_set_hotplugged,

                             &error_abort);



    class = object_get_class(OBJECT(dev));

    do {

        for (prop = DEVICE_CLASS(class)->props; prop && prop->name; prop++) {

            qdev_property_add_legacy(dev, prop, &error_abort);

            qdev_property_add_static(dev, prop, &error_abort);

        }

        class = object_class_get_parent(class);

    } while (class != object_class_by_name(TYPE_DEVICE));



    object_property_add_link(OBJECT(dev), "parent_bus", TYPE_BUS,

                             (Object **)&dev->parent_bus, NULL, 0,

                             &error_abort);

    QLIST_INIT(&dev->gpios);

}
