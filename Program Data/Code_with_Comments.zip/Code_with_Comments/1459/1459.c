/*
This function is responsible for retrieving coefficients for IMC (Intensified Modified Codebook) encoding within the context of an AVCodec. Here's the detail:

- The function iterates over a set number of frequency bands (denoted by BANDS) and checks for certain conditions related to their length and flags.
- For each band, if the sum of length arrays is non-zero and certain flag conditions are met, the function proceeds to process individual coefficients within the band.
- It calculates the code word length 'cw_len' and initializes the code word 'cw' to zero.
- If the code word length is non-zero and specific flag conditions are met, it checks the bit count and potential overflow before retrieving the code word using the 'get_bits' function from the bitstream.
- It logs a warning if there's a potential problem with the code word length exceeding a certain limit.
- The retrieved code word is then assigned to the corresponding position in the 'codewords' array within the channel context.

Needs to notice:
- This function operates within the context of the IMC encoding and utilizes specific structures and functions, such as AVCodecContext, IMCContext, and get_bits.
- Understanding the IMC encoding standard and the associated data structures is essential for comprehending the detailed operations within this function.
- The function includes error checking and warning logging to ensure the integrity of the coefficient retrieval process, particularly in relation to potential bit count issues.
*/
static void imc_get_coeffs(AVCodecContext *avctx,

                           IMCContext *q, IMCChannel *chctx)

{

    int i, j, cw_len, cw;



    for (i = 0; i < BANDS; i++) {

        if (!chctx->sumLenArr[i])

            continue;

        if (chctx->bandFlagsBuf[i] || chctx->bandWidthT[i]) {

            for (j = band_tab[i]; j < band_tab[i + 1]; j++) {

                cw_len = chctx->CWlengthT[j];

                cw = 0;



                if (cw_len && (!chctx->bandFlagsBuf[i] || !chctx->skipFlags[j])) {

                    if (get_bits_count(&q->gb) + cw_len > 512) {

                        av_log(avctx, AV_LOG_WARNING,

                            "Potential problem on band %i, coefficient %i"

                            ": cw_len=%i\n", i, j, cw_len);

                    }



                    cw = get_bits(&q->gb, cw_len);

                }



                chctx->codewords[j] = cw;

            }

        }

    }

}
