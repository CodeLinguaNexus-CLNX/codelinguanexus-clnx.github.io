/**
 * This function is responsible for injecting errors into the block I/O path for debugging purposes.
 * Here's the detail: The function interacts with the block debug state to insert errors based on the provided rule. It may schedule the error injection to occur immediately or defer it, depending on the rule configuration. After injecting the error, the function returns the specified error code to simulate the I/O failure.
 * Need's to notice: When using this function, ensure that the block driver state and debug rules are properly set up. Take into consideration the potential impact of injecting errors into the I/O path and the necessity of handling this in a controlled testing environment.
 */
static int inject_error(BlockDriverState *bs, BlkdebugRule *rule)

{

    BDRVBlkdebugState *s = bs->opaque;

    int error = rule->options.inject.error;

    bool immediately = rule->options.inject.immediately;



    if (rule->options.inject.once) {

        QSIMPLEQ_REMOVE(&s->active_rules, rule, BlkdebugRule, active_next);

        remove_rule(rule);

    }



    if (!immediately) {

        aio_co_schedule(qemu_get_current_aio_context(), qemu_coroutine_self());

        qemu_coroutine_yield();

    }



    return -error;

}
