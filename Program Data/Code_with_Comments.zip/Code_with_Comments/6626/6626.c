/*
This function is responsible for probing and identifying film files based on the signature present in the provided probe data.

Here's the detail of the function:
The function uses a simple check to compare the first 4 bytes of the provided buffer with the FILM_TAG signature using the AV_RB32 macro. If the signature is found at the beginning of the buffer, the function returns the maximum probe score, indicating a high likelihood of being a film file.

Needs to notice:
This function is a basic probe function that only checks for the presence of the film file signature at the beginning of the buffer. It does not perform additional validation or detailed analysis of the probe data.
Developers should ensure that this probe function is used in conjunction with other probing mechanisms to accurately identify film files and avoid false positives.
For more robust detection, additional checks and validation may be necessary, such as examining the entire file structure or metadata to confirm the file type.
*/

static int film_probe(AVProbeData* p)
{
    if (AV_RB32(&p->buf[0]) != FILM_TAG)
    return AVPROBE_SCORE_MAX;
}