/*
First Paragraph:
This function is responsible for writing data to the CSRHCI (Cambridge Silicon Radio Host Controller Interface) communication channel, facilitating the transmission of input buffer data while managing the internal state of the communication interface.

Second Paragraph:
Here's the detailed description of the function: Upon invocation, the csrhci_write function takes the provided buffer data and length, and writes the data to the CSRHCI communication channel through the CharDriverState structure. It also manages the state of the communication interface, including updating the input buffer length, copying the input data to the internal packet buffer, and processing the incoming packets based on their header and data lengths. The function continuously checks for complete packets in the input buffer and processes them accordingly, ensuring efficient communication handling.

Third Paragraph:
Needs to notice that when utilizing this function, special attention should be given to the management of the input buffer and the internal state of the CSRHCI communication interface. It is important to handle the enable flag appropriately to control the writing of data, and to manage the input buffer length and packet processing logic to prevent potential buffer overflows or data loss. Additionally, developers should consider the specific requirements and constraints of the CSRHCI communication protocol and ensure that the function operates within the defined limits, especially with regard to memory usage and packet processing efficiency.

*/static int csrhci_write(struct CharDriverState* chr,

                const uint8_t *buf, int len)

{

    struct csrhci_s *s = (struct csrhci_s *) chr->opaque;

    int plen = s->in_len;



    if (!s->enable)

        return 0;



    s->in_len += len;

    memcpy(s->inpkt + plen, buf, len);



    while (1) {

        if (s->in_len >= 2 && plen < 2)

            s->in_hdr = csrhci_header_len(s->inpkt) + 1;



        if (s->in_len >= s->in_hdr && plen < s->in_hdr)

            s->in_data = csrhci_data_len(s->inpkt) + s->in_hdr;



        if (s->in_len >= s->in_data) {

            csrhci_in_packet(s, s->inpkt);



            memmove(s->inpkt, s->inpkt + s->in_len, s->in_len - s->in_data);

            s->in_len -= s->in_data;

            s->in_hdr = INT_MAX;

            s->in_data = INT_MAX;

            plen = 0;

        } else

            break;

    }



    return len;

}
