/*This function is responsible for freeing all elements in a queue and executing a specified function for each element to release associated resources.

Here's the detail: Upon invocation, the function iterates through the queue and dequeues each element, applying the provided 'free_func' to release resources associated with each element.

Need's to notice: It is crucial to ensure that the 'free_func' is properly implemented to release the resources associated with the elements in the queue. Additionally, care should be taken to avoid memory leaks by ensuring that all elements in the queue are properly deallocated. Proper error handling should also be in place to handle any unexpected issues during the queue freeing process.*/
void ff_schro_queue_free(FFSchroQueue *queue, void (*free_func)(void *))

{

    while (queue->p_head)

        free_func(ff_schro_queue_pop(queue));

}
