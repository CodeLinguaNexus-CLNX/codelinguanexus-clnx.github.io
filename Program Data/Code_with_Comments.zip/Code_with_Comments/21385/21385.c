/*Function description: This function is responsible for updating the DTS (Decoding Time Stamp) shift value within the context of a MOV (QuickTime) stream. It adjusts the DTS shift based on the provided duration.

Detail: If the provided duration is less than zero, the function compares the current DTS shift value with the negative of the provided duration, and assigns the larger of the two values to the DTS shift. This ensures that the DTS shift reflects the maximum negative duration encountered during the processing of the MOV stream.

Need's to notice: It's important to note that the function performs the DTS shift update based on the provided duration and the current DTS shift value. Additionally, the function handles negative durations by adjusting the DTS shift to accommodate the most negative duration encountered.*/
static void mov_update_dts_shift(MOVStreamContext *sc, int duration)

{

    if (duration < 0) {





        sc->dts_shift = FFMAX(sc->dts_shift, -duration);

