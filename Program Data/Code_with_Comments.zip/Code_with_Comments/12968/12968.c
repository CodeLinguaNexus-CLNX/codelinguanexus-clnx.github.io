/*
This function is responsible for adding a new block to the RDMA (Remote Direct Memory Access) context in a C program. Here's the detail:

- It takes in the RDMAContext structure pointer, the name of the block, a host address, the offset within the block, and the length of the block as parameters.
- It allocates memory for a new RDMALocalBlock and initializes its attributes based on the provided input parameters and the current state of the RDMA context.
- If there are existing blocks in the local RAM, it handles the migration of existing block information to the new array of blocks.
- It sets various attributes of the new block, including block name, local host address, offset, length, index, chunk information, transit and unregister bitmaps, remote keys, and flags indicating whether the block is a RAM block.
- If a blockmap exists in the RDMA context, it inserts the new block into the blockmap using its offset as the key for quick access.
- It also performs a trace of the added block for debugging or logging purposes.
- Finally, it increments the count of blocks in the local RAM and returns 0 upon successful addition of the block.

Needs to notice:
- Proper memory management is crucial, including memory allocation and deallocation for new and old blocks respectively.
- The function heavily involves manipulation of block data structures and their associated metadata, so care should be taken to ensure the integrity of the data and the correctness of the operations performed.
- Error handling and edge cases, such as when the local RAM is uninitialized or if the blockmap is not present, should be considered for robustness and reliability.
- Monitoring the trace output and debugging information can aid in diagnosing issues related to block addition and RDMA context management.
*/
static int rdma_add_block(RDMAContext *rdma, const char *block_name,

                         void *host_addr,

                         ram_addr_t block_offset, uint64_t length)

{

    RDMALocalBlocks *local = &rdma->local_ram_blocks;

    RDMALocalBlock *block;

    RDMALocalBlock *old = local->block;



    local->block = g_malloc0(sizeof(RDMALocalBlock) * (local->nb_blocks + 1));



    if (local->nb_blocks) {

        int x;



        if (rdma->blockmap) {

            for (x = 0; x < local->nb_blocks; x++) {

                g_hash_table_remove(rdma->blockmap,

                                    (void *)(uintptr_t)old[x].offset);

                g_hash_table_insert(rdma->blockmap,

                                    (void *)(uintptr_t)old[x].offset,

                                    &local->block[x]);

            }

        }

        memcpy(local->block, old, sizeof(RDMALocalBlock) * local->nb_blocks);

        g_free(old);

    }



    block = &local->block[local->nb_blocks];



    block->block_name = g_strdup(block_name);

    block->local_host_addr = host_addr;

    block->offset = block_offset;

    block->length = length;

    block->index = local->nb_blocks;

    block->src_index = ~0U; /* Filled in by the receipt of the block list */

    block->nb_chunks = ram_chunk_index(host_addr, host_addr + length) + 1UL;

    block->transit_bitmap = bitmap_new(block->nb_chunks);

    bitmap_clear(block->transit_bitmap, 0, block->nb_chunks);

    block->unregister_bitmap = bitmap_new(block->nb_chunks);

    bitmap_clear(block->unregister_bitmap, 0, block->nb_chunks);

    block->remote_keys = g_malloc0(block->nb_chunks * sizeof(uint32_t));



    block->is_ram_block = local->init ? false : true;



    if (rdma->blockmap) {

        g_hash_table_insert(rdma->blockmap, (void *) block_offset, block);

    }



    trace_rdma_add_block(block_name, local->nb_blocks,

                         (uintptr_t) block->local_host_addr,

                         block->offset, block->length,

                         (uintptr_t) (block->local_host_addr + block->length),

                         BITS_TO_LONGS(block->nb_chunks) *

                             sizeof(unsigned long) * 8,

                         block->nb_chunks);



    local->nb_blocks++;



    return 0;

}
