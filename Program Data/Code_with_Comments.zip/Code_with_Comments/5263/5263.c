/*
This function is responsible for setting a specific bit in the IRQ_queue_t structure to indicate that a particular IRQ (interrupt request) is pending.

Here��s the detail: Upon invocation, the function increments the pending count within the IRQ_queue_t structure to reflect the addition of a pending IRQ. Subsequently, it uses the set_bit function or method to set the bit corresponding to the given IRQ number in the queue, indicating that the IRQ is now pending.

Need��s to notice: When utilizing this function, it��s important to ensure that the IRQ_queue_t structure is properly initialized and that the n_IRQ parameter corresponds to a valid IRQ number within the specified range. Additionally, any interactions or dependencies with the IRQ handling system should be taken into consideration, and proper synchronization mechanisms should be employed if this function is accessed concurrently to ensure thread safety and prevent race conditions.

*/static inline void IRQ_setbit(IRQ_queue_t* q, int n_IRQ)

{

    q->pending++;

    set_bit(q->queue, n_IRQ);

}
