/*
This function is responsible for polling the completion queue of an RDMAContext to retrieve completed work requests and their associated details. Here's the breakdown of the details:

- The function takes in an RDMAContext pointer and pointers to wr_id_out and byte_len as parameters.

- It calls ibv_poll_cq to poll the completion queue for a single completion. If no completion is available, it sets wr_id_out to a special value (RDMA_WRID_NONE) and returns 0.

- If an error occurs during polling (ret < 0), it prints an error message and returns the error code.

- Upon a successful completion, the function extracts the wr_id and checks the status of the completion. If the status is not success, it prints an error message containing the status and the corresponding wr_id description.

- Depending on the value of wr_id, different actions are taken. For example, if wr_id corresponds to an RDMA write operation, it processes the completion details, clears the corresponding bit, and decrements nb_sent if necessary.

- The function then updates wr_id_out with the wr_id of the completion and, if byte_len is provided, updates byte_len with the length of the data transfer.

- Finally, the function returns 0 to indicate successful completion.

Points to notice:
1. The function handles different completion types based on the wr_id and performs specific actions accordingly.
2. Error handling is done by printing error messages and returning appropriate error codes.
3. The function interfaces with the RDMA completion queue and extracts information about completed work requests, allowing for further processing based on the completion type.

In summary, this function plays a crucial role in handling the completion of work requests in the RDMA context and provides detailed information about the completed operations. It also demonstrates error handling and specific actions based on the type of completion.
*/
static uint64_t qemu_rdma_poll(RDMAContext *rdma, uint64_t *wr_id_out,

                               uint32_t *byte_len)

{

    int ret;

    struct ibv_wc wc;

    uint64_t wr_id;



    ret = ibv_poll_cq(rdma->cq, 1, &wc);



    if (!ret) {

        *wr_id_out = RDMA_WRID_NONE;

        return 0;

    }



    if (ret < 0) {

        fprintf(stderr, "ibv_poll_cq return %d!\n", ret);

        return ret;

    }



    wr_id = wc.wr_id & RDMA_WRID_TYPE_MASK;



    if (wc.status != IBV_WC_SUCCESS) {

        fprintf(stderr, "ibv_poll_cq wc.status=%d %s!\n",

                        wc.status, ibv_wc_status_str(wc.status));

        fprintf(stderr, "ibv_poll_cq wrid=%s!\n", wrid_desc[wr_id]);



        return -1;

    }



    if (rdma->control_ready_expected &&

        (wr_id >= RDMA_WRID_RECV_CONTROL)) {

        DDDPRINTF("completion %s #%" PRId64 " received (%" PRId64 ")"

                  " left %d\n", wrid_desc[RDMA_WRID_RECV_CONTROL],

                  wr_id - RDMA_WRID_RECV_CONTROL, wr_id, rdma->nb_sent);

        rdma->control_ready_expected = 0;

    }



    if (wr_id == RDMA_WRID_RDMA_WRITE) {

        uint64_t chunk =

            (wc.wr_id & RDMA_WRID_CHUNK_MASK) >> RDMA_WRID_CHUNK_SHIFT;

        uint64_t index =

            (wc.wr_id & RDMA_WRID_BLOCK_MASK) >> RDMA_WRID_BLOCK_SHIFT;

        RDMALocalBlock *block = &(rdma->local_ram_blocks.block[index]);



        DDDPRINTF("completions %s (%" PRId64 ") left %d, "

                 "block %" PRIu64 ", chunk: %" PRIu64 " %p %p\n",

                 print_wrid(wr_id), wr_id, rdma->nb_sent, index, chunk,

                 block->local_host_addr, (void *)block->remote_host_addr);



        clear_bit(chunk, block->transit_bitmap);



        if (rdma->nb_sent > 0) {

            rdma->nb_sent--;

        }



        if (!rdma->pin_all) {

            /*

             * FYI: If one wanted to signal a specific chunk to be unregistered

             * using LRU or workload-specific information, this is the function

             * you would call to do so. That chunk would then get asynchronously

             * unregistered later.

             */

#ifdef RDMA_UNREGISTRATION_EXAMPLE

            qemu_rdma_signal_unregister(rdma, index, chunk, wc.wr_id);

#endif

        }

    } else {

        DDDPRINTF("other completion %s (%" PRId64 ") received left %d\n",

            print_wrid(wr_id), wr_id, rdma->nb_sent);

    }



    *wr_id_out = wc.wr_id;

    if (byte_len) {

        *byte_len = wc.byte_len;

    }



    return  0;

}
