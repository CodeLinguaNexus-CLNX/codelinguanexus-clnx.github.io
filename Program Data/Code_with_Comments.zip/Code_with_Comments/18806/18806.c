/*
This function is responsible for decoding the Group Of Blocks (GOB) header in the H.263 video codec.

Here's the detail of how it works: 
- First, it checks for the GOB Start Code, which is a specific bit pattern indicating the beginning of a GOB.
- If a GOB Start Code is found, the function continues to process the header.
- The function handles the presence of any GSTUFF, which are additional bits that may be added for error detection or correction purposes. It skips the zero bits and seeks for the first '1' bit.
- Next, it checks if the video is using slice structured mode or not. In slice structured mode, the function decodes a Macroblock Address (MBA) and performs additional checks for the MB number.
- If not in slice structured mode, it reads in the GOB number (GN) and calculates the starting MB coordinates based on the GOB index and the GOB number.
- The function then reads the GOB Frame ID (GFID) and the quantization scale (qscale) value, which determines the level of compression for the GOB.
- It performs a check to ensure that the calculated MB coordinates do not exceed the height of the video frame and that the qscale value is not zero.
- Finally, the function returns 0 if the GOB header decoding is successful.

Here are some points to note about using this function:
- The function expects a valid MPEG-4 MpegEncContext structure as input.
- It assumes that the bitstream being decoded is compliant with the H.263 video coding standard.
- The function should only be called when processing H.263 video streams.
- Any errors encountered during the decoding process will cause the function to return -1.

Please keep in mind that the above explanation is based on the provided code segment, and there may be additional context or dependencies that are not apparent from this snippet alone.
*/
static int h263_decode_gob_header(MpegEncContext *s)

{

    unsigned int val, gob_number;

    int left;



    /* Check for GOB Start Code */

    val = show_bits(&s->gb, 16);

    if(val)

        return -1;



        /* We have a GBSC probably with GSTUFF */

    skip_bits(&s->gb, 16); /* Drop the zeros */

    left= get_bits_left(&s->gb);

    //MN: we must check the bits left or we might end in a infinite loop (or segfault)

    for(;left>13; left--){

        if(get_bits1(&s->gb)) break; /* Seek the '1' bit */

    }

    if(left<=13)

        return -1;



    if(s->h263_slice_structured){

        if(get_bits1(&s->gb)==0)

            return -1;



        ff_h263_decode_mba(s);



        if(s->mb_num > 1583)

            if(get_bits1(&s->gb)==0)

                return -1;



        s->qscale = get_bits(&s->gb, 5); /* SQUANT */

        if(get_bits1(&s->gb)==0)

            return -1;

        skip_bits(&s->gb, 2); /* GFID */

    }else{

        gob_number = get_bits(&s->gb, 5); /* GN */

        s->mb_x= 0;

        s->mb_y= s->gob_index* gob_number;

        skip_bits(&s->gb, 2); /* GFID */

        s->qscale = get_bits(&s->gb, 5); /* GQUANT */

    }



    if(s->mb_y >= s->mb_height)

        return -1;



    if(s->qscale==0)

        return -1;



    return 0;

}
