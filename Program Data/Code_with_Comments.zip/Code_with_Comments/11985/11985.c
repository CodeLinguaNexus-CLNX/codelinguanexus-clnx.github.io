/*
This function is responsible for unpacking compressed data using the LZ algorithm. Here's the breakdown of the details:

- It takes as input the compressed source data (`src`), the destination buffer for the uncompressed data (`dest`), and the length of the destination buffer (`dest_len`).

- The function initializes pointers and variables to keep track of the compressed and uncompressed data, queue management, and various parameters used in the decompression process.

- It begins by reading the total data length from the compressed source and sets up the initial state for queue management based on the header information.

- It then enters a loop to process the compressed data. It examines the tags in the compressed data to determine how to decompress each segment.

- If the tag indicates a literal copy operation, it directly copies the data to the destination buffer from the compressed source, while also updating the queue with the copied data.

- If the tag indicates a back-reference operation, it retrieves the offset and length information, and copies data from the queue based on this information, updating both the destination buffer and the queue accordingly.

- The process continues until all the compressed data is unpacked and copied to the destination buffer.

- Error handling is implemented to ensure that the function does not exceed the boundaries of the destination buffer and that it properly handles edge cases in the compressed data.

- Special attention is given to specific tag values and header patterns to adjust the decompression process accordingly.

Some key points to notice:
1. The function relies on a pre-defined queue to efficiently handle back-references during decompression.
2. It utilizes bitwise operations to interpret the tags and extract offset and length information from the compressed data.
3. Error conditions, such as exceeding the destination buffer size, are checked and handled within the function.
4. There are specific conditions based on tag values and header patterns that trigger adjustments in the decompression process.

In summary, this function plays a crucial role in decompressing data using the LZ algorithm efficiently and with consideration for different compression techniques and header formats. It requires a deep understanding of the LZ algorithm and data compression principles.
*/
static void lz_unpack(const unsigned char *src, unsigned char *dest, int dest_len)

{

    const unsigned char *s;

    unsigned char *d;

    unsigned char *d_end;

    unsigned char queue[QUEUE_SIZE];

    unsigned int qpos;

    unsigned int dataleft;

    unsigned int chainofs;

    unsigned int chainlen;

    unsigned int speclen;

    unsigned char tag;

    unsigned int i, j;



    s = src;

    d = dest;

    d_end = d + dest_len;

    dataleft = AV_RL32(s);

    s += 4;

    memset(queue, 0x20, QUEUE_SIZE);

    if (AV_RL32(s) == 0x56781234) {

        s += 4;

        qpos = 0x111;

        speclen = 0xF + 3;

    } else {

        qpos = 0xFEE;

        speclen = 100;  /* no speclen */

    }



    while (dataleft > 0) {

        tag = *s++;

        if ((tag == 0xFF) && (dataleft > 8)) {

            if (d + 8 > d_end)

                return;

            for (i = 0; i < 8; i++) {

                queue[qpos++] = *d++ = *s++;

                qpos &= QUEUE_MASK;

            }

            dataleft -= 8;

        } else {

            for (i = 0; i < 8; i++) {

                if (dataleft == 0)

                    break;

                if (tag & 0x01) {

                    if (d + 1 > d_end)

                        return;

                    queue[qpos++] = *d++ = *s++;

                    qpos &= QUEUE_MASK;

                    dataleft--;

                } else {

                    chainofs = *s++;

                    chainofs |= ((*s & 0xF0) << 4);

                    chainlen = (*s++ & 0x0F) + 3;

                    if (chainlen == speclen)

                        chainlen = *s++ + 0xF + 3;

                    if (d + chainlen > d_end)

                        return;

                    for (j = 0; j < chainlen; j++) {

                        *d = queue[chainofs++ & QUEUE_MASK];

                        queue[qpos++] = *d++;

                        qpos &= QUEUE_MASK;

                    }

                    dataleft -= chainlen;

                }

                tag >>= 1;

            }

        }

    }

}
