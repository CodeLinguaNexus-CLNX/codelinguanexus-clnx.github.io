/*
This function is responsible for processing a specific command specified by the busid parameter.

Here's the detailed explanation of the code snippet:
- The function takes three parameters: a pointer to an ESPState structure (s), a pointer to a buffer (buf) that holds the command data, and a busid of type uint8_t.
- A debug print statement is used to print the value of the busid.
- The variable "lun" is set to the lower 3 bits of the busid value using a bitwise AND with 7.
- A new SCSI request (scsi_req) is created using the scsi_req_new function, specifying the current device (s->current_dev), the target (0), and the logical unit number (lun). The created request is assigned to s->current_req.
- The command data is enqueued in the SCSI request using the scsi_req_enqueue function, and the returned data length is stored in the "datalen" variable.
- The transfer length (ti_size) of the current transfer is set to datalen.
- If datalen is not zero, indicating that there is data to be transferred:
  - The register ESP_RSTAT is updated to indicate that a transfer is complete (STAT_TC). The DMA-related registers are reset.
  - Depending on the value of datalen, the register ESP_RSTAT is updated to indicate whether it is a send operation (STAT_DI) or receive operation (STAT_DO).
  - The SCSI request is continued using the scsi_req_continue function.
- The ESP_RINTR register is set with the interrupt status bits INTR_BS and INTR_FC.
- The ESP_RSEQ register is set with the SEQ_CD bit.
- An interrupt request is raised using the esp_raise_irq function.

Need to notice:
- The overall behavior and meaning of the registers and functions used in the code may require a deeper understanding of the system architecture and context in which this code is used.
- It is important to ensure that the proper values for the busid parameter are provided to ensure correct command processing.
- The specific functionality and handling of the SCSI request, data transfer, and interrupt handling depend on the larger system implementation.
*/
static void do_busid_cmd(ESPState *s, uint8_t *buf, uint8_t busid)

{

    int32_t datalen;

    int lun;



    DPRINTF("do_busid_cmd: busid 0x%x\n", busid);

    lun = busid & 7;

    s->current_req = scsi_req_new(s->current_dev, 0, lun, NULL);

    datalen = scsi_req_enqueue(s->current_req, buf);

    s->ti_size = datalen;

    if (datalen != 0) {

        s->rregs[ESP_RSTAT] = STAT_TC;

        s->dma_left = 0;

        s->dma_counter = 0;

        if (datalen > 0) {

            s->rregs[ESP_RSTAT] |= STAT_DI;

        } else {

            s->rregs[ESP_RSTAT] |= STAT_DO;

        }

        scsi_req_continue(s->current_req);

    }

    s->rregs[ESP_RINTR] = INTR_BS | INTR_FC;

    s->rregs[ESP_RSEQ] = SEQ_CD;

    esp_raise_irq(s);

}
