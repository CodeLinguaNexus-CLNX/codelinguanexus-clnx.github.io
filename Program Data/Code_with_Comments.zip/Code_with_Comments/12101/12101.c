/*
This function is responsible for performing vertical 8x8 block-wise intra prediction using the MSA (MIPS SIMD Architecture) instruction set.

Here's the detail: The `intra_predict_vert_8x8_msa` function takes as input a source block `src` and writes the vertically predicted block to the destination `dst` with the specified `dst_stride`. It initializes `src_data1` and `src_data2` by loading 32 bits of data from the source pointer and its subsequent offset. Then, it iterates over 8 rows, each time storing `src_data1` and `src_data2` into the destination `dst` and `dst + 4` respectively, and then increments the destination pointer by `dst_stride`.

Need's to notice: When using this function, it's important to ensure that the source and destination pointers are properly aligned and that the stride meets memory alignment requirements. Additionally, developers should be aware of the specific SIMD architecture (MSA in this case) for which the function is optimized and understand the potential impact of this optimization in terms of performance and compatibility. Since the function utilizes MSA SIMD instructions, it is crucial to ensure that the code is properly tested and validated for correctness and efficiency on MSA-enabled hardware platforms.

*/static void intra_predict_vert_8x8_msa(uint8_t* src, uint8_t* dst,

                                       int32_t dst_stride)

{

    uint32_t row;

    uint32_t src_data1, src_data2;



    src_data1 = LW(src);

    src_data2 = LW(src + 4);



    for (row = 8; row--;) {

        SW(src_data1, dst);

        SW(src_data2, (dst + 4));

        dst += dst_stride;

    }

}
