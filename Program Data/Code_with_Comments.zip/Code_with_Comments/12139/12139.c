/*
Function:
This function, "tcg_code_size", is responsible for calculating the total size of generated TCG (Tiny Code Generator) code.

Details:
The function first acquires a lock on the region and then iterates through the TCG contexts to calculate the size of the generated code in each context. It ensures that the code size does not exceed the buffer size and accumulates the total code size. Finally, it releases the lock and returns the total code size.

Usage Notes:
When generating comments, ensure that the token count does not exceed 256.

If you need further clarification on any specific part of this function, feel free to ask!

*/size_t tcg_code_size(void)

{

    unsigned int i;

    size_t total;



    qemu_mutex_lock(&region.lock);

    total = region.agg_size_full;

    for (i = 0; i < n_tcg_ctxs; i++) {

        const TCGContext *s = tcg_ctxs[i];

        size_t size;



        size = atomic_read(&s->code_gen_ptr) - s->code_gen_buffer;

        g_assert(size <= s->code_gen_buffer_size);

        total += size;

    }

    qemu_mutex_unlock(&region.lock);

    return total;

}
