/*
This function is responsible for converting a hex color value into YUV color space and storing the result in an array.

Here's the detail:
- The function takes a string argument representing a color in six hex digits, similar to the format used in HTML tags but without the "#" symbol.
- It uses strtol to parse the hex color string into an integer value.
- The integer value is then split into its RGB components (red, green, and blue) by performing bitwise shifting operations.
- The RGB components are then converted to YUV color space using the RGB_TO_Y, RGB_TO_U, and RGB_TO_V macros, and the resulting YUV values are stored in the padcolor array.

Needs to notice:
- This function assumes that the input argument represents a valid hex color value and does not perform extensive validation on the input.
- Proper conversion between RGB and YUV color spaces is essential for accurate color representation and may require further consideration depending on the specific color conversion algorithm being used.
- Understanding the usage and potential limitations of the padcolor array is important, as it may be used elsewhere in the codebase for color-related operations.
*/
static void opt_pad_color(const char *arg) {

    /* Input is expected to be six hex digits similar to

       how colors are expressed in html tags (but without the #) */

    int rgb = strtol(arg, NULL, 16);

    int r,g,b;



    r = (rgb >> 16);

    g = ((rgb >> 8) & 255);

    b = (rgb & 255);



    padcolor[0] = RGB_TO_Y(r,g,b);

    padcolor[1] = RGB_TO_U(r,g,b,0);

    padcolor[2] = RGB_TO_V(r,g,b,0);

}
