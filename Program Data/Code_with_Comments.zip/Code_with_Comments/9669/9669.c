/*
First Paragraph:
This function is responsible for obtaining the physical address, along with the protection attributes, for a given virtual address in the context of the CPUState. It manages the translation of virtual addresses to physical addresses, while also handling protection attributes and access permissions based on the specified address, read/write mode, and access type.

Second Paragraph:
Here's the detailed description of the function: Upon invocation, the get_physical_address function begins by checking whether the given address falls within the P1, P2, and P4 areas that do not require translation. If the address is within these ranges or falls beyond 0xe0000000, it evaluates the address based on the current supervisor state and access mode. If the MMU is disabled, it directly calculates the physical address and sets the protection attributes. Otherwise, it resorts to the MMU for address translation and protection attribute retrieval by calling the get_mmu_address function.

Third Paragraph:
Needs to notice that when using this function, it's crucial to consider the memory management unit (MMU) configuration and the supervisor/user mode to ensure proper address translation and protection attribute retrieval. Developers should be mindful of the address ranges that do not require translation and the implications of MMU disablement on address calculation. Additionally, understanding the access permissions and protection attributes associated with the physical address is essential for handling memory access and protection mechanisms effectively within the CPUState context.

*/int get_physical_address(CPUState* env, target_ulong* physical,

			 int *prot, target_ulong address,

			 int rw, int access_type)

{

    /* P1, P2 and P4 areas do not use translation */

    if ((address >= 0x80000000 && address < 0xc0000000) ||

	address >= 0xe0000000) {

	if (!(env->sr & SR_MD)

	    && (address < 0xe0000000 || address > 0xe4000000)) {

	    /* Unauthorized access in user mode (only store queues are available) */

	    fprintf(stderr, "Unauthorized access\n");

	    return (rw & PAGE_WRITE) ? MMU_DTLB_MISS_WRITE :

		MMU_DTLB_MISS_READ;

	}

	/* Mask upper 3 bits */

	*physical = address & 0x1FFFFFFF;

	*prot = PAGE_READ | PAGE_WRITE;

	return MMU_OK;

    }



    /* If MMU is disabled, return the corresponding physical page */

    if (!env->mmucr & MMUCR_AT) {

	*physical = address & 0x1FFFFFFF;

	*prot = PAGE_READ | PAGE_WRITE;

	return MMU_OK;

    }



    /* We need to resort to the MMU */

    return get_mmu_address(env, physical, prot, address, rw, access_type);

}
