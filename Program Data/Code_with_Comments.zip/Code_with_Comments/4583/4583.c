/*
This function is responsible for performing a dynamic cast and assertion check for an object's class hierarchy in a C++-like object-oriented framework.

Here's the detail: The function attempts to dynamically cast the given class pointer to the specified type (typename) using the object_class_dynamic_cast function. If the dynamic cast fails and the input class pointer is not null (indicating the object exists), the function prints an error message to stderr, indicating the failure, and then aborts the program.

Needs to notice: When using this function, it's important to ensure that the ObjectClass hierarchy and the dynamic_cast functionality are correctly implemented and utilized within the framework or codebase. Additionally, the function's behavior resembles the dynamic_cast behavior in C++ and is intended for similar use cases, such as runtime type checking and casting within an object-oriented system. Care should be taken to use this function in scenarios where dynamic type checking and assertion of class hierarchy are essential for program correctness and reliability. However, it's also crucial to consider other error handling and logging mechanisms in the broader context of the application.
*/

ObjectClass* object_class_dynamic_cast_assert(ObjectClass* class,

                                              const char *typename,

                                              const char *file, int line,

                                              const char *func)

{

    ObjectClass *ret = object_class_dynamic_cast(class, typename);



    if (!ret && class) {

        fprintf(stderr, "%s:%d:%s: Object %p is not an instance of type %s\n",

                file, line, func, class, typename);

        abort();

    }



    return ret;

}
