/*
This function is responsible for comparing two 64-bit unsigned integers byte by byte and producing a comparison result. Here's the detail:

- The function takes two 64-bit unsigned integers (op1 and op2) as input for comparison.

- It initializes a result variable (res) to store the comparison result.

- The function then iterates through each byte of the input integers (8 bytes in total) using a loop.

- For each iteration, it extracts the individual bytes of op1 and op2 by shifting and masking.

- It compares the two extracted bytes and sets the corresponding bit in the result variable (res) if the byte from op1 is greater than or equal to the byte from op2.

- After iterating through all the bytes, the function returns the final comparison result as a 64-bit unsigned integer.

Needs to notice:

- This function performs a byte-wise unsigned integer comparison and produces a 64-bit comparison result, where each bit represents the comparison result for a corresponding byte position.

- The comparison is performed in a little-endian manner, with the least significant byte being processed first.

- It operates with the assumption that both input integers are 64-bit unsigned and accessible for reading.

- The function's comparison logic may be used in scenarios where byte-level comparison and result aggregation are required for 64-bit unsigned integers.

- As with any low-level comparison function, care should be taken to ensure the correct interpretation of the comparison result based on the application requirements.
*/
uint64_t helper_cmpbge(uint64_t op1, uint64_t op2)

{

    uint8_t opa, opb, res;

    int i;



    res = 0;

    for (i = 0; i < 8; i++) {

        opa = op1 >> (i * 8);

        opb = op2 >> (i * 8);

        if (opa >= opb) {

            res |= 1 << i;

        }

    }

    return res;

}
