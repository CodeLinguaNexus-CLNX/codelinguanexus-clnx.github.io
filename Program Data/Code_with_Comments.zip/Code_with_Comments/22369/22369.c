/*This function is responsible for performing a comparison operation between two values T0 and T1, and then setting the value of T0 based on the result of the comparison.

Here's the detail of the function: The function first compares the values of T0 and T1. If T0 is less than T1, it sets T0 to 0x08. If T0 is greater than T1, it sets T0 to 0x04. If neither of these conditions is met, it sets T0 to 0x02.

Need's to notice that the function uses simple conditional logic to determine the appropriate value for T0 based on the comparison result. It's important to understand the context in which this function is used and the implications of setting T0 to specific values based on the comparison outcome. Additionally, the RETURN() function is called at the end of the function, indicating that it likely returns control to the calling code or function.*/
PPC_OP(cmpl)

{

    if (T0 < T1) {

        T0 = 0x08;

    } else if (T0 > T1) {

        T0 = 0x04;

    } else {

        T0 = 0x02;

    }

    RETURN();

}
