/*
This function is responsible for performing a NEON (ARM Advanced SIMD) "unzip" operation on NEON registers based on the specified parameters. Here's the detail:

- The function, named "gen_neon_unzip", takes as input the NEON register number "reg", the quantity "q", the temporary register number "tmp", and the size of the elements being processed.
- Within a loop that iterates over the NEON registers, the function loads pairs of values from the specified NEON register using the "neon_load_reg" function for processing.
- Depending on the specified size, a NEON "unzip" operation is performed on the loaded values. If the size is 0, an 8-bit "unzip" operation is performed; if the size is 1, a 16-bit "unzip" operation is performed; if the size is 2, no operation is performed; and for any other size, the function aborts with an error.
- After the "unzip" operation, the resulting values are stored back to the temporary registers using the "neon_store_scratch" function.

Needs to notice:
- The function assumes that the input register numbers and size are within valid ranges and compatible with the NEON operations being performed.
- It is important to ensure that the "neon_load_reg" and "neon_store_scratch" functions are properly implemented and handle the register and data transfer operations correctly.
- Any specific requirements or constraints for the input parameters (such as alignment or register availability) should be handled by the caller before invoking this function.
- The caller should ensure proper error handling in case the function encounters unsupported operations or other exceptional conditions.
*/
static void gen_neon_unzip(int reg, int q, int tmp, int size)

{

    int n;

    TCGv t0, t1;



    for (n = 0; n < q + 1; n += 2) {

        t0 = neon_load_reg(reg, n);

        t1 = neon_load_reg(reg, n + 1);

        switch (size) {

        case 0: gen_neon_unzip_u8(t0, t1); break;

        case 1: gen_neon_zip_u16(t0, t1); break; /* zip and unzip are the same.  */

        case 2: /* no-op */; break;

        default: abort();

        }

        neon_store_scratch(tmp + n, t0);

        neon_store_scratch(tmp + n + 1, t1);

    }

}
