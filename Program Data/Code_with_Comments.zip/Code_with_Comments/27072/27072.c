/*
This function is responsible for initiating an asynchronous I/O write operation on a block driver, utilizing a vector of QEMU I/O vectors. Here's the detail:

- It takes the block driver state, sector number, I/O vector, the number of sectors, a completion callback function, and an opaque pointer as parameters.
- Internally, it invokes the bdrv_aio_rw_vector() function with the appropriate parameters, specifying a write operation by passing 1 as the last argument.

Needs to notice:
- The function abstracts the process of initiating an asynchronous I/O write operation, providing a simplified interface for performing write operations on block devices.
- It follows an asynchronous I/O design pattern, allowing non-blocking I/O operations to be performed, which is crucial for high-performance I/O operations, especially in virtualized environments.
- The completion callback function provided as an argument will be invoked when the write operation is completed, and it needs to handle any necessary post-write processing.
- Understanding the usage and interactions of the opaque pointer and how it is utilized in the completion callback function is essential for properly handling asynchronous write completions.
*/
BlockDriverAIOCB *bdrv_aio_writev(BlockDriverState *bs, int64_t sector_num,
                                  QEMUIOVector *iov, int nb_sectors,
                                  BlockDriverCompletionFunc *cb, void *opaque)
{
    return bdrv_aio_rw_vector(bs, sector_num, iov, nb_sectors,
                              cb, opaque, 1);
}