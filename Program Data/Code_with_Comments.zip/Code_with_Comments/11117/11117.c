/*
This function, bdrv_snapshot_delete, is responsible for deleting a snapshot identified by the given snapshot_id within the context of a BlockDriverState. Here's the detail:

- It begins by obtaining the BlockDriver associated with the BlockDriverState and checks if it exists. If the BlockDriver is not available, it returns -ENOMEDIUM, indicating a lack of a storage medium error.

- If the BlockDriver's bdrv_snapshot_delete function pointer is available, it proceeds to call the snapshot deletion function within the BlockDriver itself, delegating the operation to the specific BlockDriver implementation.

- If the BlockDriver does not have a dedicated bdrv_snapshot_delete function, the function checks if the BlockDriverState has an associated file and recursively calls bdrv_snapshot_delete on the file's BlockDriverState.

- If none of the above conditions are met, it returns -ENOTSUP, indicating that the operation is not supported by the BlockDriver or its associated file.

Needs to notice:
- This function's behavior is dependent on the specific BlockDriver implementation and its support for snapshot deletion.
- It delegates the snapshot deletion operation to the underlying BlockDriver if available, or recursively to the associated file's BlockDriverState if necessary.
- Care should be taken to ensure that proper error handling and fallback mechanisms are in place, especially when dealing with various types of BlockDrivers and their capabilities.
*/
int bdrv_snapshot_delete(BlockDriverState *bs, const char *snapshot_id)

{

    BlockDriver *drv = bs->drv;

    if (!drv) {

        return -ENOMEDIUM;

    }

    if (drv->bdrv_snapshot_delete) {

        return drv->bdrv_snapshot_delete(bs, snapshot_id);

    }

    if (bs->file) {

        return bdrv_snapshot_delete(bs->file, snapshot_id);

    }

    return -ENOTSUP;

}
