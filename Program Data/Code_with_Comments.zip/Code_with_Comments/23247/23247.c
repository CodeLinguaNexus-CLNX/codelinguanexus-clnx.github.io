/**
 * This function is responsible for testing the conversion of a string representing a metric value (such as "12345k") to a 64-bit signed integer, based on the SI metric system prefixes.
 *
 * Here's the detail: The function initializes a string representing a metric value and a pointer to store the end of the parsed string. It then calls the qemu_strtosz_metric function to convert the string to a 64-bit signed integer, considering the metric prefix "k" as kilo (10^3). The test verifies that the conversion result matches the expected value and that the end pointer points to the correct position in the input string.
 *
 * Needs to notice: This test ensures the correct functionality of the string-to-integer conversion with metric prefixes, highlighting the importance of accurate parsing and conversion of metric values using the specified prefixes. It's essential to validate the behavior for different input strings and metric prefixes to maintain consistent and reliable conversion functionality.
 */
static void test_qemu_strtosz_metric(void)

{

    const char *str = "12345k";

    char *endptr = NULL;

    int64_t res;



    res = qemu_strtosz_metric(str, &endptr);

    g_assert_cmpint(res, ==, 12345000);

    g_assert(endptr == str + 6);

}
