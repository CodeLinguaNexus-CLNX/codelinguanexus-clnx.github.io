/*
This function is responsible for parsing and handling the FMTP (Format-specific Media Type Parameters) configuration for a given codec within the context of an audio-visual media stream. Here's the breakdown:
- It starts by checking the codec_id to determine the type of codec being processed (e.g., MPEG4, AAC).
- If the codec is identified as MPEG4 or AAC and the attribute "config" is found, the function decodes the hexa encoded value of the parameter.
- After decoding the hexa encoded parameter, the function dynamically allocates memory for the extradata within the codec context and copies the decoded parameter into this extradata. It also updates the extradata_size accordingly.

Needs to notice:
- This function only handles the FMTP configuration for MPEG4 and AAC codecs, and it ignores the configuration for other codec types.
- The hex_to_data function is assumed to properly handle the decoding of the hexa encoded parameter. Ensure that this function behaves as expected and does not introduce any vulnerabilities.
- It is essential to consider memory management for the allocation of extradata, as well as potential memory leaks if the allocation fails or if the function is called multiple times for the same codec context.
- When using this function, it's important to understand the FMTP configuration requirements specific to MPEG4 and AAC codecs and ensure that the parsed configuration is appropriately utilized within the codec context for decoding and processing the media stream.
*/

static void sdp_parse_fmtp_config(AVCodecContext* codec, char* attr, char* value)

{

    switch (codec->codec_id) {

        case CODEC_ID_MPEG4:

        case CODEC_ID_AAC:

            if (!strcmp(attr, "config")) {

                /* decode the hexa encoded parameter */

                int len = hex_to_data(NULL, value);



                codec->extradata = av_mallocz(len + FF_INPUT_BUFFER_PADDING_SIZE);

                if (!codec->extradata)

                    return;

                codec->extradata_size = len;

                hex_to_data(codec->extradata, value);

            }

            break;

        default:

            break;

    }

    return;

}