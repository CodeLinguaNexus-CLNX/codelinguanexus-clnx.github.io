/*This function is responsible for adding a timer into a sorted list based on its expire_time in the QEMUTimerList.

Here's the detail: The function starts by finding the appropriate position to insert the timer in the sorted list by iterating through the active timers and comparing their expire_time with the given expire_time. Once the correct position is found, the function updates the expire_time and next attributes of the timer to be added and rearranges the pointers to include the timer in the sorted order.

Need's to notice: When using this function, it's important to ensure that the timer_list and the timers are properly initialized and managed to avoid potential memory corruption or undefined behavior. Additionally, the function assumes that the timers in the list are sorted by their expire_time, and any deviation from this expectation may lead to incorrect behavior.*/
static bool timer_mod_ns_locked(QEMUTimerList *timer_list,

                                QEMUTimer *ts, int64_t expire_time)

{

    QEMUTimer **pt, *t;



    /* add the timer in the sorted list */

    pt = &timer_list->active_timers;

    for (;;) {

        t = *pt;

        if (!timer_expired_ns(t, expire_time)) {

            break;

        }

        pt = &t->next;

    }

    ts->expire_time = MAX(expire_time, 0);

    ts->next = *pt;

    *pt = ts;



    return pt == &timer_list->active_timers;

}
