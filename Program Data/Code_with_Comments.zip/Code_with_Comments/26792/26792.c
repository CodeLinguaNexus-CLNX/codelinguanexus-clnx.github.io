/*
   This function is responsible for initiating an I2C transfer on the specified I2C bus, targeting a specific device address, and indicating the direction of data transfer.

   Here's the detail of the function:
   When called, this function searches for the I2C slave device corresponding to the provided address within the specified I2C bus. If the slave device is found, the function sets the current device of the bus to the identified slave and triggers the appropriate start event based on the transfer direction (send or receive) as indicated by the 'recv' parameter. It then returns a value to indicate the success or failure of the initiation.

   Needs to notice that:
   - This function relies on the DeviceState and i2c_slave structures to access and manipulate the details of the I2C bus and the slave devices. It assumes a specific I2C bus and slave device architecture for the transfer initiation.
   - It handles the scenario where the bus is already busy and interprets it as a repeated start condition, enabling the function to manage transfer sequences effectively.
*/
int i2c_start_transfer(i2c_bus *bus, int address, int recv)

{

    DeviceState *qdev;

    i2c_slave *slave = NULL;



    LIST_FOREACH(qdev, &bus->qbus.children, sibling) {

        slave = I2C_SLAVE_FROM_QDEV(qdev);

        if (slave->address == address)

            break;

    }



    if (!slave)

        return 1;



    /* If the bus is already busy, assume this is a repeated

       start condition.  */

    bus->current_dev = slave;

    slave->info->event(slave, recv ? I2C_START_RECV : I2C_START_SEND);

    return 0;

}
