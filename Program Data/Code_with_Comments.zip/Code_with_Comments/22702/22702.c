/*This function is responsible for probing a buffer to determine if it contains an SRT (SubRip) subtitle file.

Here's the detail: Upon invocation, the function first checks for and skips over the UTF-8 Byte Order Mark (BOM) if present in the buffer. It then skips any leading line break characters. Subsequently, it iterates through the buffer, attempting to parse the timestamp information of the subtitle file. Specifically, it looks for the timestamps in the format "HH:MM:SS,MMM --> HH:MM:SS,MMM" and checks if it can successfully parse the required fields. If the parsing is successful for at least one set of timestamps, the function returns the maximum probe score (AVPROBE_SCORE_MAX) indicating a high likelihood of the buffer containing an SRT subtitle file. If the parsing fails for both sets of timestamps, the function returns a score of 0, indicating a low likelihood of the buffer containing an SRT subtitle file.

Need's to notice: When utilizing this function, it is important to note that it only performs a heuristic check based on the format of the timestamp lines and does not guarantee the integrity or correctness of the SRT subtitle file. Additionally, the function assumes that the buffer contains valid SRT data and does not perform exhaustive validation of the entire subtitle file structure. It's important to complement this probing function with thorough validation of the SRT file content before further processing.*/
static int srt_probe(AVProbeData *p)

{

    const unsigned char *ptr = p->buf;

    int i, v, num = 0;



    if (AV_RB24(ptr) == 0xEFBBBF)

        ptr += 3;  /* skip UTF-8 BOM */



    while (*ptr == '\r' || *ptr == '\n')

        ptr++;

    for (i=0; i<2; i++) {

        if ((num == i || num + 1 == i)

            && sscanf(ptr, "%*d:%*2d:%*2d%*1[,.]%*3d --> %*d:%*2d:%*2d%*1[,.]%3d", &v) == 1)

            return AVPROBE_SCORE_MAX;

        num = atoi(ptr);

        ptr += strcspn(ptr, "\n") + 1;

    }

    return 0;

}
