/*This function is responsible for parsing and handling NUMA (Non-Uniform Memory Access) node options provided in QEMU configuration, including CPU and memory specifications for each NUMA node.

Here's the detail of the function:
- The function begins by determining the NUMA node number to be configured based on the provided options, or assigns the next available node number if not explicitly specified.
- It then performs various validations and settings for the NUMA node:
  - Checks if the specified node number exceeds the maximum allowed NUMA nodes and returns an error if so.
  - Verifies that the specified NUMA node is not a duplicate of an already configured node.
  - Iterates through the list of CPUs assigned to the NUMA node and sets the corresponding bits in the bitmap representing the CPUs associated with the node, performing range checks on the CPU indices.
  - Validates and sets the memory size or memory device associated with the NUMA node, providing error messages for conflicting memory options or ambiguous memory device specifications.
  - Marks the NUMA node as "present" and updates the maximum NUMA node ID if necessary.

Need's to notice:
- This function is essential for configuring NUMA nodes within the QEMU virtualization environment, allowing users to specify CPU and memory characteristics for each NUMA node.
- It performs extensive validation to ensure correct and non-overlapping configuration of NUMA nodes, including CPU indices and memory settings.
- Users and developers need to be mindful of the specific requirements and constraints related to NUMA configuration within QEMU, especially regarding the uniqueness of node IDs, memory configuration, and CPU assignments.
*/
static void parse_numa_node(NumaNodeOptions *node, QemuOpts *opts, Error **errp)

{

    uint16_t nodenr;

    uint16List *cpus = NULL;



    if (node->has_nodeid) {

        nodenr = node->nodeid;

    } else {

        nodenr = nb_numa_nodes;

    }



    if (nodenr >= MAX_NODES) {

        error_setg(errp, "Max number of NUMA nodes reached: %"

                   PRIu16 "", nodenr);

        return;

    }



    if (numa_info[nodenr].present) {

        error_setg(errp, "Duplicate NUMA nodeid: %" PRIu16, nodenr);

        return;

    }



    for (cpus = node->cpus; cpus; cpus = cpus->next) {

        if (cpus->value >= max_cpus) {

            error_setg(errp,

                       "CPU index (%" PRIu16 ")"

                       " should be smaller than maxcpus (%d)",

                       cpus->value, max_cpus);

            return;

        }

        bitmap_set(numa_info[nodenr].node_cpu, cpus->value, 1);

    }



    if (node->has_mem && node->has_memdev) {

        error_setg(errp, "qemu: cannot specify both mem= and memdev=");

        return;

    }



    if (have_memdevs == -1) {

        have_memdevs = node->has_memdev;

    }

    if (node->has_memdev != have_memdevs) {

        error_setg(errp, "qemu: memdev option must be specified for either "

                   "all or no nodes");

        return;

    }



    if (node->has_mem) {

        uint64_t mem_size = node->mem;

        const char *mem_str = qemu_opt_get(opts, "mem");

        /* Fix up legacy suffix-less format */

        if (g_ascii_isdigit(mem_str[strlen(mem_str) - 1])) {

            mem_size <<= 20;

        }

        numa_info[nodenr].node_mem = mem_size;

    }

    if (node->has_memdev) {

        Object *o;

        o = object_resolve_path_type(node->memdev, TYPE_MEMORY_BACKEND, NULL);

        if (!o) {

            error_setg(errp, "memdev=%s is ambiguous", node->memdev);

            return;

        }



        object_ref(o);

        numa_info[nodenr].node_mem = object_property_get_int(o, "size", NULL);

        numa_info[nodenr].node_memdev = MEMORY_BACKEND(o);

    }

    numa_info[nodenr].present = true;

    max_numa_nodeid = MAX(max_numa_nodeid, nodenr + 1);

}
