/*This function is responsible for decoding the sub-layer hierarchical rate allocation and rate control parameters in the context of High Efficiency Video Coding (HEVC).

Here's the detail: The function iterates through the number of coded picture buffer (CPB) entries specified by `nb_cpb` and reads the values from the input GetBitContext. It retrieves the bit_rate_value_minus1 and cpb_size_value_minus1 using the get_ue_golomb_long function. If `subpic_params_present` is true, it also reads the cpb_size_du_value_minus1 and bit_rate_du_value_minus1. Finally, it skips the cbr_flag using the skip_bits1 function.

Need's to notice: When using this function, it's important to ensure that the HEVCContext structure `s` and the GetBitContext `gb` are properly initialized with the appropriate values before calling this function. Additionally, the parameters `nb_cpb` and `subpic_params_present` should be set according to the specific HEVC stream being processed. Care must be taken to handle any potential errors or exceptional cases that may arise during the decoding process.*/
static void decode_sublayer_hrd(HEVCContext *s, int nb_cpb,

                                int subpic_params_present)

{

    GetBitContext *gb = &s->HEVClc.gb;

    int i;



    for (i = 0; i < nb_cpb; i++) {

        get_ue_golomb_long(gb); // bit_rate_value_minus1

        get_ue_golomb_long(gb); // cpb_size_value_minus1



        if (subpic_params_present) {

            get_ue_golomb_long(gb); // cpb_size_du_value_minus1

            get_ue_golomb_long(gb); // bit_rate_du_value_minus1

        }

        skip_bits1(gb); // cbr_flag

    }

}
