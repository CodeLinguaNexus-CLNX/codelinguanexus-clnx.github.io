/*
This function is responsible for handling the completion of a block job transaction and performing the necessary clean-up, especially in the case of aborting the transaction. It ensures proper handling of the jobs involved in the transaction and their associated asynchronous I/O contexts.

Here's the detail of the function: The function starts by retrieving the transaction associated with the block job and initializes variables for processing other jobs and their associated asynchronous I/O contexts. If the transaction is already in the process of aborting, the function returns early to let the responsible job handle the situation. If it's the first failed job, it marks the transaction as aborting and proceeds to cancel other jobs and release their associated I/O contexts. It then iterates through the other jobs in the transaction, cancels them as necessary, sets their status, and ensures their completion. Finally, it releases the asynchronous I/O contexts and completes the affected jobs.

Need's to notice that the function orchestrates the clean-up and handling of jobs within a block job transaction, especially in the context of aborting the transaction. It ensures that all involved jobs are properly canceled, their statuses are managed accordingly, and the associated I/O contexts are acquired and released correctly. The function also handles scenarios where the transaction involves multiple jobs and ensures their appropriate completion or cancellation based on the situation.

*/static void block_job_completed_txn_abort(BlockJob* job)

{

    AioContext *ctx;

    BlockJobTxn *txn = job->txn;

    BlockJob *other_job, *next;



    if (txn->aborting) {

        /*

         * We are cancelled by another job, which will handle everything.

         */

        return;

    }

    txn->aborting = true;

    /* We are the first failed job. Cancel other jobs. */

    QLIST_FOREACH(other_job, &txn->jobs, txn_list) {

        ctx = blk_get_aio_context(other_job->blk);

        aio_context_acquire(ctx);

    }

    QLIST_FOREACH(other_job, &txn->jobs, txn_list) {

        if (other_job == job || other_job->completed) {

            /* Other jobs are "effectively" cancelled by us, set the status for

             * them; this job, however, may or may not be cancelled, depending

             * on the caller, so leave it. */

            if (other_job != job) {

                block_job_cancel_async(other_job);

            }

            continue;

        }

        block_job_cancel_sync(other_job);

        assert(other_job->completed);

    }

    QLIST_FOREACH_SAFE(other_job, &txn->jobs, txn_list, next) {

        ctx = blk_get_aio_context(other_job->blk);

        block_job_completed_single(other_job);

        aio_context_release(ctx);

    }

}
