/*
This function is responsible for initializing the HEVC (High Efficiency Video Coding) codec parser context.

Here's the detail:

- It begins by accessing the HEVC context structure within the private data of the codec parser context, allowing for manipulation of HEVC-specific data and parameters.
- The function then allocates and zeros out memory for the HEVC local context, which is used for storing local decoding information and state during parsing and decoding operations.

Needs to notice:
- This initialization function assumes that the HEVC parser context has already been properly allocated and initialized prior to its invocation. Failure to do so may lead to unexpected behavior or memory access issues.
- Proper memory management is crucial when allocating memory for the HEVC local context to prevent memory leaks and ensure efficient resource usage.
- Any modifications or expansions to the HEVC parser context or its associated data structures should be carefully considered to maintain compatibility and integrity within the HEVC decoding workflow.
- It's important to ensure that the HEVC parser context is used and accessed within the appropriate scope and context to prevent unintended side effects or conflicts with other parts of the decoding process.
*/
static int hevc_init(AVCodecParserContext *s)

{

    HEVCContext  *h  = &((HEVCParseContext *)s->priv_data)->h;

    h->HEVClc = av_mallocz(sizeof(HEVCLocalContext));



    h->skipped_bytes_pos_size = INT_MAX;



    return 0;

}