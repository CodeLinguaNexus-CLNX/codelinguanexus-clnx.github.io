/*
This function is responsible for checking and handling CPU watchpoints in the context of CPU emulation. Here's the detail:

1. It first checks if the watchpoint has been hit, and if so, it raises a debug interrupt to trigger after the current instruction to handle the watchpoint.

2. It calculates the virtual address based on the memory IO virtual address, offset, and length mask.

3. It iterates through the watchpoints associated with the CPU and checks if the virtual address matches the watchpoint conditions. If a match is found, it updates the watchpoint flags and triggers the corresponding actions.

4. If a watchpoint is hit and has not been previously hit, it sets the CPU's watchpoint_hit field, locates the TranslationBlock (TB) for the memory IO program counter (PC), restores the CPU state, invalidates the TB, and handles whether to stop before access or generate code accordingly.

Needs to notice:
- The function should handle potential concurrency issues or race conditions related to watchpoint-hit handling in a multi-threaded environment.
- Proper synchronization mechanisms should be used to ensure the integrity of the watchpoint data structures during iteration and modification.
- Error handling for scenarios such as inability to find the TB for a given PC should be robust to prevent unexpected behavior during CPU emulation.
*/
static void check_watchpoint(int offset, int len_mask, int flags)

{

    CPUState *env = cpu_single_env;

    target_ulong pc, cs_base;

    TranslationBlock *tb;

    target_ulong vaddr;

    CPUWatchpoint *wp;

    int cpu_flags;



    if (env->watchpoint_hit) {

        /* We re-entered the check after replacing the TB. Now raise

         * the debug interrupt so that is will trigger after the

         * current instruction. */

        cpu_interrupt(env, CPU_INTERRUPT_DEBUG);

        return;

    }

    vaddr = (env->mem_io_vaddr & TARGET_PAGE_MASK) + offset;

    QTAILQ_FOREACH(wp, &env->watchpoints, entry) {

        if ((vaddr == (wp->vaddr & len_mask) ||

             (vaddr & wp->len_mask) == wp->vaddr) && (wp->flags & flags)) {

            wp->flags |= BP_WATCHPOINT_HIT;

            if (!env->watchpoint_hit) {

                env->watchpoint_hit = wp;

                tb = tb_find_pc(env->mem_io_pc);

                if (!tb) {

                    cpu_abort(env, "check_watchpoint: could not find TB for "

                              "pc=%p", (void *)env->mem_io_pc);

                }

                cpu_restore_state(tb, env, env->mem_io_pc);

                tb_phys_invalidate(tb, -1);

                if (wp->flags & BP_STOP_BEFORE_ACCESS) {

                    env->exception_index = EXCP_DEBUG;

                } else {

                    cpu_get_tb_cpu_state(env, &pc, &cs_base, &cpu_flags);

                    tb_gen_code(env, pc, cs_base, cpu_flags, 1);

                }

                cpu_resume_from_signal(env, NULL);

            }

        } else {

            wp->flags &= ~BP_WATCHPOINT_HIT;

        }

    }

}
