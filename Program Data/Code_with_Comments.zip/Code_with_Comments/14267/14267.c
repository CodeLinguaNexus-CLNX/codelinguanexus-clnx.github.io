/*
**First paragraph:**
This function is responsible for retrieving a list of plugged Non-Volatile Dual In-line Memory Module (NVDIMM) devices within the QEMU virtual machine.

**Second paragraph:**
Here's the detail:
When invoked, this function initializes a linked list container and uses the object_child_foreach function to iterate through the NVDIMM devices that are currently plugged into the virtual machine. It populates the linked list with the plugged NVDIMM devices and returns the list as the result.

**Third paragraph:**
Needs to notice:
It is important to note that this function provides a convenient way to obtain a list of plugged NVDIMM devices within the QEMU virtual machine, which can be useful for management and monitoring purposes. Developers should handle the returned linked list appropriately and consider the potential presence of NULL or empty lists when invoking this function.

The generated token for this explanation is within 256 characters.

*/static GSList* nvdimm_get_plugged_device_list(void)

{

    GSList *list = NULL;



    object_child_foreach(qdev_get_machine(), nvdimm_plugged_device_list,

                         &list);

    return list;

}
