/*
This function is responsible for comparing two 64-bit integer values. Here's the detail:

- The function, named "compare_int64", takes two constant pointers to void as input, representing the addresses of the two 64-bit integer values to be compared.
- Inside the function, it first dereferences the void pointers to obtain the actual 64-bit integer values by casting them to int64_t types.
- It then compares the two integer values and returns -1 if the first value is smaller, +1 if the first value is larger, and 0 if the two values are equal.

Needs to notice:
- Developers using this function should ensure that the pointers passed to it actually point to 64-bit integer values, as using pointers to other types could lead to undefined behavior.
- This function assumes that the input pointers are valid and properly aligned for dereferencing.
- It is important to note that the specific context in which this comparison function will be used, such as with sorting algorithms or data structures, will determine the exact implications of its behavior.
*/
static int compare_int64(const void *a, const void *b)

{

    int64_t va = *(int64_t *)a, vb = *(int64_t *)b;

    return va < vb ? -1 : va > vb ? +1 : 0;

}
