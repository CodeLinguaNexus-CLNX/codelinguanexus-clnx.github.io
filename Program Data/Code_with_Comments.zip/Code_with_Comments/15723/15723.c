/*
This function is responsible for iterating through the guest physical memory blocks and retrieving the next page's details. Here's the detail:

- Upon invocation, the function uses the input parameters `blockptr`, `pfnptr`, `bufptr`, and `s` to manage the iteration and retrieve information about the next page in the guest physical memory.

- The function first checks if `block` is NULL, which indicates the start of the iteration. If so, it initializes `block` to the first element in the list of guest physical blocks and sets the page number (`pfnptr`) based on the target start address of the block. It also ensures that the buffer pointer (`bufptr`) is correctly set to the host address if provided.

- If `block` is not NULL, the function calculates the address for the next page and determines whether it falls within the current block. If it does, the buffer pointer (`buf`) is calculated accordingly. If the next page spans across blocks, it proceeds to the next block and updates the necessary pointers.

- The function then updates the buffer pointer (`bufptr`) if required and returns true to indicate that the next page details have been successfully retrieved. If there are no more blocks to iterate through, the function returns false.

Needs to notice:
- It is crucial to ensure that the input parameters (`blockptr`, `pfnptr`, `bufptr`, `s`) are correctly initialized before calling this function to ensure the proper iteration
*/
static void decode_delta_l(uint8_t *dst,

                           const uint8_t *buf, const uint8_t *buf_end,

                           int w, int flag, int bpp, int dst_size)

{

    GetByteContext off0, off1, dgb, ogb;

    PutByteContext pb;

    unsigned poff0, poff1;

    int i, k, dstpitch;

    int planepitch_byte = (w + 7) / 8;

    int planepitch = ((w + 15) / 16) * 2;

    int pitch = planepitch * bpp;



    if (buf_end - buf <= 64)

        return;



    bytestream2_init(&off0, buf, buf_end - buf);

    bytestream2_init(&off1, buf + 32, buf_end - (buf + 32));

    bytestream2_init_writer(&pb, dst, dst_size);



    dstpitch = flag ? (((w + 7) / 8) * bpp): 2;



    for (k = 0; k < bpp; k++) {

        poff0 = bytestream2_get_be32(&off0);

        poff1 = bytestream2_get_be32(&off1);



        if (!poff0)

            continue;



        if (2LL * poff0 >= buf_end - buf)

            return;



        if (2LL * poff1 >= buf_end - buf)

            return;



        bytestream2_init(&dgb, buf + 2 * poff0, buf_end - (buf + 2 * poff0));

        bytestream2_init(&ogb, buf + 2 * poff1, buf_end - (buf + 2 * poff1));



        while ((bytestream2_peek_be16(&ogb)) != 0xFFFF) {

            uint32_t offset = bytestream2_get_be16(&ogb);

            int16_t cnt = bytestream2_get_be16(&ogb);

            uint16_t data;



            offset = ((2 * offset) / planepitch_byte) * pitch + ((2 * offset) % planepitch_byte) + k * planepitch;

            if (cnt < 0) {

                bytestream2_seek_p(&pb, offset, SEEK_SET);

                cnt = -cnt;

                data = bytestream2_get_be16(&dgb);

                for (i = 0; i < cnt; i++) {

                    bytestream2_put_be16(&pb, data);

                    bytestream2_skip_p(&pb, dstpitch - 2);

                }

            } else {

                bytestream2_seek_p(&pb, offset, SEEK_SET);

                for (i = 0; i < cnt; i++) {

                    data = bytestream2_get_be16(&dgb);

                    bytestream2_put_be16(&pb, data);

                    bytestream2_skip_p(&pb, dstpitch - 2);

                }

            }

        }

    }

}
