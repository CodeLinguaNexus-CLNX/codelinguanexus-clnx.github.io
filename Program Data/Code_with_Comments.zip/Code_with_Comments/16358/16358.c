/*
This function is responsible for flushing the decoding process for the VP8 video codec within the given AVCodecContext.

Here's the detail: Upon invocation, the function delegates the flushing operation to the vp8_decode_flush_impl function, passing the AVCodecContext along with 0 and 0 as parameters. This likely triggers the internal mechanisms within the VP8 decoder to discard any remaining buffered input, reset the decoding state, and prepare for a fresh decoding session without the influence of prior input data.

Needs to notice: When using this function, it is essential to be aware of the implications and potential impact of flushing the decoding process, as it may affect the consistency and correctness of subsequent decoding operations. Additionally, it's important to consider the specific behavior and requirements of the VP8 codec and any related resources in the AVCodecContext to ensure proper handling of the flushing operation. Furthermore, verifying the necessity of calling this function in the decoding workflow and understanding its interaction with other codec operations is crucial for achieving the desired decoding behavior.
*/
static void vp8_decode_flush(AVCodecContext *avctx)

{

    vp8_decode_flush_impl(avctx, 0, 0);

}
