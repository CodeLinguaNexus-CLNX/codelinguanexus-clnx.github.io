/*
This function is responsible for performing the necessary operations to handle a signal return on the S390X architecture. Here's the detail: The function takes the CPU state as input and retrieves the signal frame address from the CPU state. It then proceeds to trace the action of performing the signal return and attempts to lock the signal frame for reading.

The function retrieves the old mask from the signal frame and translates it into the target set. After that, it sets the signal mask accordingly. Then, it attempts to restore the signal registers from the signal frame. If successful, it unlocks the signal frame and returns a specified error code related to signal return.

Needs to notice:
1. This function is specific to the S390X architecture and is involved in the signal handling mechanism.
2. It operates by accessing and manipulating the signal frame and the signal mask.
3. It performs error handling by forcing a segmentation violation signal in case of failure and returns a specific error code related to signal return.

In summary, this function plays a critical role in handling the signal return process on the S390X architecture, ensuring proper signal handling and restoration of signal-related registers.
*/
long do_sigreturn(CPUS390XState *env)

{

    sigframe *frame;

    abi_ulong frame_addr = env->regs[15];

    target_sigset_t target_set;

    sigset_t set;



    trace_user_do_sigreturn(env, frame_addr);

    if (!lock_user_struct(VERIFY_READ, frame, frame_addr, 1)) {

        goto badframe;

    }

    __get_user(target_set.sig[0], &frame->sc.oldmask[0]);



    target_to_host_sigset_internal(&set, &target_set);

    set_sigmask(&set); /* ~_BLOCKABLE? */



    if (restore_sigregs(env, &frame->sregs)) {

        goto badframe;

    }



    unlock_user_struct(frame, frame_addr, 0);

    return -TARGET_QEMU_ESIGRETURN;



badframe:

    force_sig(TARGET_SIGSEGV);

    return 0;

}
