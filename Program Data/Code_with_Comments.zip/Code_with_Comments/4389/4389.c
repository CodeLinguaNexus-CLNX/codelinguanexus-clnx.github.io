/*
This function is responsible for determining whether the VirtIO serial device supports multi-port functionality.

Here��s the detail of the function. It takes a pointer to a VirtIOSerial structure as input, obtains the corresponding VirtIODevice pointer using the VIRTIO_DEVICE macro, and then calls the virtio_has_feature function to check if the VIRTIO_CONSOLE_F_MULTIPORT feature is supported by the device. The function returns a boolean value indicating whether multi-port support is present.

Needs to notice that this function relies on the virtio_has_feature function and assumes that the input VirtIOSerial pointer is valid and properly initialized. Users should ensure the validity of the input pointer and handle the result of the function call appropriately based on the requirements of the system or application.

*/static bool use_multiport(VirtIOSerial* vser)

{

    VirtIODevice *vdev = VIRTIO_DEVICE(vser);

    return virtio_has_feature(vdev, VIRTIO_CONSOLE_F_MULTIPORT);

}
