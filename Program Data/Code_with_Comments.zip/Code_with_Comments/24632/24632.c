/*
This function is responsible for generating MTPData containing object information based on the provided MTPState, MTPControl, and MTPObject parameters.

Here's the detail:
- The function allocates a new MTPData instance by calling usb_mtp_data_alloc() and assigns it to the variable 'd'.
- It emits a trace log to record the MTP operation of getting object information, including the address, handle, and path of the object.
- Various attributes of the MTPObject 'o' are added to the MTPData 'd' using helper functions like usb_mtp_add_u32, usb_mtp_add_u16, usb_mtp_add_str, and usb_mtp_add_time. These attributes include the storage ID, format, size, parent handle, association format-specific values, file name, and file creation/modification times.
- Conditional logic is applied based on the format of the MTPObject. If the format is FMT_ASSOCIATION, specific values are added to the MTPData; otherwise, different default values are added accordingly.
- Finally, an empty wide string is added to the MTPData before returning it.

Needs to notice:
- The function assumes familiarity with the MTP (Media Transfer Protocol) specification and the structure of MTPData. Users of this function must ensure that the MTPData is used appropriately within the context of MTP communication.
- The usage of the MTPState, MTPControl, and MTPObject parameters should comply with the expected state and control flow of the MTP subsystem.
- Care should be taken to handle memory allocation and deallocation of the MTPData 'd' to prevent memory leaks or invalid memory access.
- Understanding the file system attributes and MTP object hierarchy is crucial for correctly populating the MTPData with accurate object information.
- The conditional logic based on the object format should align with the defined behavior of different object formats within the MTP specification to ensure correct handling of object information.
*/
static MTPData *usb_mtp_get_object_info(MTPState *s, MTPControl *c,

                                        MTPObject *o)

{

    MTPData *d = usb_mtp_data_alloc(c);



    trace_usb_mtp_op_get_object_info(s->dev.addr, o->handle, o->path);



    usb_mtp_add_u32(d, QEMU_STORAGE_ID);

    usb_mtp_add_u16(d, o->format);

    usb_mtp_add_u16(d, 0);

    usb_mtp_add_u32(d, o->stat.st_size);



    usb_mtp_add_u16(d, 0);

    usb_mtp_add_u32(d, 0);

    usb_mtp_add_u32(d, 0);

    usb_mtp_add_u32(d, 0);

    usb_mtp_add_u32(d, 0);

    usb_mtp_add_u32(d, 0);

    usb_mtp_add_u32(d, 0);



    if (o->parent) {

        usb_mtp_add_u32(d, o->parent->handle);

    } else {

        usb_mtp_add_u32(d, 0);

    }

    if (o->format == FMT_ASSOCIATION) {

        usb_mtp_add_u16(d, 0x0001);

        usb_mtp_add_u32(d, 0x00000001);

        usb_mtp_add_u32(d, 0);

    } else {

        usb_mtp_add_u16(d, 0);

        usb_mtp_add_u32(d, 0);

        usb_mtp_add_u32(d, 0);

    }



    usb_mtp_add_str(d, o->name);

    usb_mtp_add_time(d, o->stat.st_ctime);

    usb_mtp_add_time(d, o->stat.st_mtime);

    usb_mtp_add_wstr(d, L"");



    return d;

}
