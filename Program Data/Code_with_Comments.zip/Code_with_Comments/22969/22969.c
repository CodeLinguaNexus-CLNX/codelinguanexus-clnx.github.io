/*This function is responsible for generating the effective address (EA) for the Motorola 68000 series CPU. It calculates the memory address used for load or store operations based on the addressing mode specified in the instruction. The function handles various addressing modes, including direct register access, indirect register addressing, displacement, and immediate values.

Here's the detail:
The function takes input parameters such as the CPU state, the instruction, operand size, value to be stored or loaded, and the type of EA operation (load or store). It then processes the instruction to determine the addressing mode and generates the effective address accordingly. This involves handling different types of addressing modes and performing relevant calculations to obtain the memory address.

Needs to notice:
1. The function supports a wide range of addressing modes specific to the Motorola 68000 CPU architecture.
2. It takes into account the operand size and the type of operation (load or store) to appropriately generate the effective address.
3. The function may involve handling exception cases, and care should be taken to ensure exception safety when using the generated effective address in subsequent operations.*/
static TCGv gen_ea(CPUM68KState *env, DisasContext *s, uint16_t insn,

                   int opsize, TCGv val, TCGv *addrp, ea_what what)

{

    TCGv reg;

    TCGv result;

    uint32_t offset;



    switch ((insn >> 3) & 7) {

    case 0: /* Data register direct.  */

        reg = DREG(insn, 0);

        if (what == EA_STORE) {

            gen_partset_reg(opsize, reg, val);

            return store_dummy;

        } else {

            return gen_extend(reg, opsize, what == EA_LOADS);

        }

    case 1: /* Address register direct.  */

        reg = AREG(insn, 0);

        if (what == EA_STORE) {

            tcg_gen_mov_i32(reg, val);

            return store_dummy;

        } else {

            return gen_extend(reg, opsize, what == EA_LOADS);

        }

    case 2: /* Indirect register */

        reg = AREG(insn, 0);

        return gen_ldst(s, opsize, reg, val, what);

    case 3: /* Indirect postincrement.  */

        reg = AREG(insn, 0);

        result = gen_ldst(s, opsize, reg, val, what);

        /* ??? This is not exception safe.  The instruction may still

           fault after this point.  */

        if (what == EA_STORE || !addrp)

            tcg_gen_addi_i32(reg, reg, opsize_bytes(opsize));

        return result;

    case 4: /* Indirect predecrememnt.  */

        {

            TCGv tmp;

            if (addrp && what == EA_STORE) {

                tmp = *addrp;

            } else {

                tmp = gen_lea(env, s, insn, opsize);

                if (IS_NULL_QREG(tmp))

                    return tmp;

                if (addrp)

                    *addrp = tmp;

            }

            result = gen_ldst(s, opsize, tmp, val, what);

            /* ??? This is not exception safe.  The instruction may still

               fault after this point.  */

            if (what == EA_STORE || !addrp) {

                reg = AREG(insn, 0);

                tcg_gen_mov_i32(reg, tmp);

            }

        }

        return result;

    case 5: /* Indirect displacement.  */

    case 6: /* Indirect index + displacement.  */

        return gen_ea_once(env, s, insn, opsize, val, addrp, what);

    case 7: /* Other */

        switch (insn & 7) {

        case 0: /* Absolute short.  */

        case 1: /* Absolute long.  */

        case 2: /* pc displacement  */

        case 3: /* pc index+displacement.  */

            return gen_ea_once(env, s, insn, opsize, val, addrp, what);

        case 4: /* Immediate.  */

            /* Sign extend values for consistency.  */

            switch (opsize) {

            case OS_BYTE:

                if (what == EA_LOADS) {

                    offset = cpu_ldsb_code(env, s->pc + 1);

                } else {

                    offset = cpu_ldub_code(env, s->pc + 1);

                }

                s->pc += 2;

                break;

            case OS_WORD:

                if (what == EA_LOADS) {

                    offset = cpu_ldsw_code(env, s->pc);

                } else {

                    offset = cpu_lduw_code(env, s->pc);

                }

                s->pc += 2;

                break;

            case OS_LONG:

                offset = read_im32(env, s);

                break;

            default:

                qemu_assert(0, "Bad immediate operand");

            }

            return tcg_const_i32(offset);

        default:

            return NULL_QREG;

        }

    }

    /* Should never happen.  */

    return NULL_QREG;

}
