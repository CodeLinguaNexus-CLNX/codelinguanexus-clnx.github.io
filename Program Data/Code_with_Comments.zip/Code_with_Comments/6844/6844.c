/**
 * This function is responsible for extracting the exponent part from a 64-bit floating point number.
 *
 * Here's the detail: The function performs a bitwise shift operation to extract the exponent field from the given 64-bit floating point number. It then applies a bitwise AND operation to isolate the exponent bits based on the IEEE 754 representation of double precision floating point numbers.
 *
 * Need's to notice: When using this function, it's important to ensure that the input float64 value represents a valid double precision floating point number to avoid undefined behavior. Additionally, proper interpretation of the extracted exponent should consider the specific floating point representation used.
 */INLINE int16 extractFloat64Exp( float64 a )

{



    return ( a>>52 ) & 0x7FF;



}
