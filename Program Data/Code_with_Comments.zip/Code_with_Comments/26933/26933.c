/*
This function is responsible for performing a dynamic cast on the input object to the specified type and asserting its type. Here's the detail:

- It attempts to cast the input object to the specified type using the object_dynamic_cast function.
- If the cast fails (returns a null pointer), it prints an error message indicating that the object is not an instance of the specified type, along with the memory address of the object and the type name. This is done using fprintf to print to the standard error stream.
- Subsequently, the function calls the abort function to terminate the program abruptly, indicating a critical error.

Needs to notice:
- This function relies on the correctness of the object_dynamic_cast function for proper type casting, and any changes to the underlying casting mechanism should be carefully considered and tested.
- Using abort() will lead to an immediate termination of the program without stack unwinding or cleanup, so its usage should be limited to critical error conditions.
*/
Object *object_dynamic_cast_assert(Object *obj, const char *typename)

{

    Object *inst;



    inst = object_dynamic_cast(obj, typename);



    if (!inst) {

        fprintf(stderr, "Object %p is not an instance of type %s\n",

                obj, typename);

        abort();

    }



    return inst;

}
