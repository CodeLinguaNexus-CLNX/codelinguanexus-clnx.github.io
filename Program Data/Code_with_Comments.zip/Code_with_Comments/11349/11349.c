/*
First paragraph:
This function is responsible for initiating and coordinating the process of stopping continuous testing on a virtualized network device through a Virtio interface, including queuing the necessary control commands and validating the successful transmission of packet data within the QEMU virtualization environment.

Second paragraph:
Here's the detail of the function: Upon invocation, the function begins by initializing several local variables and preparing the necessary data structures for communication. It allocates memory for a request address of 64 bytes using the provided guest allocator. Subsequently, it adds an entry to the Virtqueue, representing the request for stopping continuous testing, and triggers the Virtqueue to notify QEMU of the newly added entry. Following this, a control command to stop continuous testing is sent to QEMU through the QMP (QEMU Monitor Protocol) interface. Then, a packet containing the necessary information for stopping the continuous test, represented by the 'TEST' string, is prepared and transmitted to the virtualized network device through the specified socket using the iov_send function. Further QMP commands are issued to query the status and continue the operation, ensuring the queued packet data is processed by QEMU.

Third paragraph:
Needs to notice that the comment within the code emphasizes the intention of the 'stop' command and the subsequent 'query-status' command, which is to ensure the correct queuing and processing of the packet data in QEMU prior to resuming continuous testing. This highlights the importance of managing the interaction with the virtualized environment during the process of stopping and continuing the continuous testing procedure. Additionally, it's crucial to ensure proper error handling and resource deallocation, as demonstrated by the use of guest_alloc and guest_free functions to manage memory allocation and deallocation within the virtualized environment.

I hope this explanation effectively conveys the function's responsibilities and key details. If you have any further questions or need additional information, please feel free to ask!

*/static void rx_stop_cont_test(const QVirtioBus* bus, QVirtioDevice* dev,

                              QGuestAllocator *alloc, QVirtQueue *vq,

                              int socket)

{

    uint64_t req_addr;

    uint32_t free_head;

    char test[] = "TEST";

    char buffer[64];

    int len = htonl(sizeof(test));

    struct iovec iov[] = {

        {

            .iov_base = &len,

            .iov_len = sizeof(len),

        }, {

            .iov_base = test,

            .iov_len = sizeof(test),

        },

    };

    int ret;



    req_addr = guest_alloc(alloc, 64);



    free_head = qvirtqueue_add(vq, req_addr, 64, true, false);

    qvirtqueue_kick(bus, dev, vq, free_head);



    qmp("{ 'execute' : 'stop'}");



    ret = iov_send(socket, iov, 2, 0, sizeof(len) + sizeof(test));

    g_assert_cmpint(ret, ==, sizeof(test) + sizeof(len));



    /* We could check the status, but this command is more importantly to

     * ensure the packet data gets queued in QEMU, before we do 'cont'.

     */

    qmp("{ 'execute' : 'query-status'}");

    qmp("{ 'execute' : 'cont'}");



    qvirtio_wait_queue_isr(bus, dev, vq, QVIRTIO_NET_TIMEOUT_US);

    memread(req_addr + VNET_HDR_SIZE, buffer, sizeof(test));

    g_assert_cmpstr(buffer, ==, "TEST");



    guest_free(alloc, req_addr);

}
