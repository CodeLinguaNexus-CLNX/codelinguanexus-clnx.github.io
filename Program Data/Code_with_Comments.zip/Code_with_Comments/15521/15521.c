/*
This function is responsible for updating the page flags within a 64-bit hash-based memory management unit context in a PowerPC architecture. Here's the detail:

1. The function checks the current state of the page flags and updates them based on specific conditions and input parameters.
2. If the "accessed" flag is not set, it is updated to indicate that the page has been accessed.
3. If the "changed" flag is not set and a write access with a successful return is detected, the "changed" flag is updated to indicate that the page has been modified.
4. If a write access is detected but it's the first write access, the function updates the protection settings to force a page fault.

Needs to notice:
When using this function, it's important to understand the PowerPC memory management architecture and the specific meanings and implications of the various page flags being manipulated. Additionally, the impact of the input parameters "ret" (return value) and "rw" (read/write flag) on the function's behavior should be carefully considered to ensure the correct handling of page flag updates.
*/
static int ppc_hash64_pte_update_flags(struct mmu_ctx_hash64 *ctx,

                                       target_ulong *pte1p,

                                       int ret, int rw)

{

    int store = 0;



    /* Update page flags */

    if (!(*pte1p & HPTE64_R_R)) {

        /* Update accessed flag */

        *pte1p |= HPTE64_R_R;

        store = 1;

    }

    if (!(*pte1p & HPTE64_R_C)) {

        if (rw == 1 && ret == 0) {

            /* Update changed flag */

            *pte1p |= HPTE64_R_C;

            store = 1;

        } else {

            /* Force page fault for first write access */

            ctx->prot &= ~PAGE_WRITE;

        }

    }



    return store;

}
