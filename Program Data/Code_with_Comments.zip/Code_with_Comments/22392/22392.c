/*This function is responsible for restoring the original terminal settings upon program termination.

Here's the detail of the function: It first checks if the operating system is not Windows (MINGW32 is not defined). If that condition is met, it proceeds to reset the terminal attributes of file descriptor 0 (which usually represents standard input) to the values stored in the 'oldtty' structure. This is performed using the tcsetattr() function with the TCSANOW flag, applying the changes immediately.

Needs to notice that this function assumes the presence of a global 'oldtty' variable containing the original terminal settings. Additionally, it assumes that the terminal settings were modified at some point prior to this function being called. It's important to ensure that the 'oldtty' variable is properly initialized and that modifications to terminal settings are performed consistently and safely throughout the program.*/
static void term_exit(void)

{

#ifndef __MINGW32__

    tcsetattr (0, TCSANOW, &oldtty);

#endif

}
