/*
This function is responsible for checking CUDA errors and logging error messages in the context of an AVCodecContext. Here's the detail:

- It takes as input the AVCodecContext, a CUDA error code (CUresult), and the name of the function in which the error check is being performed.

- If the CUDA error code indicates success (CUDA_SUCCESS), the function returns 1, indicating that no error occurred.

- If the CUDA error code indicates a failure, the function logs a fatal error message using av_log, including the name of the function in which the error occurred and the hexadecimal error code. It then returns 0 to signal that an error has occurred.

Needs to notice:
- The function assumes that the CUDA-related operations are being performed in the context of an AVCodecContext, and the avctx parameter is required to log error messages within this context. It's important to ensure that the avctx parameter is valid and correctly initialized.
- The function solely focuses on checking and logging CUDA errors and does not handle the corrective actions for the errors. Therefore, it's essential to incorporate appropriate error handling and recovery mechanisms in the broader context where this function is used.
- Error codes specific to CUDA are logged in hexadecimal format, which should be taken into account when interpreting the error messages.
- It's crucial to ensure that the CUDA runtime environment is properly initialized and configured before invoking this error-checking function to provide accurate error reporting.

This function provides a fundamental mechanism for checking CUDA errors within the context of an AVCodecContext and logging error messages. When utilizing it, it's important to handle the identified errors effectively and to ensure that the CUDA environment is appropriately set up for error reporting.
*/
static av_cold int check_cuda_errors(AVCodecContext *avctx, CUresult err, const char *func)

{

    if (err != CUDA_SUCCESS) {

        av_log(avctx, AV_LOG_FATAL, ">> %s - failed with error code 0x%x\n", func, err);

        return 0;

    }

    return 1;

}
