/*
This function, iscsi_unmap_cb, is responsible for handling the completion and status of an iSCSI unmap command. Here's the detail:

- Upon receiving the completion status of the unmap command, it first checks if the associated IscsiAIOCB structure has been marked as canceled. If canceled, it exits early without further processing.
- It then updates the status of the IscsiAIOCB to indicate success (status = 0) and proceeds to handle the case where the status of the unmap command is less than 0 (indicating an error).
- In case of a negative status, it logs an error report with details about the failure to unmap data on the iSCSI LUN, including the specific error retrieved from the iSCSI context.
- It sets the status of the IscsiAIOCB to indicate an I/O error (-EIO) in case of a failure.
- Finally, it schedules a bottom-half (bh) task to handle further processing related to the completion of the unmap command.

Needs to notice:
- This function operates within the context of handling iSCSI unmap commands and is often used in asynchronous I/O operations.
- Handling of IscsiAIOCB and associated state, such as the canceled flag, is essential for managing the callback effectively.
- Proper error reporting and handling of I/O errors are crucial for maintaining the integrity and reliability of data operations over iSCSI.
- It's important to ensure that any subsequent processing scheduled in the bottom-half task is carried out appropriately with regards to the unmap operation.
*/
iscsi_unmap_cb(struct iscsi_context *iscsi, int status,

                     void *command_data, void *opaque)

{

    IscsiAIOCB *acb = opaque;



    if (acb->canceled != 0) {

        return;

    }



    acb->status = 0;

    if (status < 0) {

        error_report("Failed to unmap data on iSCSI lun. %s",

                     iscsi_get_error(iscsi));

        acb->status = -EIO;

    }



    iscsi_schedule_bh(acb);

}
