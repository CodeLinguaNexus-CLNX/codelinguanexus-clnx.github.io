/*
This function is responsible for decoding frames in the FlashSV video format. It processes the input bitstream data to decompress and reconstruct the video frames.

Here's the detailed breakdown:
- The function starts by parsing the bitstream to extract information about the block size, image dimensions, and block layout.
- It then allocates and initializes buffers for storing the decompressed frame data.
- The function iterates through the block structure of the image, decompressing and reconstructing each block using zlib decompression.
- Once all blocks are processed, the decoded frame data is stored in the output buffer.

Usage needs to notice:
- The function assumes input data in the FlashSV format and is responsible for managing memory and buffer allocation for the decoded frames.
- It handles the decompression and reconstruction of individual blocks within the frame using zlib library functions.
- The function returns the size of the consumed input buffer and the decoded frame data for further processing.

Please note that error handling, buffer management, and boundary checks are important considerations while using this function.
*/
static uint32_t bmdma_readb(void *opaque, uint32_t addr)

{

    BMDMAState *bm = opaque;

    PCIIDEState *pci_dev = pci_from_bm(bm);

    uint32_t val;



    switch(addr & 3) {

    case 0:

        val = bm->cmd;

        break;

    case 1:

        val = pci_dev->dev.config[MRDMODE];

        break;

    case 2:

        val = bm->status;

        break;

    case 3:

        if (bm->unit == 0) {

            val = pci_dev->dev.config[UDIDETCR0];

        } else {

            val = pci_dev->dev.config[UDIDETCR1];

        }

        break;

    default:

        val = 0xff;

        break;

    }

#ifdef DEBUG_IDE

    printf("bmdma: readb 0x%02x : 0x%02x\n", addr, val);

#endif

    return val;

}
