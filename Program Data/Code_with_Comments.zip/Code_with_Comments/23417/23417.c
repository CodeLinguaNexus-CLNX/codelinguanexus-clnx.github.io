/*
Function is responsible for removing a virtual serial port from the VirtIO serial device. Here's a detailed explanation:

Functionality Overview:
- This function is part of the VirtIO serial device handling and is responsible for removing a specific port identified by port_id from the device.
- It first updates the ports_map to clear the corresponding bit for the removed port, then finds the port using the port_id and performs certain cleanup operations including discarding unconsumed buffers and sending a control event to notify the removal of the port.

Detailed Explanation:
- It calculates the index i into the ports_map array based on the port_id and clears the bit representing the specific port in the ports_map by using bitwise operations.
- It then attempts to find the port using the given port_id. If the port is not found, it triggers an assertion, indicating a critical issue.
- After ensuring the validity of the port, it proceeds to discard any unconsumed buffers associated with the port by calling discard_vq_data.
- Finally, it sends a control event to signal the removal of the port from the VirtIO serial device, using send_control_event.

Needs to Notice:
- Before invoking this function, ensure that the VirtIOSerial pointer (vser) and the port_id are valid, and the necessary synchronization and locking mechanisms are in place to prevent concurrent access issues.
- It's crucial to verify the correctness of data structures and memory allocations related to VirtIO serial device and its ports to avoid potential memory corruption or segmentation faults.
- The use of assert implies that the function assumes the presence of a valid port. It's essential to understand the context in which this function is called and ensure proper error-handling mechanisms are in place.
*/
static int wav_write_trailer(AVFormatContext *s)

{

    AVIOContext *pb  = s->pb;

    WAVMuxContext    *wav = s->priv_data;

    int64_t file_size, data_size;

    int64_t number_of_samples = 0;

    int rf64 = 0;



    avio_flush(pb);



    if (s->pb->seekable) {

        if (wav->write_peak != 2) {

            ff_end_tag(pb, wav->data);

            avio_flush(pb);

        }



        if (wav->write_peak && wav->peak_output) {

            peak_write_chunk(s);

            avio_flush(pb);

        }



        /* update file size */

        file_size = avio_tell(pb);

        data_size = file_size - wav->data;

        if (wav->rf64 == RF64_ALWAYS || (wav->rf64 == RF64_AUTO && file_size - 8 > UINT32_MAX)) {

            rf64 = 1;

        } else {

            avio_seek(pb, 4, SEEK_SET);

            avio_wl32(pb, (uint32_t)(file_size - 8));

            avio_seek(pb, file_size, SEEK_SET);



            avio_flush(pb);

        }



        number_of_samples = av_rescale(wav->maxpts - wav->minpts + wav->last_duration,

                                       s->streams[0]->codec->sample_rate * (int64_t)s->streams[0]->time_base.num,

                                       s->streams[0]->time_base.den);



        if(s->streams[0]->codec->codec_tag != 0x01) {

            /* Update num_samps in fact chunk */

            avio_seek(pb, wav->fact_pos, SEEK_SET);

            if (rf64 || (wav->rf64 == RF64_AUTO && number_of_samples > UINT32_MAX)) {

                rf64 = 1;

                avio_wl32(pb, -1);

            } else {

                avio_wl32(pb, number_of_samples);

                avio_seek(pb, file_size, SEEK_SET);

                avio_flush(pb);

            }

        }



        if (rf64) {

            /* overwrite RIFF with RF64 */

            avio_seek(pb, 0, SEEK_SET);

            ffio_wfourcc(pb, "RF64");

            avio_wl32(pb, -1);



            /* write ds64 chunk (overwrite JUNK if rf64 == RF64_AUTO) */

            avio_seek(pb, wav->ds64 - 8, SEEK_SET);

            ffio_wfourcc(pb, "ds64");

            avio_wl32(pb, 28);                  /* ds64 chunk size */

            avio_wl64(pb, file_size - 8);       /* RF64 chunk size */

            avio_wl64(pb, data_size);           /* data chunk size */

            avio_wl64(pb, number_of_samples);   /* fact chunk number of samples */

            avio_wl32(pb, 0);                   /* number of table entries for non-'data' chunks */



            /* write -1 in data chunk size */

            avio_seek(pb, wav->data - 4, SEEK_SET);

            avio_wl32(pb, -1);



            avio_seek(pb, file_size, SEEK_SET);

            avio_flush(pb);

        }

    }



    if (wav->write_peak)

        peak_free_buffers(s);



    return 0;

}
