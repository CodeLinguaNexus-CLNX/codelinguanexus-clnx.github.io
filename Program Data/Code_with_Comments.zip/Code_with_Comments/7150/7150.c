/*
/*
This function is responsible for retrieving the stream index associated with a given KLVPacket within the MXF format context.

Here's the detail: The function iterates through the list of streams within the format context and compares the track numbers to identify the relevant stream index for the provided KLVPacket. It implements the logic specified in the SMPTE 379M 7.3 standard for matching the track numbers with the KLVPacket's key. Additionally, it handles a special case where it returns 0 if there is only one stream, particularly for OP Atom files with a track number of 0.

Need's to notice: When using this function, developers should ensure that the MXFTrack is properly initialized and its track numbers are populated according to the SMPTE 379M 7.3 standard. Additionally, special consideration should be given to handling the edge case for OP Atom files with a single stream or a track number of 0.
*/
*/
static int mxf_get_stream_index(AVFormatContext *s, KLVPacket *klv)

{

    int i;



    for (i = 0; i < s->nb_streams; i++) {

        MXFTrack *track = s->streams[i]->priv_data;

        /* SMPTE 379M 7.3 */

        if (!memcmp(klv->key + sizeof(mxf_essence_element_key), track->track_number, sizeof(track->track_number)))

            return i;

    }

    /* return 0 if only one stream, for OP Atom files with 0 as track number */

    return s->nb_streams == 1 ? 0 : -1;

}
