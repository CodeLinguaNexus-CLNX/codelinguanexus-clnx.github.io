/*
This function is responsible for waiting until a specific flag in the IDE device status register is cleared, with a timeout of 5 seconds.

Here's the detail of the function:
The function first retrieves the PCI device and the base address registers (BARs) for the Bus Master IDE (BMDMA) and IDE interfaces. It then enters a loop where it reads the status register of the IDE device at regular intervals. If the specified flag in the status register is found to be cleared, the function returns the current status data. If the timeout of 5 seconds is reached before the flag is cleared, the function exits the loop.

Needs to notice:
This function uses a 5-second timeout to wait for the specified flag to be cleared in the IDE device status register. Developers should ensure that this timeout duration is appropriate for the system and hardware being used. Additionally, the nsleep function used for waiting should be implemented and handled correctly for the target platform.
It's important to handle potential scenarios where the flag may not be cleared within the timeout period, as indicated by the g_assert_not_reached() call. Developers should consider proper error handling or recovery mechanisms for such cases.
The function assumes the presence of a PCI device, proper BARs for the BMDMA and IDE interfaces, and a valid status register configuration for the IDE device. These assumptions should be verified in the context of the usage of this function.
*/

static uint8_t ide_wait_clear(uint8_t flag)

{

    QPCIDevice *dev;

    QPCIBar bmdma_bar, ide_bar;

    uint8_t data;

    time_t st;



    dev = get_pci_device(&bmdma_bar, &ide_bar);



    /* Wait with a 5 second timeout */

    time(&st);

    while (true) {

        data = qpci_io_readb(dev, ide_bar, reg_status);

        if (!(data & flag)) {


            return data;

        }

        if (difftime(time(NULL), st) > 5.0) {

            break;

        }

        nsleep(400);

    }

    g_assert_not_reached();

}