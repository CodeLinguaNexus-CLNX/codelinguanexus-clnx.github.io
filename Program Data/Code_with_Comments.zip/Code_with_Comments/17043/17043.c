/**
 * This function is responsible for initializing the machine settings and parameters for the Xilinx ZynqMP EP108 board within the given MachineClass structure.
 *
 * Here's the detail of the function:
 * - The function sets the description of the machine, initializes the specific initialization function (xlnx_ep108_init) for the machine, sets the default block type to IF_IDE, and specifies the number of units per default bus.
 * - Additionally, the function configures the behavior to ignore memory transaction failures, indicating potential resiliency or error handling characteristics of the EP108 board.
 *
 * Need's to notice:
 * - When using this function, ensure that the machine parameters and defaults are appropriately set for the Xilinx ZynqMP EP108 board to guarantee correct emulation and behavior. Developers should verify the compatibility of the specified default block type and bus units with the EP108 board's configuration and capabilities, and understand the implications of ignoring memory transaction failures for system stability and reliability.
 */
static void xlnx_ep108_machine_init(MachineClass *mc)

{

    mc->desc = "Xilinx ZynqMP EP108 board";

    mc->init = xlnx_ep108_init;

    mc->block_default_type = IF_IDE;

    mc->units_per_default_bus = 1;

    mc->ignore_memory_transaction_failures = true;

}
