/*
This function is responsible for finalizing the replay of an event in the system. Here's the detail:

1. It clears the flag indicating that there is unread data in the replay mechanism, marking the completion of the current event replay.

2. It then triggers the function `replay_fetch_data_kind()` to fetch the next set of data for the replay process, continuing the sequential retrieval of recorded events.

Needs to notice:

Developers should ensure that the `replay_fetch_data_kind()` function is called in a manner that aligns with the desired replay logic, and that any necessary cleanup or finalization steps related to event replay are appropriately handled within this function. Additionally, proper synchronization mechanisms should be considered if this function is accessed concurrently to prevent race conditions or unexpected interleaving of operations during the replay process.
*/
void replay_finish_event(void)

{

    replay_has_unread_data = 0;

    replay_fetch_data_kind();

}
