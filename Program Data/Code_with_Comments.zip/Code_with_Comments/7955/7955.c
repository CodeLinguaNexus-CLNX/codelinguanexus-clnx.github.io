/*This function is responsible for allocating memory dynamically based on the specified size, handling edge cases where the size is zero.

Here's the detail: When called, the function first checks whether the requested size is zero and if zero-sized allocations are allowed. If not allowed, the program is terminated using the abort function. Otherwise, the function uses the malloc function to allocate memory, with a minimum size of 1 if the requested size is zero. It then performs an out-of-memory (OOM) check using the oom_check function before returning a pointer to the allocated memory.

Need's to notice: When utilizing this function, it's important to consider the implications of zero-sized allocations and ensure that they are handled appropriately in the context of the program's memory management. Additionally, proper error handling should be in place to manage out-of-memory situations.*/
void *qemu_malloc(size_t size)

{

    if (!size && !allow_zero_malloc()) {

        abort();

    }

    return oom_check(malloc(size ? size : 1));

}
