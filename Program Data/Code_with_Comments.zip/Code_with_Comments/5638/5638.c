/*
This function is responsible for writing and configuring the DPLL (Dynamic Performance Scaling) control registers within the OMAP (Open Multimedia Applications Platform) system. Here's the detailed description:

- The function takes opaque, address, value, and size as input parameters to perform the DPLL control register write operation.
- It extracts the DPLL control structure from the opaque pointer and initializes some necessary variables.
- The function checks the size of the write operation, and if it doesn't match the expected size, it delegates the write operation to another function, omap_badwidth_write16.
- If the address being written to is 0x00 (CTL_REG), the function interprets and processes the control values to determine the desired DPLL mode, division factor, and multiplier for clock scaling.
- Based on the control values, the function sets the DPLL clock rate using the omap_clk_setrate function.
- It then modifies the DPLL mode according to the desired mode and simulates the restoration of lock status.
- If the address does not match the expected value, the function raises an error.

Needs to notice:
- This function plays a critical role in configuring the DPLL control registers, which are essential for clock generation and performance scaling in the OMAP system.
- It involves complex logic to interpret control values and set the DPLL clock rate accordingly, requiring thorough understanding and validation of the underlying hardware behavior.
- The function's reliance on the omap_clk_setrate function implies that the behavior of clock scaling operations should be carefully coordinated and validated within the system.
*/

static void omap_dpll_write(void* opaque, target_phys_addr_t addr,

                            uint64_t value, unsigned size)

{

    struct dpll_ctl_s *s = (struct dpll_ctl_s *) opaque;

    uint16_t diff;

    static const int bypass_div[4] = { 1, 2, 4, 4 };

    int div, mult;



    if (size != 2) {

        return omap_badwidth_write16(opaque, addr, value);

    }



    if (addr == 0x00) {	/* CTL_REG */

        /* See omap_ulpd_pm_write() too */

        diff = s->mode & value;

        s->mode = value & 0x2fff;

        if (diff & (0x3ff << 2)) {

            if (value & (1 << 4)) {			/* PLL_ENABLE */

                div = ((value >> 5) & 3) + 1;		/* PLL_DIV */

                mult = MIN((value >> 7) & 0x1f, 1);	/* PLL_MULT */

            } else {

                div = bypass_div[((value >> 2) & 3)];	/* BYPASS_DIV */

                mult = 1;

            }

            omap_clk_setrate(s->dpll, div, mult);

        }



        /* Enter the desired mode.  */

        s->mode = (s->mode & 0xfffe) | ((s->mode >> 4) & 1);



        /* Act as if the lock is restored.  */

        s->mode |= 2;

    } else {

        OMAP_BAD_REG(addr);

    }

}
