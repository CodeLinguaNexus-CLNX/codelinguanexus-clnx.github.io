/*This function is responsible for decoding and executing the "movu" instruction for the CRIS architecture in the context of a disassembler.

Here's the detail: Upon invocation, the function first determines the size of the memory operation using the 'memsize_z' function, and then proceeds to log the disassembled "movu" instruction in the appropriate format. It sets the condition code flags based on the result of the operation and initializes a temporary TCG variable. Subsequently, it prepares the move operation using the 'dec_prep_move_r' function, performs the actual arithmetic logic unit (ALU) operation for the move using the 'cris_alu' function, and frees the temporary TCG variable before returning the size of the instruction.

Need's to notice: When working with this function, it is essential to verify that the decoding and execution of the "movu" instruction align with the expected behavior of the CRIS architecture. Additionally, any side effects or dependencies on the CPU state and condition code flags should be carefully considered to ensure the correctness of the disassembler's output and the subsequent execution flow.*/
static unsigned int dec_movu_r(DisasContext *dc)

{

	TCGv t0;

	int size = memsize_z(dc);

	DIS(fprintf (logfile, "movu.%c $r%u, $r%u\n",

		    memsize_char(size),

		    dc->op1, dc->op2));



	cris_cc_mask(dc, CC_MASK_NZ);

	t0 = tcg_temp_new(TCG_TYPE_TL);

	dec_prep_move_r(dc, dc->op1, dc->op2, size, 0, t0);

	cris_alu(dc, CC_OP_MOVE, cpu_R[dc->op2], cpu_R[dc->op2], t0, 4);

	tcg_temp_free(t0);

	return 2;

}
