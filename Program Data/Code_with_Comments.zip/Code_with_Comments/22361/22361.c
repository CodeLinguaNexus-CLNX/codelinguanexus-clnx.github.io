/*This function is responsible for performing YUV to YUV conversion using specific filters and scaling, including the handling of different components (luminance, chrominance, and alpha if present) to generate the output YUV data.

Here's the detail of the function: It takes the input YUV data and applies the specified filters and scaling to convert it to the desired YUV format, including handling the destination buffers for luminance, chrominance, and alpha channels if applicable. It utilizes the provided filters and source data to perform the necessary conversion calculations using optimized MMX instructions for efficient processing.

Need's to notice that the function's performance and correctness depend on the proper configuration and availability of MMX instructions for optimized processing. Additionally, the function assumes the correct input data alignment and buffer sizes for the conversion, and it's important to ensure these requirements are met when using this function.*/
static inline void RENAME(yuv2yuvX_ar)(SwsContext *c, const int16_t *lumFilter,

                                       const int16_t **lumSrc, int lumFilterSize,

                                       const int16_t *chrFilter, const int16_t **chrUSrc,

                                       const int16_t **chrVSrc,

                                       int chrFilterSize, const int16_t **alpSrc,

                                       uint8_t *dest, uint8_t *uDest, uint8_t *vDest,

                                       uint8_t *aDest, long dstW, long chrDstW)

{

    if (uDest) {

        YSCALEYUV2YV12X_ACCURATE(CHR_MMX_FILTER_OFFSET, uDest, chrDstW, 0)

        YSCALEYUV2YV12X_ACCURATE(CHR_MMX_FILTER_OFFSET, vDest, chrDstW + c->uv_off, c->uv_off)

    }

    if (CONFIG_SWSCALE_ALPHA && aDest) {

        YSCALEYUV2YV12X_ACCURATE(ALP_MMX_FILTER_OFFSET, aDest, dstW, 0)

    }



    YSCALEYUV2YV12X_ACCURATE(LUM_MMX_FILTER_OFFSET, dest, dstW, 0)

}
