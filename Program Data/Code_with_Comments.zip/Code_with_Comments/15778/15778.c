/*
This function is responsible for attaching a child block driver state to a parent block driver state. 

Here's the detail: The function takes in the parent block driver state, child block driver state, child name, child role, and an error pointer. It first calls the bdrv_root_attach_child function to attach the child block driver state to the parent block driver state, passing in the child name and role. This function returns a pointer to the BdrvChild structure representing the attachment.

Then, the function inserts the child block driver state into the parent's list of children using the macro QLIST_INSERT_HEAD, ensuring that the child is added at the head of the list.

Finally, the function returns the pointer to the created BdrvChild structure.

Need's to notice that the function assumes that the provided parent and child block driver states are valid and that the child name and role are properly defined. Additionally, error handling through the error pointer should be taken into consideration.
*/
BdrvChild *bdrv_attach_child(BlockDriverState *parent_bs,

                             BlockDriverState *child_bs,

                             const char *child_name,

                             const BdrvChildRole *child_role,

                             Error **errp)

{

    BdrvChild *child = bdrv_root_attach_child(child_bs, child_name, child_role,

                                              parent_bs);

    QLIST_INSERT_HEAD(&parent_bs->children, child, next);

    return child;

}
