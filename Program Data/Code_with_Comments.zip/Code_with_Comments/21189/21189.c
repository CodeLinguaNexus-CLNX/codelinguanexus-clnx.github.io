/*
This function is responsible for handling the retrieval of file attributes (metadata) in the V9fs protocol, and constructing the response to the client's getattr request.

Here's the detail:
- The function starts by extracting the file ID (fid) and request mask from the received V9fsPDU (protocol data unit), and then traces the getattr operation as part of the debugging process.
- It retrieves the file state associated with the fid and proceeds to perform a lookup and obtain the basic file attributes (stat) using the v9fs_co_lstat function.
- Afterwards, it converts the obtained file attributes into the V9fsStatDotl format and prepares to fill in the st_gen field if requested and supported by the underlying file system.
- Following this, the function marshals the V9fsStatDotl structure into the response buffer and traces the return of the getattr operation, including the relevant file attribute details.
- Finally, it manages the releasing of the fid and completes the processing of the pdu, potentially indicating any errors encountered during the operation.

Needs to notice:
- The function predominantly handles the processing of file attributes requested via the V9fs protocol, converting and marshaling them into the appropriate format for the response to the client.
- It demonstrates the handling of both basic and extended file attribute information, depending on the capabilities of the underlying file system and the requests from the client.
- Error handling and tracing of the getattr operation are integrated to manage potential issues and provide diagnostic information for debugging.
*/
void pci_default_write_config(PCIDevice *d, uint32_t addr, uint32_t val, int l)

{

    int i, was_irq_disabled = pci_irq_disabled(d);

    uint32_t config_size = pci_config_size(d);



    for (i = 0; i < l && addr + i < config_size; val >>= 8, ++i) {

        uint8_t wmask = d->wmask[addr + i];

        uint8_t w1cmask = d->w1cmask[addr + i];

        assert(!(wmask & w1cmask));

        d->config[addr + i] = (d->config[addr + i] & ~wmask) | (val & wmask);

        d->config[addr + i] &= ~(val & w1cmask); /* W1C: Write 1 to Clear */

    }

    if (ranges_overlap(addr, l, PCI_BASE_ADDRESS_0, 24) ||

        ranges_overlap(addr, l, PCI_ROM_ADDRESS, 4) ||

        ranges_overlap(addr, l, PCI_ROM_ADDRESS1, 4) ||

        range_covers_byte(addr, l, PCI_COMMAND))

        pci_update_mappings(d);



    if (range_covers_byte(addr, l, PCI_COMMAND))

        pci_update_irq_disabled(d, was_irq_disabled);

}
