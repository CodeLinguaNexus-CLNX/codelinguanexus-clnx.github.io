/*
```c
/**
 * This function is responsible for checking whether a given value can be represented within a specified number of bits without losing information due to truncation.
 */

/* Here's the detail */
/* - The function performs a bitwise left shift operation on the value 'val' by the number of positions that would result in preserving only the specified number of low-order bits (determined by 'bits').
 * - Subsequently, the function performs a bitwise right shift to restore the original value to its original position, effectively truncating any excess high-order bits beyond the specified 'bits' without altering the original value. 
 * - The equality comparison against the original value determines if the value can be represented within the specified bit width without loss of information. If the comparison evaluates to true, the function returns 1, indicating that the value fits within the specified bit width, and returns 0 otherwise.

 */

/* Need's to notice */
/* - This function assumes that the input value 'val' is an unsigned integer type, as the behavior of the right shift operation on signed integers may vary depending on the platform's arithmetic shift rules.
 * - It is important to be mindful of the potential for undefined behavior or unexpected results if the 'bits' parameter exceeds the width of 'val', as this would lead to invalid comparisons and unreliable outcomes.
 * - While this function provides a method to check for the fit of a value within a specified number of bits, developers should exercise caution in ensuring the correctness and appropriateness of this operation within the broader context of their code.
 */
```
*/
static inline int check_fit(tcg_target_long val, unsigned int bits)

{

    return ((val << ((sizeof(tcg_target_long) * 8 - bits))

             >> (sizeof(tcg_target_long) * 8 - bits)) == val);

}
