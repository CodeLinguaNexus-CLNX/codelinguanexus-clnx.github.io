/*
This function is responsible for handling the connection of a VNC client to a VNC display, including setting up the initial state and event handling. Here's the detail: it allocates and initializes a VncState structure, determines the authentication method to be used based on the provided parameters, sets up socket handlers based on whether it's a WebSocket connection, manages event notifications, and initializes the VNC state if it's not a WebSocket connection.

Needs to notice: When using this function, it's important to ensure that the VncDisplay and VncState structures are properly initialized and that the event handling and socket setup are appropriate for the type of connection being established. Additionally, the function includes a check for the number of connecting clients and potentially disconnects clients if the limit is exceeded, so the behavior of this check should be understood in the specific VNC server implementation.
*/
static inline void stw_phys_internal(hwaddr addr, uint32_t val,

                                     enum device_endian endian)

{

    uint8_t *ptr;

    MemoryRegionSection *section;



    section = phys_page_find(address_space_memory.dispatch, addr >> TARGET_PAGE_BITS);



    if (!memory_region_is_ram(section->mr) || section->readonly) {

        addr = memory_region_section_addr(section, addr);

        if (memory_region_is_ram(section->mr)) {

            section = &phys_sections[phys_section_rom];

        }

#if defined(TARGET_WORDS_BIGENDIAN)

        if (endian == DEVICE_LITTLE_ENDIAN) {

            val = bswap16(val);

        }

#else

        if (endian == DEVICE_BIG_ENDIAN) {

            val = bswap16(val);

        }

#endif

        io_mem_write(section->mr, addr, val, 2);

    } else {

        unsigned long addr1;

        addr1 = (memory_region_get_ram_addr(section->mr) & TARGET_PAGE_MASK)

            + memory_region_section_addr(section, addr);

        /* RAM case */

        ptr = qemu_get_ram_ptr(addr1);

        switch (endian) {

        case DEVICE_LITTLE_ENDIAN:

            stw_le_p(ptr, val);

            break;

        case DEVICE_BIG_ENDIAN:

            stw_be_p(ptr, val);

            break;

        default:

            stw_p(ptr, val);

            break;

        }

        invalidate_and_set_dirty(addr1, 2);

    }

}
