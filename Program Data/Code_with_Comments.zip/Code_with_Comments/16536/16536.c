/*
This function is responsible for performing averaging operations on a block of pixels using AltiVec SIMD instructions on the PowerPC architecture.

Here's the detail:
- The function first checks whether the reference C code for the AltiVec implementation is to be used, as indicated by the ALTIVEC_USE_REFERENCE_C_CODE macro. If the macro is defined, the function executes the averaging operation using the reference C code; otherwise, it uses optimized AltiVec SIMD instructions.

If ALTIVEC_USE_REFERENCE_C_CODE is defined:
- It iterates over each row of pixels (height 'h'), loading four pixels at a time and averaging them with the corresponding pixels in the block. This process is repeated for each row, advancing the pointers based on the line size.

If ALTIVEC_USE_REFERENCE_C_CODE is not defined:
- It initializes registers for vector operations and loads pixels and blocks using AltiVec load instructions.
- It then performs vector permutation and averaging operations using AltiVec SIMD instructions. Finally, the averaged result is stored back into the block memory.

Needs to notice:
- When using SIMD instructions, it's crucial to ensure correct alignment and handling of memory access to avoid alignment faults and data corruption.
- Developers should be aware of the specific AltiVec SIMD instructions being used and their behavior to guarantee accurate implementation and performance benefits.
- Care should be taken to handle any edge cases such as boundary alignment, width, or height constraints to ensure the correct functioning of the averaging operation across different input scenarios.
- When using optimized SIMD instructions, it's important to consider the potential difference in behavior or performance compared to the reference C code and to thoroughly test the functionality across various input data sets.
*/
void avg_pixels16_altivec(uint8_t *block, const uint8_t *pixels, int line_size, int h)

{

POWERPC_TBL_DECLARE(altivec_avg_pixels16_num, 1);

#ifdef ALTIVEC_USE_REFERENCE_C_CODE

    int i;



POWERPC_TBL_START_COUNT(altivec_avg_pixels16_num, 1);



    for(i=0; i<h; i++) {

      op_avg(*((uint32_t*)(block)),(((const struct unaligned_32 *)(pixels))->l));

      op_avg(*((uint32_t*)(block+4)),(((const struct unaligned_32 *)(pixels+4))->l));

      op_avg(*((uint32_t*)(block+8)),(((const struct unaligned_32 *)(pixels+8))->l));

      op_avg(*((uint32_t*)(block+12)),(((const struct unaligned_32 *)(pixels+12))->l));

      pixels+=line_size;

      block +=line_size;

    }



POWERPC_TBL_STOP_COUNT(altivec_avg_pixels16_num, 1);



#else /* ALTIVEC_USE_REFERENCE_C_CODE */

    register vector unsigned char pixelsv1, pixelsv2, pixelsv, blockv;

    register vector unsigned char perm = vec_lvsl(0, pixels);

    int i;



POWERPC_TBL_START_COUNT(altivec_avg_pixels16_num, 1);



    for(i=0; i<h; i++) {

      pixelsv1 = vec_ld(0, (unsigned char*)pixels);

      pixelsv2 = vec_ld(16, (unsigned char*)pixels);

      blockv = vec_ld(0, block);

      pixelsv = vec_perm(pixelsv1, pixelsv2, perm);

      blockv = vec_avg(blockv,pixelsv);

      vec_st(blockv, 0, (unsigned char*)block);

      pixels+=line_size;

      block +=line_size;

    }



POWERPC_TBL_STOP_COUNT(altivec_avg_pixels16_num, 1);



#endif /* ALTIVEC_USE_REFERENCE_C_CODE */

}
