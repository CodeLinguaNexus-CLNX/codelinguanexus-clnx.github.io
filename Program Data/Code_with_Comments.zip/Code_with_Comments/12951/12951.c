/*
This function is responsible for reading and parsing the header of a THP (Nintendo GameCube THP) video file in the context of an FFmpeg demuxer. Here's the detail:

- It begins by reading various header values from the input AVIOContext, such as version, frames per second (FPS), frame count, component offsets, and frame sizes. 
- After reading the header values, it proceeds to read the component structure and list of component types from the input AVIOContext.
- For each component, it creates a new stream using avformat_new_stream, sets the codec parameters, and configures the stream based on the read component information. For video components, it sets up video stream properties including width, height, and frame rate. For audio components, it sets up audio stream properties such as channels and sample rate.
- It handles any unknown version-specific details, if applicable, during the stream setup process.
- The function returns 0 if the header reading and stream setup process is successful. Otherwise, it returns an appropriate error code (e.g., AVERROR(ENOMEM)) if memory allocation fails during stream creation.

Needs to notice:
- This function is specific to handling THP video files within the FFmpeg demuxer and may not be directly applicable to other FFmpeg functionalities.
- Proper error handling should be employed to catch and handle any potential errors that may occur during the header reading and stream creation process.
- The function assumes a certain structure and format for THP video files, and its behavior may not be suitable for other types of video formats.
- Care should be taken to ensure the integrity and consistency of the input AVFormatContext and AVIOContext, as any inconsistencies may lead to erroneous behavior during header reading and stream setup.
*/
static int thp_read_header(AVFormatContext *s,

                           AVFormatParameters *ap)

{

    ThpDemuxContext *thp = s->priv_data;

    AVStream *st;

    AVIOContext *pb = s->pb;

    int i;



    /* Read the file header.  */

                           avio_rb32(pb); /* Skip Magic.  */

    thp->version         = avio_rb32(pb);



                           avio_rb32(pb); /* Max buf size.  */

                           avio_rb32(pb); /* Max samples.  */



    thp->fps             = av_d2q(av_int2float(avio_rb32(pb)), INT_MAX);

    thp->framecnt        = avio_rb32(pb);

    thp->first_framesz   = avio_rb32(pb);

                           avio_rb32(pb); /* Data size.  */



    thp->compoff         = avio_rb32(pb);

                           avio_rb32(pb); /* offsetDataOffset.  */

    thp->first_frame     = avio_rb32(pb);

    thp->last_frame      = avio_rb32(pb);



    thp->next_framesz    = thp->first_framesz;

    thp->next_frame      = thp->first_frame;



    /* Read the component structure.  */

    avio_seek (pb, thp->compoff, SEEK_SET);

    thp->compcount       = avio_rb32(pb);



    /* Read the list of component types.  */

    avio_read(pb, thp->components, 16);



    for (i = 0; i < thp->compcount; i++) {

        if (thp->components[i] == 0) {

            if (thp->vst != 0)

                break;



            /* Video component.  */

            st = avformat_new_stream(s, NULL);

            if (!st)

                return AVERROR(ENOMEM);



            /* The denominator and numerator are switched because 1/fps

               is required.  */

            avpriv_set_pts_info(st, 64, thp->fps.den, thp->fps.num);

            st->codec->codec_type = AVMEDIA_TYPE_VIDEO;

            st->codec->codec_id = CODEC_ID_THP;

            st->codec->codec_tag = 0;  /* no fourcc */

            st->codec->width = avio_rb32(pb);

            st->codec->height = avio_rb32(pb);

            st->codec->sample_rate = av_q2d(thp->fps);

            thp->vst = st;

            thp->video_stream_index = st->index;



            if (thp->version == 0x11000)

                avio_rb32(pb); /* Unknown.  */

        } else if (thp->components[i] == 1) {

            if (thp->has_audio != 0)

                break;



            /* Audio component.  */

            st = avformat_new_stream(s, NULL);

            if (!st)

                return AVERROR(ENOMEM);



            st->codec->codec_type = AVMEDIA_TYPE_AUDIO;

            st->codec->codec_id = CODEC_ID_ADPCM_THP;

            st->codec->codec_tag = 0;  /* no fourcc */

            st->codec->channels    = avio_rb32(pb); /* numChannels.  */

            st->codec->sample_rate = avio_rb32(pb); /* Frequency.  */



            avpriv_set_pts_info(st, 64, 1, st->codec->sample_rate);



            thp->audio_stream_index = st->index;

            thp->has_audio = 1;

        }

    }



    return 0;

}
