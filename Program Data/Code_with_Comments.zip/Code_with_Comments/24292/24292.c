/*This function is responsible for draining all pending I/O operations and ensuring that the BlockDriverState is not in a busy state before proceeding with further operations.

Here's the detail: The function first initiates a recursive draining process by calling bdrv_drain_recurse, which cascades the draining down to underlying nodes or layers in the storage stack. Subsequently, it enters a loop to check and handle any remaining pending I/O operations. Within the loop, it flushes the I/O queue using bdrv_flush_io_queue, then checks for pending requests using bdrv_requests_pending. It also performs an asynchronous I/O poll using aio_poll to handle any outstanding asynchronous I/O operations.

Need's to notice: It is crucial to ensure that the bdrv_drain_recurse function is appropriately implemented to cascade the draining process through all relevant layers. The loop condition and the order of operations within the loop are critical to effectively handle and resolve any remaining I/O operations. Proper synchronization and error handling mechanisms should be in place to handle potential race conditions and ensure the correct handling of pending I/O operations.*/
void bdrv_drain(BlockDriverState *bs)

{

    bool busy = true;



    bdrv_drain_recurse(bs);





    while (busy) {

        /* Keep iterating */

         bdrv_flush_io_queue(bs);

         busy = bdrv_requests_pending(bs);

         busy |= aio_poll(bdrv_get_aio_context(bs), busy);

