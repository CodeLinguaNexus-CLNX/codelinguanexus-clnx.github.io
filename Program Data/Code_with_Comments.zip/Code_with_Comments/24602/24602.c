/*
This function is responsible for performing a physical memory read operation for a 64-bit quantity at the specified physical address.

Here's the detail:
- It calls the ldq_phys_internal function, passing the target physical address (addr) and the device's native endianness as parameters.
- The ldq_phys_internal function is expected to handle the underlying implementation details of reading from the physical memory and correctly interpreting the endianness.

Needs to notice:
- Proper validation of the physical address and consideration of memory access permissions are essential to ensure the function operates within the permissible memory space.
- The correctness and efficiency of the ldq_phys_internal function, including its handling of endianness and error conditions, are critical for the overall functionality of this operation.
- Endianness considerations should align with the specific requirements and characteristics of the target hardware architecture to ensure accurate data interpretation.
*/
uint64_t ldq_phys(target_phys_addr_t addr)

{

    return ldq_phys_internal(addr, DEVICE_NATIVE_ENDIAN);

}
