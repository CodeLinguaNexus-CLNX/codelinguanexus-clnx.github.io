/*This function is responsible for retrieving and populating file attribute information from a virtual file system mapping directory for a specified file.

Here's the detail:
The function opens the virtual file system mapping directory using the provided directory file descriptor and attempts to retrieve attribute information for the specified file by reading the contents of a corresponding virtual file. It reads the attribute values from the virtual file and populates the stat structure with the appropriate information, including UID, GID, file mode, and device number.

Need's to notice:
It is crucial to handle potential errors and edge cases, such as failed file openings, missing attribute information, or invalid data formats in the virtual files. Additionally, the function should ensure proper error handling when accessing and reading the virtual file system mapping directory to prevent unexpected behavior and potential security vulnerabilities.*/
static void local_mapped_file_attr(int dirfd, const char *name,

                                   struct stat *stbuf)

{

    FILE *fp;

    char buf[ATTR_MAX];

    int map_dirfd;



    map_dirfd = openat(dirfd, VIRTFS_META_DIR,

                       O_RDONLY | O_DIRECTORY | O_NOFOLLOW);

    if (map_dirfd == -1) {

        return;

    }



    fp = local_fopenat(map_dirfd, name, "r");

    close_preserve_errno(map_dirfd);

    if (!fp) {

        return;

    }

    memset(buf, 0, ATTR_MAX);

    while (fgets(buf, ATTR_MAX, fp)) {

        if (!strncmp(buf, "virtfs.uid", 10)) {

            stbuf->st_uid = atoi(buf+11);

        } else if (!strncmp(buf, "virtfs.gid", 10)) {

            stbuf->st_gid = atoi(buf+11);

        } else if (!strncmp(buf, "virtfs.mode", 11)) {

            stbuf->st_mode = atoi(buf+12);

        } else if (!strncmp(buf, "virtfs.rdev", 11)) {

            stbuf->st_rdev = atoi(buf+12);

        }

        memset(buf, 0, ATTR_MAX);

    }

    fclose(fp);

}
