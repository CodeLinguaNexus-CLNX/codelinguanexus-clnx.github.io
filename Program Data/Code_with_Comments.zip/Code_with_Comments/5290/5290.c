/*
This test function is responsible for validating the conversion and manipulation of JSON boolean values within the QEMU QObject framework. Here's the breakdown:

- It tests the conversion of JSON boolean values "true" and "false" into QObjects, ensuring that the conversion is successful and the resulting object type is QBool.
- It validates the integrity of the converted QBool objects by checking their integer representation using qbool_get_int().
- It checks the conversion of QObjects representing boolean values back to JSON strings, ensuring that the conversion produces the expected JSON boolean representations.
- It releases the memory allocated for the QObjects and associated resources using QDECREF() to prevent memory leaks.

Some points to notice when using this test function:
- The test function relies on the QEMU QObject framework and its associated data types and conversion functions.
- It covers both positive and negative scenarios for boolean value conversion, ensuring that the conversion and manipulation functions behave as expected.
- Memory management through the use of QDECREF() is crucial for maintaining resource integrity and preventing memory leaks.
- This test function provides coverage for the handling of boolean values specifically within the context of the QEMU QObject framework.
*/

START_TEST(keyword_literal)

{

    QObject *obj;

    QBool *qbool;

    QString *str;



    obj = qobject_from_json("true");

    fail_unless(obj != NULL);

    fail_unless(qobject_type(obj) == QTYPE_QBOOL);



    qbool = qobject_to_qbool(obj);

    fail_unless(qbool_get_int(qbool) != 0);



    str = qobject_to_json(obj);

    fail_unless(strcmp(qstring_get_str(str), "true") == 0);

    QDECREF(str);



    QDECREF(qbool);



    obj = qobject_from_json("false");

    fail_unless(obj != NULL);

    fail_unless(qobject_type(obj) == QTYPE_QBOOL);



    qbool = qobject_to_qbool(obj);

    fail_unless(qbool_get_int(qbool) == 0);



    str = qobject_to_json(obj);

    fail_unless(strcmp(qstring_get_str(str), "false") == 0);

    QDECREF(str);



    QDECREF(qbool);



    obj = qobject_from_jsonf("%i", false);

    fail_unless(obj != NULL);

    fail_unless(qobject_type(obj) == QTYPE_QBOOL);



    qbool = qobject_to_qbool(obj);

    fail_unless(qbool_get_int(qbool) == 0);



    QDECREF(qbool);

    

    obj = qobject_from_jsonf("%i", true);

    fail_unless(obj != NULL);

    fail_unless(qobject_type(obj) == QTYPE_QBOOL);



    qbool = qobject_to_qbool(obj);

    fail_unless(qbool_get_int(qbool) != 0);



    QDECREF(qbool);

}
