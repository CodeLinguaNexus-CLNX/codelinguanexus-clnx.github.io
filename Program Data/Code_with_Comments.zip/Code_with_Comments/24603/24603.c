/**
 * This function is responsible for simulating the pressing of a key in the VNC session associated with the given VncState, based on the provided keysym value.
 *
 * Here's the detail: The function first translates the keysym value to a scancode using the VNC state's keyboard layout, and then extracts the keycode from the resulting scancode. It then sends a key press event with the obtained keycode, followed by a key release event using the input event interface. Optional key press delay is included between the press and release events.
 *
 * Need's to notice:
 * 1. The functionality of this function depends on the correctness of the keyboard layout and the keysym-to-scancode translation process, which may vary across different environments.
 * 2. The use of the input event interface for sending key press and release events assumes the availability and proper configuration of the underlying input subsystem.
 * 3. Any modifications to the handling of key events or key press delay should be carefully reviewed to ensure the intended behavior and compatibility with the VNC session.
 **/
static void press_key(VncState *vs, int keysym)

{

    int keycode = keysym2scancode(vs->vd->kbd_layout, keysym) & SCANCODE_KEYMASK;

    qemu_input_event_send_key_number(vs->vd->dcl.con, keycode, true);

    qemu_input_event_send_key_delay(0);

    qemu_input_event_send_key_number(vs->vd->dcl.con, keycode, false);

    qemu_input_event_send_key_delay(0);

}
