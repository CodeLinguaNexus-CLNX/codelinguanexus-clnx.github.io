/*
This function is responsible for generating RLDIMI (Rotate Left Doubleword Immediate then Mask Insert) instructions within the context of the disassembler. Here's a detailed breakdown of the function:

1. The gen_rldimi function takes as input a DisasContext *ctx, representing the context of the disassembler, along with the mbn (mask bit number) and shn (shift number).

2. It initializes variables for mask and the shift/mask values based on the opcode context.

3. The function then proceeds to generate the RLDIMI instruction sequence based on conditional checks and opcode values.

4. Depending on the values of sh and mb extracted from the opcode, the function generates corresponding load, shift, mask, and store operations using helper functions such as gen_op_load_gpr_T0, gen_op_rotli64_T0, gen_andi_T0_64, gen_andi_T1_64, gen_op_or, and gen_op_store_T0_gpr.

5. Additionally, it handles the generation of instruction sequence based on the Rc (Record bit) field in the opcode.

Needs to notice:
- This function operates within the context of a disassembler and is likely part of a larger framework for instruction decoding and interpretation.
- Understanding the specifics of RLDIMI instruction encoding and its interaction with the disassembler context is essential for comprehending and modifying this function.
- Developers should be familiar with the architecture's instruction set and the disassembler's internals when working on or utilizing this function.
*/
static always_inline void gen_rldimi (DisasContext *ctx, int mbn, int shn)

{

    uint64_t mask;

    uint32_t sh, mb;



    sh = SH(ctx->opcode) | (shn << 5);

    mb = MB(ctx->opcode) | (mbn << 5);

    if (likely(sh == 0)) {

        if (likely(mb == 0)) {

            gen_op_load_gpr_T0(rS(ctx->opcode));

            goto do_store;

        } else if (likely(mb == 63)) {

            gen_op_load_gpr_T0(rA(ctx->opcode));

            goto do_store;

        }

        gen_op_load_gpr_T0(rS(ctx->opcode));

        gen_op_load_gpr_T1(rA(ctx->opcode));

        goto do_mask;

    }

    gen_op_load_gpr_T0(rS(ctx->opcode));

    gen_op_load_gpr_T1(rA(ctx->opcode));

    gen_op_rotli64_T0(sh);

 do_mask:

    mask = MASK(mb, 63 - sh);

    gen_andi_T0_64(ctx, mask);

    gen_andi_T1_64(ctx, ~mask);

    gen_op_or();

 do_store:

    gen_op_store_T0_gpr(rA(ctx->opcode));

    if (unlikely(Rc(ctx->opcode) != 0))

        gen_set_Rc0(ctx);

}
