/*
This function is responsible for performing read or write operations on memory using the IOMMU (Input-Output Memory Management Unit) for DMA (Direct Memory Access) transfers.
Here's the detail: The function iterates through the provided buffer and invokes DMA translation to map the guest physical address to the host physical address, and then reads from or writes to the corresponding memory region based on the specified DMA direction. It also includes error handling and buffer cleaning in case of translation failure and performs partial buffer operations for larger translated regions.

Needs to notice: The function is reliant on the proper initialization of the DMAContext and associated translation functions. It also assumes the availability and proper configuration of the host address space. Additionally, it performs buffer cleaning in case of translation failure during reads from the guest, ensuring data security and integrity.
*/int iommu_dma_memory_rw(DMAContext *dma, dma_addr_t addr,

                        void *buf, dma_addr_t len, DMADirection dir)

{

    target_phys_addr_t paddr, plen;

    int err;



#ifdef DEBUG_IOMMU

    fprintf(stderr, "dma_memory_rw context=%p addr=0x" DMA_ADDR_FMT " len=0x"

            DMA_ADDR_FMT " dir=%d\n", dma, addr, len, dir);

#endif



    while (len) {

        err = dma->translate(dma, addr, &paddr, &plen, dir);

        if (err) {

	    /*

             * In case of failure on reads from the guest, we clean the

             * destination buffer so that a device that doesn't test

             * for errors will not expose qemu internal memory.

	     */

	    memset(buf, 0, len);

            return -1;

        }



        /* The translation might be valid for larger regions. */

        if (plen > len) {

            plen = len;

        }



        address_space_rw(dma->as, paddr, buf, plen, dir == DMA_DIRECTION_FROM_DEVICE);



        len -= plen;

        addr += plen;

        buf += plen;

    }



    return 0;

}
