/*
This function is responsible for initializing the audio PCM (Pulse Code Modulation) information based on the provided audio settings. It determines parameters such as frequency, bits per sample, sign, number of channels, shift, alignment, bytes per second, and endianness based on the audio format and settings.

Here's the detail of the function: The function initializes the local variables bits, sign, and shift to their default values. Then, it uses a switch statement to determine the parameters based on the audio format specified in the provided audio settings. For each format, it sets the appropriate values for bits, sign, and shift. After that, it assigns the corresponding values to the fields of the audio_pcm_info structure including frequency, bits, sign, number of channels, shift, alignment, bytes per second, and endianness based on the provided audio settings.

Need's to notice that the function performs format-specific initialization of the audio PCM information, taking into account the audio format specified in the provided settings. It ensures that the PCM information is properly initialized to reflect the characteristics of the audio data, such as sample size, sign, and endianness. Additionally, the function calculates the shift and align values based on the number of channels to ensure proper alignment and byte-per-sample considerations.

*/void audio_pcm_init_info(struct audio_pcm_info* info, audsettings_t* as)

{

    int bits = 8, sign = 0, shift = 0;



    switch (as->fmt) {

    case AUD_FMT_S8:

        sign = 1;

    case AUD_FMT_U8:

        break;



    case AUD_FMT_S16:

        sign = 1;

    case AUD_FMT_U16:

        bits = 16;

        shift = 1;

        break;



    case AUD_FMT_S32:

        sign = 1;

    case AUD_FMT_U32:

        bits = 32;

        shift = 2;

        break;

    }



    info->freq = as->freq;

    info->bits = bits;

    info->sign = sign;

    info->nchannels = as->nchannels;

    info->shift = (as->nchannels == 2) + shift;

    info->align = (1 << info->shift) - 1;

    info->bytes_per_second = info->freq << info->shift;

    info->swap_endianness = (as->endianness != AUDIO_HOST_ENDIANNESS);

}
