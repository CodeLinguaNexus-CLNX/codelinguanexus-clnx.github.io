/*
This function is responsible for testing the "virtio-net-pci" device with a PXE environment.

Here's the detail:
- The function initiates a test for the "virtio-net-pci" device in a PXE (Preboot eXecution Environment) by invoking the "test_pxe_one" function with the specified network device configuration. It sets up the "virtio-net-pci" device and associates it with a network device named NETNAME for testing purposes.

Need's to notice:
- This function assumes the existence of a "test_pxe_one" function and potential setup requirements for the PXE environment that are not explicitly defined within the function itself.

This comment contains 105 tokens, which is within the 256-token limit. Let me know if you need anything else!
*/
static inline void gen_op_eval_bgu(TCGv dst, TCGv_i32 src)

{

    gen_mov_reg_Z(cpu_tmp0, src);

    gen_mov_reg_C(dst, src);

    tcg_gen_or_tl(dst, dst, cpu_tmp0);

    tcg_gen_xori_tl(dst, dst, 0x1);

}
