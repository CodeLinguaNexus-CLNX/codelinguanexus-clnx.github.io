/*
This function is responsible for creating and initializing an array of CelEvaluation structures based on the dimensions of the video frame and a specific mapping scheme. Here's the breakdown:

Functionality:
The function allocates memory for an array of CelEvaluation structures and initializes their sourceX and sourceY fields based on a mapping to the ROQ quadtree order.
It iterates through the video frame dimensions in a specific pattern, setting the sourceX and sourceY coordinates for each CelEvaluation structure according to the mapping scheme.

Details:
The function operates on a RoqContext *enc and a RoqTempdata *tempData, where it allocates memory for the array of CelEvaluation structures within tempData.
The memory allocation size is determined by the product of the width and height of the video frame, divided by 64, and each element being the size of CelEvaluation structure.
It then iterates through the video frame dimensions in a nested loop, incrementing x and y by 16 in each iteration to cover non-overlapping 16x16 blocks.
Within the nested loop, it further iterates through the four quadrants of each 16x16 block, setting the sourceX and sourceY coordinates for the CelEvaluation structures based on the mapping scheme.

Points to Note:
Developers using this function should ensure proper initialization of the RoqContext and RoqTempdata structures before invoking this function to avoid unexpected behavior.
Memory allocation for the array of CelEvaluation structures should be handled with care, and proper error handling for memory allocation failure is essential.
Understanding the specific mapping scheme used to set the sourceX and sourceY coordinates is crucial for interpreting the behavior of the initialized CelEvaluation array.

Overall, the function creates and initializes an array of CelEvaluation structures based on the dimensions of the video frame and a predefined mapping scheme, providing the necessary data structure for further processing within the RoqContext.
*/
static void create_cel_evals(RoqContext *enc, RoqTempdata *tempData)

{

    int n=0, x, y, i;



    tempData->cel_evals = av_malloc(enc->width*enc->height/64 * sizeof(CelEvaluation));



    /* Map to the ROQ quadtree order */

    for (y=0; y<enc->height; y+=16)

        for (x=0; x<enc->width; x+=16)

            for(i=0; i<4; i++) {

                tempData->cel_evals[n  ].sourceX = x + (i&1)*8;

                tempData->cel_evals[n++].sourceY = y + (i&2)*4;

            }

}
