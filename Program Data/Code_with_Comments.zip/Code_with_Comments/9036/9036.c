/*
This function is responsible for parsing the metadata body of an FLV (Flash Video) file when reading from the input. Here's the detailed breakdown:

1. Function Name: `flv_read_metabody`

2. Function's Responsibility:
   - This function is responsible for reading and parsing the metadata body from an FLV file within the context of an FFmpeg `AVFormatContext`.

3. Detailed Description:
   - It starts by reading the `onMetaData` string from the input, indicating the beginning of the metadata.
   - It then checks for specific cases such as "onTextData" and validates the "onMetaData" string.
   - After identifying audio and video streams, it proceeds to parse the second object, expecting a mixed array, by calling `amf_parse_object`.
   - The function returns 0 on successful parsing and -1 on failure.

4. Key Points to Note:
   - The function assumes a specific structure and format for the metadata body, including the presence of the "onMetaData" string as the first object.
   - The proper identification of audio and video streams is crucial for subsequent parsing and processing of the metadata.
   - Review the error handling and ensure that potential failure cases are appropriately handled to avoid unexpected behavior.

It's important to verify that the FLV files follow the expected format and structure, and that the function's assumptions about the metadata content are valid. Additionally, the error handling should be thorough to handle different scenarios that may arise during metadata parsing.
*/
static int flv_read_metabody(AVFormatContext *s, int64_t next_pos)

{

    AMFDataType type;

    AVStream *stream, *astream, *vstream;

    AVIOContext *ioc;

    int i;

    // only needs to hold the string "onMetaData".

    // Anything longer is something we don't want.

    char buffer[11];



    astream = NULL;

    vstream = NULL;

    ioc     = s->pb;



    // first object needs to be "onMetaData" string

    type = avio_r8(ioc);

    if (type != AMF_DATA_TYPE_STRING ||

        amf_get_string(ioc, buffer, sizeof(buffer)) < 0)

        return -1;



    if (!strcmp(buffer, "onTextData"))

        return 1;



    if (strcmp(buffer, "onMetaData"))

        return -1;



    // find the streams now so that amf_parse_object doesn't need to do

    // the lookup every time it is called.

    for (i = 0; i < s->nb_streams; i++) {

        stream = s->streams[i];

        if (stream->codec->codec_type == AVMEDIA_TYPE_AUDIO)

            astream = stream;

        else if (stream->codec->codec_type == AVMEDIA_TYPE_VIDEO)

            vstream = stream;

    }



    // parse the second object (we want a mixed array)

    if (amf_parse_object(s, astream, vstream, buffer, next_pos, 0) < 0)

        return -1;



    return 0;

}
