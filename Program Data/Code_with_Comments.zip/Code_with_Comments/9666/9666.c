/*
First Paragraph:
This function is responsible for handling program interrupts in the context of the CPUS390XState for the S390X architecture. It manages the updates to the program status word (PSW) and other relevant state information in response to program interrupt events during CPU execution.

Second Paragraph:
Here's the detailed description of the function: Upon invocation, the do_program_interrupt function begins by retrieving the interrupt length (ilen) from the CPUS390XState environment. It then processes the ilen based on different cases, including deferred evaluation of ilen when it is set to ILEN_LATER or ILEN_LATER_INC. Subsequently, the function logs relevant information about the interrupt code and ilen before mapping the lowcore area in the physical memory to update the program status word and related state information. It then performs the necessary endian conversions for the updated values before unmapping the lowcore area. Finally, it prints debug information and updates the program status word based on the calculated mask and address.

Third Paragraph:
Needs to notice that when using this function, it is important to consider the specific S390X architecture and the handling of program interrupts within this context. Developers should be mindful of the endian conversions required for updating the program status word and related state information, ensuring consistency with the architecture's requirements. Additionally, understanding the behavior of interrupt length and its impact on the program status word updates is crucial for proper handling of program interrupts in the S390X architecture.

*/static void do_program_interrupt(CPUS390XState* env)

{

    uint64_t mask, addr;

    LowCore *lowcore;

    hwaddr len = TARGET_PAGE_SIZE;

    int ilen = env->int_pgm_ilen;



    switch (ilen) {

    case ILEN_LATER:

        ilen = get_ilen(cpu_ldub_code(env, env->psw.addr));

        break;

    case ILEN_LATER_INC:

        ilen = get_ilen(cpu_ldub_code(env, env->psw.addr));

        env->psw.addr += ilen;

        break;

    default:

        assert(ilen == 2 || ilen == 4 || ilen == 6);

    }



    qemu_log_mask(CPU_LOG_INT, "%s: code=0x%x ilen=%d\n",

                  __func__, env->int_pgm_code, ilen);



    lowcore = cpu_physical_memory_map(env->psa, &len, 1);



    lowcore->pgm_ilen = cpu_to_be16(ilen);

    lowcore->pgm_code = cpu_to_be16(env->int_pgm_code);

    lowcore->program_old_psw.mask = cpu_to_be64(get_psw_mask(env));

    lowcore->program_old_psw.addr = cpu_to_be64(env->psw.addr);

    mask = be64_to_cpu(lowcore->program_new_psw.mask);

    addr = be64_to_cpu(lowcore->program_new_psw.addr);



    cpu_physical_memory_unmap(lowcore, len, 1, len);



    DPRINTF("%s: %x %x %" PRIx64 " %" PRIx64 "\n", __func__,

            env->int_pgm_code, ilen, env->psw.mask,

            env->psw.addr);



    load_psw(env, mask, addr);

}
