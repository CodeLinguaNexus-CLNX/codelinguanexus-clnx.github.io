/*
This function, `helper_cmptun`, is responsible for comparing two 64-bit floating point values encoded as integers and returning a result based on IEEE 754 standard comparison rules.

Here's the detail: The function first converts the input integer representations of floating point numbers `a` and `b` to their corresponding 64-bit floating point representations `fa` and `fb` using the `t_to_float64` function. It then checks if either `fa` or `fb` represents a quiet NaN (Not a Number) using the `float64_is_quiet_nan` function. If either of them is a quiet NaN, it returns the value `0x4000000000000000ULL` as specified in the IEEE 754 standard. Otherwise, it returns 0.

Needs to notice that this function operates on 64-bit floating point values encoded as integers and handles comparisons based on the IEEE 754 standard, particularly with regard to quiet NaNs. When using the function, it is important to understand the IEEE 754 rules for comparing floating point values and the significance of the specific return value in the context of the standard.

*/uint64_t helper_cmptun(uint64_t a, uint64_t b)

{

    float64 fa, fb;



    fa = t_to_float64(a);

    fb = t_to_float64(b);



    if (float64_is_quiet_nan(fa) || float64_is_quiet_nan(fb))

        return 0x4000000000000000ULL;

    else

        return 0;

}
