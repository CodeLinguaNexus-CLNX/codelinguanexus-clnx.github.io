/* This function is responsible for reading the current CPU number using the RDHWR instruction on a MIPS CPU. */

/* Here's the detail: The function first checks the availability of the RDHWR instruction by calling the check_hwrena function with the CPU state as a parameter. It then retrieves the EBase register value from the CPU state, masks it with 0x3ff, and returns the result as the current CPU number. */

/* Need's to notice that this function assumes the CPU state is properly initialized and accessible. Additionally, it relies on the check_hwrena function to ensure the RDHWR instruction is supported, and the caller should handle any potential error conditions if the instruction is not available. */target_ulong helper_rdhwr_cpunum(CPUMIPSState* env)

{

    check_hwrena(env, 0);

    return env->CP0_EBase & 0x3ff;

}
