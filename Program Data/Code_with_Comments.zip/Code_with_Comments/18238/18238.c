/*
This function is responsible for determining whether a specific range of data within a BlockDriverState is comprised of zeroes.

Here's the detail: Upon invocation, this function calculates the start offset and size of the data range, aligning the start and size to the nearest sector boundaries. It then clamps the range to the length of the image before checking the status of the underlying sectors. If the range is determined to be empty, the function returns true. Otherwise, it queries the block status of the specified range and checks if the data is comprised entirely of zeroes, returning a boolean result based on the outcome of the check.

Need's to notice: It is important to consider that the functionality of this function relies on the accuracy and consistency of the underlying block driver state. Additionally, the calculation and alignment of the data range to sector boundaries should be taken into account, especially when assessing the presence of non-zero data within the specified range. Users should also consider the potential performance implications of querying and checking block status, especially when dealing with large data ranges.
*/
static bool is_zero(BlockDriverState *bs, int64_t offset, int64_t bytes)

{

    int nr;

    int64_t res;

    int64_t start;



    /* TODO: Widening to sector boundaries should only be needed as

     * long as we can't query finer granularity. */

    start = QEMU_ALIGN_DOWN(offset, BDRV_SECTOR_SIZE);

    bytes = QEMU_ALIGN_UP(offset + bytes, BDRV_SECTOR_SIZE) - start;



    /* Clamp to image length, before checking status of underlying sectors */

    if (start + bytes > bs->total_sectors * BDRV_SECTOR_SIZE) {

        bytes = bs->total_sectors * BDRV_SECTOR_SIZE - start;

    }



    if (!bytes) {

        return true;

    }

    res = bdrv_get_block_status_above(bs, NULL, start >> BDRV_SECTOR_BITS,

                                      bytes >> BDRV_SECTOR_BITS, &nr, NULL);

    return res >= 0 && (res & BDRV_BLOCK_ZERO) &&

        nr * BDRV_SECTOR_SIZE == bytes;

}
