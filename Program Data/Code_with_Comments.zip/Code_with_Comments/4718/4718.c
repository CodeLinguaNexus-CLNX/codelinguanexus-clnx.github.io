/*
This function is responsible for reading a double-precision floating-point number from the input stream using the specified endianness. It extracts the binary representation of the double-precision floating-point number from the input stream and returns the corresponding double-precision floating-point value.

Here's the detail: The function uses the GetByteContext and bytestream2 functions to read a 64-bit integer value from the input stream either in little-endian or big-endian format based on the 'le' parameter. It then interprets the obtained 64-bit integer as a double-precision floating-point number and returns it.

Need's to notice that the function utilizes type aliasing to reinterpret the binary representation of the 64-bit integer as a double-precision floating-point number, and it handles the endianness conversion appropriately based on the 'le' parameter.

*/static double tget_double(GetByteContext* gb, int le)

{

    av_alias64 i = { .u64 = le ? bytestream2_get_le64(gb) : bytestream2_get_be64(gb)};

    return i.f64;

}
