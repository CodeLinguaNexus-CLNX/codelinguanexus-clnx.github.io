/*
This function is responsible for writing a chain of X.509 certificates into a file in the PEM format.

Here's the detail:
1. The function takes a filename, an array of gnutls_x509_crt_t pointers representing the certificates (certs), and the number of certificates (ncerts).
2. It initializes variables for buffer capacity, buffer offset, and dynamically allocates an initial buffer using g_new0.
3. It iterates through each certificate in the array and exports it to the PEM format using gnutls_x509_crt_export.
4. If the buffer is not large enough to hold the exported certificate, it dynamically reallocates the buffer using g_renew and retries the export operation.
5. The exported certificate data is appended to the buffer, and the offset is updated accordingly.
6. Finally, it writes the buffer content to the specified file using g_file_set_contents.

Needs to notice:
- The function dynamically adjusts the buffer size if it's not large enough to hold the exported certificate, ensuring all certificates are written to the file.
- It uses gnutls_x509_crt_export to convert X.509 certificates to the PEM format for writing to the file.
- If any step fails, the function calls abort(), indicating an unrecoverable error.
*/
void test_tls_write_cert_chain(const char *filename,

                               gnutls_x509_crt_t *certs,

                               size_t ncerts)

{

    size_t i;

    size_t capacity = 1024, offset = 0;

    char *buffer = g_new0(char, capacity);

    int err;



    for (i = 0; i < ncerts; i++) {

        size_t len = capacity - offset;

    retry:

        err = gnutls_x509_crt_export(certs[i], GNUTLS_X509_FMT_PEM,

                                     buffer + offset, &len);

        if (err < 0) {

            if (err == GNUTLS_E_SHORT_MEMORY_BUFFER) {

                buffer = g_renew(char, buffer, offset + len);

                capacity = offset + len;

                goto retry;

            }

            g_critical("Failed to export certificate chain %s: %d",

                       gnutls_strerror(err), err);

            abort();

        }

        offset += len;

    }



    if (!g_file_set_contents(filename, buffer, offset, NULL)) {

        abort();

    }


}