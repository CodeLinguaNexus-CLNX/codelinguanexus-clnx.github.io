/* This function is responsible for initializing slice contexts for the FFV1 video codec. */

/* Here's the detail of the function. It calculates the total number of slices based on the horizontal and vertical slice counts, performs validation checks, and then initializes individual slice contexts. Each slice context is allocated and configured with the appropriate parameters, including width, height, position, and sample buffer allocation. Additionally, error handling for memory allocation and slice count validation is included. */

/* Needs to notice that this function is essential for proper initialization of slice contexts in the FFV1 codec. When using this function, ensure that the FFV1Context pointer is properly initialized and that required memory allocations are successful to avoid potential segmentation faults and memory leaks. Additionally, verify the input parameters for slice counts and handle potential error conditions to ensure the correct initialization of slice contexts. */av_cold int ffv1_init_slice_contexts(FFV1Context *f)

{

    int i;



    f->slice_count = f->num_h_slices * f->num_v_slices;

    if (f->slice_count <= 0) {

        av_log(f->avctx, AV_LOG_ERROR, "Invalid number of slices\n");

        return AVERROR(EINVAL);

    }



    for (i = 0; i < f->slice_count; i++) {

        FFV1Context *fs = av_mallocz(sizeof(*fs));

        int sx          = i % f->num_h_slices;

        int sy          = i / f->num_h_slices;

        int sxs         = f->avctx->width  *  sx      / f->num_h_slices;

        int sxe         = f->avctx->width  * (sx + 1) / f->num_h_slices;

        int sys         = f->avctx->height *  sy      / f->num_v_slices;

        int sye         = f->avctx->height * (sy + 1) / f->num_v_slices;

        f->slice_context[i] = fs;

        memcpy(fs, f, sizeof(*fs));

        memset(fs->rc_stat2, 0, sizeof(fs->rc_stat2));



        fs->slice_width  = sxe - sxs;

        fs->slice_height = sye - sys;

        fs->slice_x      = sxs;

        fs->slice_y      = sys;



        fs->sample_buffer = av_malloc(3 * MAX_PLANES * (fs->width + 6) *

                                      sizeof(*fs->sample_buffer));

        if (!fs->sample_buffer)

            return AVERROR(ENOMEM);

    }

    return 0;

}
