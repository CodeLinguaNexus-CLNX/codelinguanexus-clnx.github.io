/*This function is responsible for writing a buffer of data to a QEMUFile. It handles the task of transferring data from the input buffer to the output buffer, taking into account the remaining space in the output buffer, writing to the underlying file descriptor, and flushing the buffer when it becomes full.

Here's the detail:
The function iterates through the input buffer, transferring data to the output buffer in chunks of a certain size. It keeps track of the number of bytes transferred and uses the appropriate mechanism for writing to the buffer based on the presence of writev_buffer operation. If the buffer becomes full, it is flushed to ensure the data is written to the underlying file descriptor.

Needs to notice:
- This function manages the transfer of data from the input buffer to the output buffer in a controlled and efficient manner.
- It handles the buffer flushing when necessary to ensure the data is properly written to the underlying file descriptor.
- The function takes into account potential errors that may occur during the data transfer process and handles them appropriately.*/
void qemu_put_buffer(QEMUFile *f, const uint8_t *buf, int size)

{

    int l;



    if (f->last_error) {

        return;

    }



    while (size > 0) {

        l = IO_BUF_SIZE - f->buf_index;

        if (l > size) {

            l = size;

        }

        memcpy(f->buf + f->buf_index, buf, l);

        f->bytes_xfer += l;

        if (f->ops->writev_buffer) {

            add_to_iovec(f, f->buf + f->buf_index, l);

        }

        f->buf_index += l;

        if (f->buf_index == IO_BUF_SIZE) {

            qemu_fflush(f);

        }

        if (qemu_file_get_error(f)) {

            break;

        }

        buf += l;

        size -= l;

    }

}
