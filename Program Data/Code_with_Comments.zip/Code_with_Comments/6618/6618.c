/*
This function is responsible for decoding the value using the APE (Monkey's Audio) algorithm, based on the file version.

Here's the detail of the function:
The function first checks the file version and selects the appropriate decoding method based on the version. For file versions below 3990, it decodes the value using a specific method, handling potential overflow and bit manipulation. For file versions 3990 and above, it applies a different decoding method, involving the calculation of a base and pivot, and incorporating overflow handling.

Needs to notice:
The decoding behavior is dependent on the file version, and the handling of overflow and bit manipulation is critical for accurate decoding.
The function updates the rice parameter for further decoding, and then converts the decoded value to a signed integer before returning.
Developers should ensure that the decoding logic aligns with the APE specification and handles various file versions appropriately.
*/

static inline int ape_decode_value(APEContext* ctx, APERice* rice)

{

    int x, overflow;



    if (ctx->fileversion < 3990) {

        int tmpk;



        overflow = range_get_symbol(ctx, counts_3970, counts_diff_3970);



        if (overflow == (MODEL_ELEMENTS - 1)) {

            tmpk = range_decode_bits(ctx, 5);

            overflow = 0;

        } else

            tmpk = (rice->k < 1) ? 0 : rice->k - 1;



        if (tmpk <= 16)

            x = range_decode_bits(ctx, tmpk);

        else {

            x = range_decode_bits(ctx, 16);

            x |= (range_decode_bits(ctx, tmpk - 16) << 16);

        }

        x += overflow << tmpk;

    } else {

        int base, pivot;



        pivot = rice->ksum >> 5;

        if (pivot == 0)

            pivot = 1;



        overflow = range_get_symbol(ctx, counts_3980, counts_diff_3980);



        if (overflow == (MODEL_ELEMENTS - 1)) {

            overflow  = range_decode_bits(ctx, 16) << 16;

            overflow |= range_decode_bits(ctx, 16);

        }



        if (pivot < 0x10000) {

            base = range_decode_culfreq(ctx, pivot);

            range_decode_update(ctx, 1, base);

        } else {

            int base_hi = pivot, base_lo;

            int bbits = 0;



            while (base_hi & ~0xFFFF) {

                base_hi >>= 1;

                bbits++;

            }

            base_hi = range_decode_culfreq(ctx, base_hi + 1);

            range_decode_update(ctx, 1, base_hi);

            base_lo = range_decode_culfreq(ctx, 1 << bbits);

            range_decode_update(ctx, 1, base_lo);



            base = (base_hi << bbits) + base_lo;

        }



        x = base + overflow * pivot;

    }



    update_rice(rice, x);



    /* Convert to signed */

    if (x & 1)

        return (x >> 1) + 1;

    else

        return -(x >> 1);

}
