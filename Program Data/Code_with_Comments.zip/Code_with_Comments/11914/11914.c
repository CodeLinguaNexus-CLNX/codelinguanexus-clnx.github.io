/* This function is responsible for setting the maximum amount of RAM that can be allocated below the 4GB boundary for a PC machine. It validates and updates the maximum RAM size based on the provided value, ensuring it does not exceed the 4GB limit. Additionally, it handles a warning message for very small RAM sizes that may impact BIOS functionality.

Here's the detail: The function retrieves the provided value using the Visitor interface and performs validation checks to ensure it does not exceed the 4GB boundary. If the value is within the acceptable range, it updates the maximum RAM size accordingly. Additionally, the function issues a warning message if the specified size is very small, indicating potential BIOS compatibility issues.

Need's to notice: When using this function to set the maximum RAM size below 4GB, ensure that the provided value is within the supported range and consider the warning message for very small RAM sizes that may impact the BIOS functionality. It's important to validate the maximum RAM size based on system requirements and compatibility with the BIOS. */
static void pc_machine_set_max_ram_below_4g(Object* obj, Visitor* v,

                                            const char *name, void *opaque,

                                            Error **errp)

{

    PCMachineState *pcms = PC_MACHINE(obj);

    Error *error = NULL;

    uint64_t value;



    visit_type_size(v, name, &value, &error);

    if (error) {

        error_propagate(errp, error);

        return;

    }

    if (value > (1ULL << 32)) {

        error_setg(&error,

                   "Machine option 'max-ram-below-4g=%"PRIu64

                   "' expects size less than or equal to 4G", value);

        error_propagate(errp, error);

        return;

    }



    if (value < (1ULL << 20)) {

        error_report("Warning: small max_ram_below_4g(%"PRIu64

                     ") less than 1M.  BIOS may not work..",

                     value);

    }



    pcms->max_ram_below_4g = value;

}
