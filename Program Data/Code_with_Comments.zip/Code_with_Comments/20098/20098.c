/*
First paragraph: This function is responsible for checking if a given device name is valid for network host configuration.

Second paragraph: Here's the detailed description of the function. The function takes a device name as input and checks it against a list of valid parameter names. The list includes "tap", "socket", "dump", and other optional parameters depending on the configuration, such as "bridge", "user", and "vde". The function iterates through the valid_param_list array using a for loop and compares each element with the given device name using the strncmp function. If a match is found, indicating that the device name is valid, the function returns 1. If there is no match after checking all the elements in the valid_param_list, the function returns 0, indicating that the device name is not valid.

Third paragraph: There are no specific notices or points to be aware of mentioned in the code snippet.

TOKENS USED: function, checking, device name, valid_param_list, for loop, strncmp function, match, return value.
*/
static int net_host_check_device(const char *device)

{

    int i;

    const char *valid_param_list[] = { "tap", "socket", "dump"

#ifdef CONFIG_NET_BRIDGE

                                       , "bridge"

#endif

#ifdef CONFIG_SLIRP

                                       ,"user"

#endif

#ifdef CONFIG_VDE

                                       ,"vde"

#endif

    };

    for (i = 0; i < ARRAY_SIZE(valid_param_list); i++) {

        if (!strncmp(valid_param_list[i], device,

                     strlen(valid_param_list[i])))

            return 1;

    }



    return 0;

}
