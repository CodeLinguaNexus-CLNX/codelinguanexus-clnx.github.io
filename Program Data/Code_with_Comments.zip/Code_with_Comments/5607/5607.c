/*
This function is responsible for allocating and initializing an OfDpaFlow structure with a given cookie and timestamp.

Here's the detail of the function:
- It initializes a variable 'now' to hold the current time in seconds, obtained from the QEMU virtual clock in milliseconds and then converted to seconds.
- It allocates memory for a new OfDpaFlow structure and initializes it to zero using the g_new0 function.
- If the memory allocation fails, the function returns NULL.
- It sets the 'cookie' field of the allocated flow structure with the provided cookie value and assigns a default value to the 'tbl_id' field of the 'mask' member.
- It updates the 'install_time' and 'refresh_time' fields of the 'stats' member with the current timestamp stored in the variable 'now'.
- Finally, it returns the initialized flow structure.

Need's to notice that the function assumes the availability and proper functioning of the QEMU virtual clock, and it's crucial to handle any potential memory allocation failures. Additionally, the correct interpretation and usage of the 'cookie' value and the structure members should be ensured based on the specific requirements and context of its use.
*/static OfDpaFlow *of_dpa_flow_alloc(uint64_t cookie)

{

    OfDpaFlow *flow;

    int64_t now = qemu_clock_get_ms(QEMU_CLOCK_VIRTUAL) / 1000;



    flow = g_new0(OfDpaFlow, 1);

    if (!flow) {

        return NULL;

    }



    flow->cookie = cookie;

    flow->mask.tbl_id = 0xffffffff;



    flow->stats.install_time = flow->stats.refresh_time = now;



    return flow;

}
